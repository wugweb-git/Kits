<?php
/**
 * Claim form #6 (owner, 31 Oct 2026): the listing's details pre-filled in the form, and the review of a claim field by
 * field. Nothing a claimant sends is published until it is approved here.
 *
 * - Pre-fill: one fluentform/rendering_field_data_* filter fills every l_* field from the listing (public data only)
 *   and names the listing in "{Listing}" labels.
 * - Directory → Claims: the claim entries (Fluent Forms), listed on DirectoryWeb's Claims screen; one claim's screen
 *   (&entry=) shows now → proposed for the fields that differ, each with its own tick. Approve writes the ticked values
 *   to the listing, each logged in the enrichment change log (source "Claimed by organisation", today) with Undo there,
 *   and marks the listing claimed (aw_verified, aw_verified_on). Opening hours are shown, not written: they are entered in the listing's Opening hours list.
 * - "Show my name on this listing" = Yes and approved: the claimant's FluentCRM contact gets org-approved and the
 *   listing (vol_org_listing, vol_org_show, vol_org_role), so [aw_org_people] shows their name and role.
 *
 * @package directoryweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The claim form's listing fields: form key => label, where it lives (meta key, or phones | hours | services | about),
 * the enrichment field it is logged as, and whether it is public (pre-filled) or kept for the team only.
 */
const DIRECTORYWEB_CLAIM_L = array(
	'l_email'      => array( 'Listing email', 'aw_email', 'email', true ),
	'phones'       => array( 'Phone numbers', 'phones', 'phone', true ),
	'l_area'       => array( 'Area or landmark', 'aw_area', 'area', true ),
	'l_address'    => array( 'Full address', 'aw_address', 'address', true ),
	'l_maps'       => array( 'Google Maps link', 'aw_maps_url', 'maps_url', true ),
	'l_hours'      => array( 'Opening hours', 'hours', '', true ),
	'l_about'      => array( 'About', 'about', 'about', true ),
	'l_aliases'    => array( 'Also known as', 'aw_aliases', 'aliases', true ),
	'l_founded'    => array( 'Year established', 'aw_founded', 'founded', true ),
	'l_head'       => array( 'Head of the organisation', 'aw_head', 'head', true ),
	'l_animals'    => array( 'Animals helped', 'aw_animals', 'animals', true ),
	'l_areas'      => array( 'Areas served', 'aw_areas_served', 'areas_served', true ),
	'l_services'   => array( 'Services', 'services', 'services', true ),
	'l_languages'  => array( 'Languages', 'aw_languages', 'languages', true ),
	'l_website'    => array( 'Website', 'aw_website', 'website', true ),
	'l_instagram'  => array( 'Instagram', 'aw_instagram', 'instagram', true ),
	'l_facebook'   => array( 'Facebook', 'aw_facebook', 'facebook', true ),
	'l_x'          => array( 'X', 'aw_x', 'x', true ),
	'l_youtube'    => array( 'YouTube', 'aw_youtube', 'youtube', true ),
	'l_linkedin'   => array( 'LinkedIn', 'aw_linkedin', 'linkedin', true ),
	'l_reg'        => array( 'Registration no.', 'aw_registration', 'registration', true ),
	'l_12a'        => array( '12A', 'aw_reg_12a', 'reg_12a', true ),
	'l_80g'        => array( '80G', 'aw_reg_80g', 'reg_80g', true ),
	'l_darpan'     => array( 'NGO Darpan ID', 'aw_darpan_id', 'darpan_id', true ),
	'l_reg_type'   => array( 'Registered as', 'aw_reg_type', 'reg_type', true ),
	'l_reg_auth'   => array( 'Registration authority', 'aw_reg_authority', 'reg_authority', false ),
	'l_reg_act'    => array( 'Registration act', 'aw_reg_act', 'reg_act', false ),
	'l_reg_date'   => array( 'Date of registration', 'aw_reg_date', 'reg_date', true ),
	'l_fcra'       => array( 'FCRA', 'aw_fcra', 'fcra', true ),
	'l_awbi_code'  => array( 'AWBI code', 'aw_awbi_code', 'awbi_code', true ),
	'l_awbi_rec'   => array( 'AWBI recognised on', 'aw_awbi_recognised', 'awbi_recognised', true ),
	'l_awbi_ren'   => array( 'AWBI renewed on', 'aw_awbi_renewed', 'awbi_renewed', true ),
	'l_awbi_valid' => array( 'AWBI valid until', 'aw_awbi_valid', 'awbi_valid', true ),
	'l_volunteer'  => array( 'Volunteer link', 'aw_volunteer_url', 'volunteer_url', true ),
	'l_adopt'      => array( 'Adopt link', 'aw_adopt_url', 'adopt_url', true ),
);

/** The claim form's Fluent Forms ID (0 when it is not set up). */
function directoryweb_claim_ff_id() {
	$id = function_exists( 'kits_ff_id' ) ? (int) kits_ff_id( 'claim' ) : 0;
	if ( ! $id && function_exists( 'directoryweb_claim_ff_form_id' ) ) {
		$id = directoryweb_claim_ff_form_id(); // without Kits Core: the form saved in the option, if Fluent Forms is active and has it
	}
	return $id;
}

/** A listing's opening hours as one line, as the form shows them ("Mon 09:00–18:00, Sun closed"). */
function directoryweb_claim_hours_text( $lid ) {
	$out = array();
	foreach ( directoryweb_listing_hours( $lid ) as $r ) {
		$out[] = substr( $r['day'], 0, 3 ) . ' ' . ( $r['closed'] ? 'closed' : $r['open'] . '–' . $r['close'] );
	}
	return implode( ', ', $out );
}

/** The listing's service tags (slugs) from the claim form's list, sorted. */
function directoryweb_claim_service_slugs( $lid ) {
	$slugs = array_values( array_intersect( (array) wp_get_object_terms( $lid, 'post_tag', array( 'fields' => 'slugs' ) ), array_keys( DIRECTORYWEB_SERVICES ) ) );
	sort( $slugs );
	return $slugs;
}

/**
 * Stored or rendered text as plain text for a form box: tags gone (a date chip keeps its words, "Dec 2023"), entities decoded.
 *
 * @param string $text Text that may hold markup (an excerpt can hold the rendered date chips).
 * @return string
 */
function directoryweb_claim_plain( $text ) {
	$text = wp_strip_all_tags( (string) $text );
	$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	return trim( wp_strip_all_tags( $text ) ); // again: markup that was stored entity-encoded is tags only after the decode
}

/** The listing's About text as the form shows it: its body, or its short bio when the body is empty. */
function directoryweb_claim_about( $lid ) {
	$raw  = (string) get_post_field( 'post_content', $lid );
	$body = directoryweb_claim_plain( $raw );
	// As the listing page shows it (directoryweb_block_listing_about): the short bio when the body is empty or an import's template intro.
	$bio = has_excerpt( $lid ) && ( '' === $body || ( function_exists( 'directoryweb_listing_is_template_intro' ) && directoryweb_listing_is_template_intro( trim( $raw ) ) ) );
	return $bio ? directoryweb_claim_plain( (string) get_post_field( 'post_excerpt', $lid ) ) : $body;
}

/**
 * What the listing has now for one claim field, as text (phones: one "number | label | WhatsApp" line each; services:
 * slugs joined with a comma).
 *
 * @param int    $lid    Listing ID.
 * @param string $key    DIRECTORYWEB_CLAIM_L key.
 * @param bool   $public True: '' for fields kept for the team only (the form is a public page).
 * @return string
 */
function directoryweb_claim_now( $lid, $key, $public = true ) {
	$def = DIRECTORYWEB_CLAIM_L[ $key ] ?? null;
	if ( ! $def || ( $public && ! $def[3] ) ) {
		return '';
	}
	switch ( $def[1] ) {
		case 'phones':
			return implode( "\n", array_map( fn( $r ) => directoryweb_ff_phone_store( $r['number'] ) . ( '' !== $r['label'] ? ' | ' . $r['label'] : '' ) . ( $r['whatsapp'] ? ' | WhatsApp' : '' ), directoryweb_listing_phones( $lid ) ) );
		case 'hours':
			return directoryweb_claim_hours_text( $lid );
		case 'services':
			return implode( ',', directoryweb_claim_service_slugs( $lid ) );
		case 'about':
			return directoryweb_claim_about( $lid );
		default:
			return directoryweb_claim_plain( get_post_meta( $lid, $def[1], true ) ); // text, never markup, in every pre-filled box
	}
}

/* ---------- Pre-fill (b) ---------- */

foreach ( array( 'input_text', 'input_email', 'input_url', 'textarea', 'input_checkbox', 'input_radio', 'select' ) as $aw_claim_el ) {
	add_filter(
		'fluentform/rendering_field_data_' . $aw_claim_el,
		function ( $data, $form ) {
			if ( ! directoryweb_claim_ff_id() || (int) $form->id !== directoryweb_claim_ff_id() || ! function_exists( 'directoryweb_ff_phone10' ) ) { // DirectoryWeb's own phone helper (standalone-fallback.php)
				return $data;
			}
			$listing = function_exists( 'directoryweb_form_page_listing' ) ? directoryweb_form_page_listing() : null;
			$name    = $listing ? wp_strip_all_tags( get_the_title( $listing ) ) : 'this organisation';
			// "{Listing}" in a label or an option (role, consent) names the listing.
			if ( isset( $data['settings']['label'] ) ) {
				$data['settings']['label'] = str_replace( '{Listing}', esc_html( $name ), (string) $data['settings']['label'] );
			}
			foreach ( (array) ( $data['settings']['advanced_options'] ?? array() ) as $i => $o ) {
				$data['settings']['advanced_options'][ $i ]['label'] = str_replace( '{Listing}', esc_html( $name ), (string) ( $o['label'] ?? '' ) );
			}
			$field = (string) ( $data['attributes']['name'] ?? '' );
			if ( ! $listing || 0 !== strpos( $field, 'l_' ) ) {
				return $data;
			}
			$lid = $listing->ID;
			if ( preg_match( '/^l_phone([1-3])(_label|_wa)?$/', $field, $m ) ) {
				$row = directoryweb_listing_phones( $lid )[ (int) $m[1] - 1 ] ?? null;
				if ( $row ) {
					$part                        = $m[2] ?? '';
					$ten                         = directoryweb_ff_phone10( $row['number'] ); // the 10 digits after the +91 in front of the box
					$data['attributes']['value'] = '_wa' === $part ? ( $row['whatsapp'] ? array( '1' ) : array() ) : ( '_label' === $part ? $row['label'] : ( '' !== $ten ? $ten : $row['number'] ) );
				}
				return $data;
			}
			if ( 'l_services' === $field ) {
				$data['attributes']['value'] = directoryweb_claim_service_slugs( $lid );
				return $data;
			}
			if ( isset( DIRECTORYWEB_CLAIM_L[ $field ] ) ) {
				$now = directoryweb_claim_now( $lid, $field, true );
				if ( isset( directoryweb_ff_social_map()[ $field ] ) && '' !== directoryweb_ff_social_user( $field, $now ) ) {
					$now = directoryweb_ff_social_user( $field, $now ); // the username after the link shown in front of the box
				} elseif ( in_array( $field, directoryweb_ff_dates(), true ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $now ) ) {
					$now = wp_date( 'j M Y', strtotime( $now . ' 12:00:00' ) ); // the site's date format
				}
				$data['attributes']['value'] = $now;
			}
			return $data;
		},
		20,
		2
	);
}

/* ---------- A claim entry, read ---------- */

/**
 * The fields of a Fluent Forms claim form that carry files: kind => form field name. A form built for DirectoryWeb names
 * its upload fields logo, photos and proof; a different form can say otherwise through the filter.
 *
 * @return array
 */
function directoryweb_claim_ff_file_fields(): array {
	return (array) apply_filters( 'directoryweb_claim_ff_file_fields', array( 'logo' => 'logo', 'photos' => 'photos', 'proof' => 'proof' ) );
}

/**
 * A Fluent Forms claim's evidence, in DirectoryWeb's own store. The first call copies each uploaded file in (after the
 * same checks as the built-in form) and remembers the result on the entry, so a file is imported once. A file that is
 * refused is listed under "problems", for the reviewer; nothing is dropped without a trace.
 *
 * @param int   $entry_id Fluent Forms submission ID.
 * @param array $data     The submission's response data.
 * @return array { logo: string[], photos: string[], proof: string[], problems: string[] }
 */
function directoryweb_claim_ff_evidence( int $entry_id, array $data ): array {
	$have = array( 'logo' => array(), 'photos' => array(), 'proof' => array(), 'problems' => array() );
	if ( ! class_exists( '\FluentForm\App\Helpers\Helper' ) ) {
		return $have;
	}
	$saved = \FluentForm\App\Helpers\Helper::getSubmissionMeta( $entry_id, 'dw_evidence', '' );
	$saved = is_array( $saved ) ? $saved : (array) json_decode( (string) $saved, true );
	if ( isset( $saved['done'] ) ) {
		return array_merge( $have, array_intersect_key( $saved, $have ) );
	}
	$kinds = directoryweb_evidence_kinds();
	foreach ( directoryweb_claim_ff_file_fields() as $kind => $field ) {
		$urls = $data[ $field ] ?? array();
		$urls = is_array( $urls ) ? $urls : ( '' !== (string) $urls ? array( (string) $urls ) : array() );
		foreach ( array_slice( array_filter( array_map( 'strval', $urls ) ), 0, (int) ( $kinds[ $kind ]['files'] ?? 1 ) ) as $url ) {
			$name = directoryweb_evidence_import_path( $url, $kind );
			if ( is_wp_error( $name ) ) {
				$have['problems'][] = $name->get_error_message();
				continue;
			}
			$have[ $kind ][] = $name;
		}
	}
	\FluentForm\App\Helpers\Helper::setSubmissionMeta( $entry_id, 'dw_evidence', wp_json_encode( $have + array( 'done' => 1 ) ), directoryweb_claim_ff_id() );
	return $have;
}

// A claim sent through Fluent Forms has its files copied into DirectoryWeb's private store when it arrives.
add_action(
	'fluentform/submission_inserted',
	function ( $entry_id, $data, $form ) {
		if ( directoryweb_claim_ff_id() && (int) ( $form->id ?? 0 ) === directoryweb_claim_ff_id() ) {
			directoryweb_claim_ff_evidence( (int) $entry_id, (array) $data );
		}
	},
	30,
	3
);

/**
 * One claim entry: its data, what it proposes for the listing (DIRECTORYWEB_CLAIM_L keys => text), the person, uploads, status.
 * Entries from the earlier form (aw_phone, aw_whatsapp, aw_email, aw_website, aw_area, aw_services) are read too.
 *
 * @param int $entry_id Fluent Forms entry ID.
 * @return array|null
 */
function directoryweb_claim_entry( $entry_id ) {
	global $wpdb;
	if ( ! directoryweb_claim_ff_id() || ! function_exists( 'directoryweb_ff_phone_store' ) ) {
		return null; // no Fluent Forms claim form, or DirectoryWeb's phone helper is not loaded
	}
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, form_id, serial_number, response, created_at FROM {$wpdb->prefix}fluentform_submissions WHERE id = %d AND form_id = %d", $entry_id, directoryweb_claim_ff_id() ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	if ( ! $row ) {
		return null;
	}
	$d       = (array) json_decode( (string) $row['response'], true );
	$s       = fn( $k ) => is_array( $d[ $k ] ?? '' ) ? implode( ',', array_map( 'strval', $d[ $k ] ) ) : trim( (string) ( $d[ $k ] ?? '' ) );
	$lid     = absint( $d['listing'] ?? 0 );
	$lid     = $lid && 'aw_listing' === get_post_type( $lid ) ? $lid : 0; // the hidden listing field comes from the page: only a real listing
	$propose = array();
	$legacy  = isset( $d['aw_email'] ) || isset( $d['aw_phone'] ) || isset( $d['aw_services'] );
	if ( $legacy ) { // the form before 31 Oct 2026: only what was typed; an empty box meant "keep"
		foreach ( array( 'aw_email' => 'l_email', 'aw_website' => 'l_website', 'aw_area' => 'l_area' ) as $old => $new ) {
			if ( '' !== $s( $old ) ) {
				$propose[ $new ] = $s( $old );
			}
		}
		if ( '' !== $s( 'aw_services' ) ) {
			$sv = array_intersect( explode( ',', $s( 'aw_services' ) ), array_keys( DIRECTORYWEB_SERVICES ) );
			sort( $sv );
			$propose['l_services'] = implode( ',', $sv );
		}
		$add = array_filter( array( $s( 'aw_phone' ) => false, $s( 'aw_whatsapp' ) => true ), fn( $k ) => '' !== (string) $k, ARRAY_FILTER_USE_KEY );
		if ( $add && $lid ) {
			$rows = directoryweb_listing_phones( $lid );
			foreach ( $add as $num => $wa ) {
				$rows[] = array( 'number' => (string) $num, 'label' => '', 'whatsapp' => $wa );
			}
			$propose['phones'] = implode( "\n", array_map( fn( $r ) => $r['number'] . ( '' !== $r['label'] ? ' | ' . $r['label'] : '' ) . ( $r['whatsapp'] ? ' | WhatsApp' : '' ), $rows ) );
		}
	} else {
		foreach ( DIRECTORYWEB_CLAIM_L as $key => $def ) {
			if ( 'phones' === $key ) {
				$lines = array();
				for ( $i = 1; $i <= 3; $i++ ) {
					$num = directoryweb_ff_phone_store( $s( "l_phone{$i}" ) );
					if ( '' !== $num ) {
						$lab     = $s( "l_phone{$i}_label" );
						$lines[] = $num . ( '' !== $lab ? ' | ' . $lab : '' ) . ( directoryweb_ff_ticked( $d, "l_phone{$i}_wa" ) ? ' | WhatsApp' : '' );
					}
				}
				foreach ( array_slice( $lid ? directoryweb_listing_phones( $lid ) : array(), 3 ) as $r ) { // numbers past the form's three stay as they are
					$lines[] = directoryweb_ff_phone_store( $r['number'] ) . ( '' !== $r['label'] ? ' | ' . $r['label'] : '' ) . ( $r['whatsapp'] ? ' | WhatsApp' : '' );
				}
				$propose['phones'] = implode( "\n", $lines );
				continue;
			}
			if ( 'l_services' === $key ) {
				$sv = array_intersect( (array) ( $d['l_services'] ?? array() ), array_keys( DIRECTORYWEB_SERVICES ) );
				sort( $sv );
				$propose[ $key ] = implode( ',', $sv );
				continue;
			}
			if ( ! $def[3] && '' === $s( $key ) ) {
				continue; // a team-only field the form never showed filled: empty is "nothing said"
			}
			$propose[ $key ] = $s( $key );
		}
	}
	$ev   = directoryweb_claim_ff_evidence( (int) $row['id'], $d );
	$file = fn( $url ) => preg_match( '/[?&]f=([A-Za-z0-9]{20}\.png)/', (string) $url, $m ) ? $m[1] : '';
	$meta = class_exists( '\FluentForm\App\Helpers\Helper' ) ? \FluentForm\App\Helpers\Helper::getSubmissionMeta( (int) $row['id'], 'aw_claim_review', '' ) : '';
	return array(
		'id'      => (int) $row['id'],
		'ref'     => function_exists( 'kits_ff_ref' ) ? kits_ff_ref( 'claim', (int) $row['id'] ) : ( (int) $row['serial_number'] ? 'AW-C-' . (int) $row['serial_number'] : '' ),
		'sent'    => (string) $row['created_at'],
		'listing' => $lid,
		'name'    => $s( 'name' ),
		'role'    => DIRECTORYWEB_CLAIM_ROLES[ $s( 'role' ) ] ?? $s( 'role' ),
		'email'   => $s( 'email' ),
		'phone'   => $s( 'phone' ),
		'show'    => 'yes' === $s( 'show_on_listing' ),
		'notes'   => $s( 'notes' ),
		'logo'    => $ev['logo'][0] ?? $file( $d['logo_token'] ?? '' ),
		'photos'  => $ev['photos'] ? $ev['photos'] : array_values( array_filter( array_map( $file, explode( ',', (string) ( $d['photo_tokens'] ?? '' ) ) ) ) ),
		'proof'   => isset( $ev['proof'][0] ) ? directoryweb_evidence_link( $ev['proof'][0] ) : (string) ( $d['proof_token'] ?? '' ),
		'proofs'  => array_map( 'directoryweb_evidence_link', $ev['proof'] ),
		'problems' => $ev['problems'],
		'propose' => $propose,
		'review'  => is_array( $meta ) ? $meta : (array) json_decode( (string) $meta, true ), // stored as JSON (aw_claim_ff_decide)
	);
}

/**
 * The fields where the claim differs from the listing now: key => [label, now, proposed]. Compared without regard to
 * spacing; email and links also without regard to case, and links without scheme, www and a closing slash.
 *
 * @param array $c directoryweb_claim_entry().
 * @return array
 */
function directoryweb_claim_changes( $c ) {
	$norm = function ( $v, $loose ) {
		$v = trim( preg_replace( '/\s+/', ' ', (string) $v ) );
		return $loose ? rtrim( preg_replace( '#^https?://(www\.)?#', '', strtolower( $v ) ), '/' ) : $v; // links and email without regard to case
	};
	$out = array();
	foreach ( $c['propose'] as $key => $new ) {
		$now   = directoryweb_claim_now( $c['listing'], $key, false );
		if ( isset( directoryweb_ff_social_map()[ $key ] ) && '' !== directoryweb_ff_social_user( $key, $now ) && '' !== directoryweb_ff_social_user( $key, $new ) ) {
			$now = directoryweb_ff_social_user( $key, $now ); // the link and its username are the same thing
			$new = directoryweb_ff_social_user( $key, $new );
		}
		$loose = 'l_email' === $key || ( 0 === strpos( DIRECTORYWEB_CLAIM_L[ $key ][1], 'aw_' ) && preg_match( '/url|website|instagram|facebook|_x$|youtube|linkedin/', DIRECTORYWEB_CLAIM_L[ $key ][1] ) );
		if ( $norm( $now, $loose ) !== $norm( $new, $loose ) ) {
			$out[ $key ] = array( DIRECTORYWEB_CLAIM_L[ $key ][0], $now, $new );
		}
	}
	return $out;
}

/* ---------- Fluent Forms → Claims (with the other form entries) ---------- */

/** The Claims screen's address (registered under Directory, so every old link keeps working). */
const DIRECTORYWEB_CLAIMS_LINK = 'edit.php?post_type=aw_listing&page=aw-claims';

add_action(
	'admin_menu',
	function () {
		add_submenu_page( 'edit.php?post_type=aw_listing', 'Claims', 'Claims', DIRECTORYWEB_CAP, 'aw-claims', 'directoryweb_claims_screen' ); // phpcs:ignore WordPress.WP.Capabilities.Unknown -- DirectoryWeb's own capability (directoryweb-caps.php)
	}
);

/**
 * Claims are form entries (owner, 12 Nov 2026: "With form entries"): the menu item sits under Fluent Forms, after
 * Entries, for a user who can open Fluent Forms; anyone else keeps it under Directory. Only the item moves: the screen,
 * its address and its review are as before.
 */
function directoryweb_claims_in_forms(): bool {
	global $menu;
	foreach ( (array) $menu as $item ) {
		if ( is_array( $item ) && 'fluent_forms' === ( $item[2] ?? '' ) ) {
			return current_user_can( (string) $item[1] ) && current_user_can( DIRECTORYWEB_CAP ); // phpcs:ignore WordPress.WP.Capabilities.Unknown -- DirectoryWeb's own capability (directoryweb-caps.php)
		}
	}
	return false;
}
add_action(
	'admin_menu',
	function () {
		global $submenu;
		if ( ! directoryweb_claims_in_forms() ) {
			// No Fluent Forms menu (standalone, or with Kits Core and no forms plugin): Claims is an item of the DirectoryWeb menu.
			// Its parent, Directory, is no longer a top-level menu, so the item registered above would be unreachable from the menu.
			if ( current_user_can( DIRECTORYWEB_CAP ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- DirectoryWeb's own capability (directoryweb-caps.php)
				add_submenu_page( DIRECTORYWEB_PAGE, __( 'Claims', 'directoryweb' ), __( 'Claims', 'directoryweb' ), DIRECTORYWEB_CAP, DIRECTORYWEB_CLAIMS_LINK ); // phpcs:ignore WordPress.WP.Capabilities.Unknown
			}
			return;
		}
		remove_submenu_page( 'edit.php?post_type=aw_listing', 'aw-claims' ); // the screen stays registered at its address
		$items = array_values( (array) ( $submenu['fluent_forms'] ?? array() ) );
		$at    = count( $items );
		foreach ( $items as $i => $item ) {
			if ( 'fluent_forms_all_entries' === ( $item[2] ?? '' ) ) {
				$at = $i + 1;
				break;
			}
		}
		array_splice( $items, $at, 0, array( array( 'Claims', DIRECTORYWEB_CAP, DIRECTORYWEB_CLAIMS_LINK, 'Claims' ) ) );
		$submenu['fluent_forms'] = $items; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- one item added to Fluent Forms' menu.
	},
	999
);
// On the Claims screen, Fluent Forms is the open menu and Claims the lit item.
add_filter(
	'parent_file',
	function ( $parent ) {
		global $plugin_page;
		if ( 'aw-claims' === $plugin_page ) {
			return directoryweb_claims_in_forms() ? 'fluent_forms' : DIRECTORYWEB_PAGE;
		}
		return $parent;
	},
	PHP_INT_MAX - 1
);
add_filter(
	'submenu_file',
	function ( $file ) {
		global $plugin_page;
		return 'aw-claims' === $plugin_page ? DIRECTORYWEB_CLAIMS_LINK : $file;
	},
	PHP_INT_MAX - 1
);

/** Directory → Claims: the list (DirectoryWeb's shell screen), one claim (&entry=), or the notice after a review (&done=). */
function directoryweb_claims_screen() {
	if ( ! current_user_can( DIRECTORYWEB_CAP ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- DirectoryWeb's own capability (directoryweb-caps.php)
		wp_die( 'Not allowed.', 403 );
	}
	if ( function_exists( 'directoryweb_ui_page' ) && directoryweb_ui_page( 'claims' ) ) {
		return; // The Claims list (directoryweb-ui.php).
	}
	$entry = absint( wp_unslash( $_GET['entry'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification -- read only
	$done  = sanitize_key( wp_unslash( $_GET['done'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $entry && '' === $done ) {
		// The list is only on the shell screen, which could not be drawn.
		if ( function_exists( 'directoryweb_missing_page' ) ) {
			directoryweb_missing_page( __( 'Claims', 'directoryweb' ) );
		} else {
			echo '<div class="wrap"><h1>' . esc_html__( 'Claims', 'directoryweb' ) . '</h1>';
			wp_admin_notice( esc_html__( 'DirectoryWeb needs Kits Core (active, with its build) to show this screen.', 'directoryweb' ), array( 'type' => 'error' ) );
			echo '</div>';
		}
		return;
	}
	echo '<div class="wrap">';
	if ( ! directoryweb_claim_ff_id() ) {
		echo '<h1>Claims</h1>';
		wp_admin_notice( 'The claim form is not set up (Fluent Forms off, or <code>wp aw ff-form claim &lt;ID&gt;</code>).', array( 'type' => 'warning' ) );
		echo '</div>';
		return;
	}
	if ( $entry ) {
		directoryweb_claim_review_screen( $entry );
		echo '</div>';
		return;
	}
	echo '<h1>Claims</h1>';
	wp_admin_notice( esc_html( 'approved' === $done ? 'Claim approved: the ticked fields are on the listing (Undo in Plugins → SourceWeb → Enrichment review).' : 'Claim rejected.' ), array( 'type' => 'success', 'dismissible' => true ) );
	echo '<p><a href="' . esc_url( add_query_arg( array( 'post_type' => 'aw_listing', 'page' => 'aw-claims' ), admin_url( 'edit.php' ) ) ) . '">All claims</a></p>';
	echo '</div>';
}

/** One claim: who sent it, the changed fields with a tick each, uploads, and Approve / Reject. */
function directoryweb_claim_review_screen( $entry_id ) {
	$c = directoryweb_claim_entry( $entry_id );
	if ( ! $c ) {
		echo '<h1>Claim</h1><p>Not found.</p>';
		return;
	}
	$lid    = $c['listing'];
	$status = (string) ( $c['review']['status'] ?? 'pending' );
	$back   = add_query_arg( array( 'post_type' => 'aw_listing', 'page' => 'aw-claims' ), admin_url( 'edit.php' ) );
	echo '<h1>Claim: ' . esc_html( $lid ? get_the_title( $lid ) : '(no listing)' ) . ' <span class="subtitle">' . esc_html( $c['ref'] ) . '</span></h1>';
	echo '<p><a href="' . esc_url( $back ) . '">All claims</a>' . ( $lid ? ' · <a href="' . esc_url( (string) get_edit_post_link( $lid ) ) . '">Edit listing</a> · <a href="' . esc_url( (string) get_permalink( $lid ) ) . '" target="_blank">View listing</a>' : '' ) . '</p>';
	$who = array(
		'From'                 => $c['name'] . ( '' !== $c['role'] ? ', ' . $c['role'] : '' ),
		'Email'                => $c['email'],
		'Phone'                => $c['phone'],
		'Show name on listing' => $c['show'] ? 'Yes' : 'No',
		'Anything else'        => $c['notes'],
		'Sent'                 => mysql2date( 'j M Y, H:i', $c['sent'] ),
		'Status'               => ucfirst( $status ),
	);
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( $who as $k => $v ) {
		echo '<tr><th scope="row">' . esc_html( $k ) . '</th><td>' . nl2br( esc_html( '' !== (string) $v ? (string) $v : '—' ) ) . '</td></tr>';
	}
	$proofs = $c['proofs'] ? $c['proofs'] : ( '' !== $c['proof'] ? array( $c['proof'] ) : array() );
	echo '<tr><th scope="row">Proof</th><td>' . wp_kses( $proofs ? implode( '<br>', array_map( fn( $u, $i ) => '<a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">Open document ' . ( $i + 1 ) . '</a>', $proofs, array_keys( $proofs ) ) ) : '—', array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ), 'br' => array() ) ) . '</td></tr>';
	if ( $c['problems'] ) {
		echo '<tr><th scope="row">Files not accepted</th><td>' . implode( '<br>', array_map( 'esc_html', $c['problems'] ) ) . '</td></tr>';
	}
	echo '</tbody></table>';

	$changes = directoryweb_claim_changes( $c );
	$pending = 'pending' === $status && $lid;
	echo '<h2>Changes</h2>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'aw_claim_ff_decide_' . $c['id'] );
	echo '<input type="hidden" name="action" value="aw_claim_ff_decide"><input type="hidden" name="entry" value="' . (int) $c['id'] . '">';
	$rows = array();
	$file = 'directoryweb_claim_file_url';
	foreach ( $changes as $key => $ch ) {
		$hand   = 'l_hours' === $key; // entered by hand in the listing's Opening hours
		$bad    = 'phones' === $key && array_filter( explode( "\n", (string) $ch[2] ), fn( $l ) => '' !== trim( $l ) && ! directoryweb_claim_phone_ok( explode( '|', $l )[0] ) );
		$rows[] = array(
			'cb'    => $pending && ! $hand ? '<input type="checkbox" name="fields[]" value="' . esc_attr( $key ) . '"' . ( $bad ? '' : ' checked' ) . '>' : '',
			'field' => esc_html( $ch[0] ) . ( $hand ? '<br><span class="description">Enter by hand in the listing\'s Opening hours.</span>' : '' ) . ( $bad ? '<br><span class="description">A line is not a phone number: approving keeps the list as it is.</span>' : '' ),
			'now'   => nl2br( esc_html( '' !== $ch[1] ? $ch[1] : '—' ) ),
			'new'   => nl2br( esc_html( '' !== $ch[2] ? $ch[2] : '(remove)' ) ),
		);
	}
	if ( '' !== $c['logo'] ) {
		$rows[] = array(
			'cb'    => $pending ? '<input type="checkbox" name="fields[]" value="logo" checked>' : '',
			'field' => 'Logo',
			'now'   => $lid && has_post_thumbnail( $lid ) ? get_the_post_thumbnail( $lid, array( 80, 80 ) ) : '—',
			'new'   => '<img src="' . esc_url( $file( $c['logo'] ) ) . '" alt="" width="80" height="80" style="object-fit:contain">',
		);
	}
	if ( $c['photos'] ) {
		$rows[] = array(
			'cb'    => $pending ? '<input type="checkbox" name="fields[]" value="photos" checked>' : '',
			'field' => 'Photos (added before the current ones, 6 at most)',
			'now'   => esc_html( (string) count( array_filter( explode( ',', (string) get_post_meta( $lid, 'aw_gallery', true ) ) ) ) . ' now' ),
			'new'   => implode( ' ', array_map( fn( $f ) => '<img src="' . esc_url( $file( $f ) ) . '" alt="" width="80" height="80" style="object-fit:cover">', $c['photos'] ) ),
		);
	}
	directoryweb_simple_table( 'aw-claim-changes', array( 'cb' => '<span class="screen-reader-text">Approve</span>', 'field' => 'Field', 'now' => 'Now', 'new' => 'Proposed' ), $rows, array( 'primary' => 'field', 'empty' => 'Nothing differs from the listing.' ) );
	if ( $pending ) {
		echo '<p class="description">Approve writes the ticked fields to the listing (source "Claimed by organisation", today) and marks it claimed. Each field can be undone in Plugins → SourceWeb → Enrichment review.</p>';
		echo '<p>';
		submit_button( 'Approve ticked fields', 'primary', 'do_approve', false );
		echo ' ';
		submit_button( 'Reject', 'secondary', 'do_reject', false );
		echo '</p>';
	} elseif ( ! empty( $c['review']['fields'] ) ) {
		echo '<p>Approved fields: ' . esc_html( implode( ', ', (array) $c['review']['fields'] ) ) . '.</p>';
	}
	echo '</form>';
}

/** A plausible phone number: digits with spaces, +, -, brackets or /, and 6 to 15 digits. */
function directoryweb_claim_phone_ok( $v ) {
	$v = trim( (string) $v );
	$n = strlen( preg_replace( '/\D+/', '', $v ) );
	return (bool) preg_match( '#^[0-9+()\-/ .]+$#', $v ) && $n >= 6 && $n <= 15;
}

/** A claimed value cleaned for its listing field ('' when it cannot be used). */
function directoryweb_claim_clean( $meta_key, $v ) {
	$v = trim( (string) $v );
	switch ( $meta_key ) {
		case 'aw_email':
			return (string) sanitize_email( $v );
		case 'aw_website':
		case 'aw_maps_url':
		case 'aw_donate_url':
		case 'aw_volunteer_url':
		case 'aw_adopt_url':
			return (string) esc_url_raw( $v );
		case 'aw_instagram':
		case 'aw_facebook':
		case 'aw_x':
		case 'aw_youtube':
		case 'aw_linkedin':
			if ( preg_match( '#^(?:https?://)?(?:[a-z]+\.)?[a-z.]+\.[a-z]+/#i', $v ) ) {
				return (string) esc_url_raw( preg_match( '#^https?://#i', $v ) ? $v : 'https://' . $v ); // a link the username box cannot hold (a YouTube channel, a LinkedIn /in/ profile)
			}
			$field = (string) array_search( $meta_key, array_map( fn( $d ) => $d[0], directoryweb_ff_social_map() ), true );
			$user  = '' !== $field ? directoryweb_ff_social_user( $field, $v ) : '';
			return '' !== $user ? sprintf( directoryweb_ff_social_map()[ $field ][1], rawurlencode( $user ) ) : '';
		case 'aw_founded':
			return preg_match( '/^(18|19|20)\d{2}$/', $v ) ? $v : '';
		case 'aw_reg_date':
		case 'aw_awbi_recognised':
		case 'aw_awbi_renewed':
		case 'aw_awbi_valid':
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
		default:
			return sanitize_text_field( $v );
	}
}

/** The link to a stored claim file: DirectoryWeb's own store, or (for a file an older Kits Core form kept) Kits Core's handler. */
function directoryweb_claim_file_url( $name ) {
	if ( function_exists( 'directoryweb_evidence_name_ok' ) && directoryweb_evidence_name_ok( (string) $name ) ) {
		return directoryweb_evidence_link( (string) $name );
	}
	return add_query_arg( array( 'action' => 'aw_ff_file', 'f' => $name ), admin_url( 'admin-post.php' ) );
}

/** A private upload (claim logo or photo) into the media library for the listing; attachment ID or 0. */
function directoryweb_claim_sideload( $file, $lid, $title ) {
	$bytes = function_exists( 'directoryweb_evidence_read' ) ? directoryweb_evidence_read( (string) $file ) : '';
	if ( '' === $bytes && function_exists( 'kits_private_dir' ) && preg_match( '/^[A-Za-z0-9]{20}\.png$/', (string) $file ) && is_file( kits_private_dir() . '/' . $file ) ) {
		$bytes = (string) file_get_contents( kits_private_dir() . '/' . $file ); // a file an older Kits Core form kept, if that plugin is still here
	}
	if ( '' === $bytes || '.pdf' === substr( (string) $file, -4 ) ) {
		return 0;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = wp_tempnam( $file );
	if ( ! $tmp || false === file_put_contents( $tmp, $bytes ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
		return 0;
	}
	$att = media_handle_sideload( array( 'name' => sanitize_title( get_the_title( $lid ) ) . '-' . wp_generate_password( 4, false, false ) . '.png', 'tmp_name' => $tmp ), $lid, $title );
	if ( is_wp_error( $att ) ) {
		wp_delete_file( $tmp );
		return 0;
	}
	update_post_meta( $att, '_wp_attachment_image_alt', $title );
	return (int) $att;
}

/**
 * Write one approved field to the listing, logged first in the enrichment change log (with what was there, for Undo).
 *
 * @param array  $c   directoryweb_claim_entry().
 * @param string $key DIRECTORYWEB_CLAIM_L key, logo or photos.
 * @return bool
 */
function directoryweb_claim_apply_field( $c, $key ) {
	$lid = $c['listing'];
	$src = array( array( 'key' => 'claim', 'name' => 'Claimed by organisation', 'url' => '', 'fetched_at' => wp_date( 'c' ) ) );
	$on   = function_exists( 'aw_enrich_add_row' ) && function_exists( 'aw_enrich_snapshot' ) && function_exists( 'aw_enrich_install' );
	$snap = fn( $field ) => $on ? aw_enrich_snapshot( $lid, $field ) : null;
	$log  = function ( $field, $value, $old = null ) use ( $lid, $src, $c, $on ) {
		if ( $on ) {
			aw_enrich_install();
			aw_enrich_add_row( $lid, $field, $value, null !== $old ? $old : aw_enrich_snapshot( $lid, $field ), $src, 'high', 'approved', 'claim-' . $c['id'], 'Claimed by organisation' );
		}
	};
	if ( 'logo' === $key ) {
		$old = $snap( 'logo' );
		$att = directoryweb_claim_sideload( $c['logo'], $lid, get_the_title( $lid ) . ' logo' );
		if ( ! $att || ! set_post_thumbnail( $lid, $att ) ) {
			return false;
		}
		$log( 'logo', 'claim upload', $old ); // logged once it worked, with what was there before
		return true;
	}
	if ( 'photos' === $key ) {
		$old = $snap( 'photos' );
		$ids = array();
		foreach ( array_slice( $c['photos'], 0, 5 ) as $f ) {
			$att = directoryweb_claim_sideload( $f, $lid, get_the_title( $lid ) );
			if ( $att ) {
				$ids[] = $att;
			}
		}
		if ( ! $ids ) {
			return false;
		}
		$have = array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $lid, 'aw_gallery', true ) ) ) );
		update_post_meta( $lid, 'aw_gallery', implode( ',', array_slice( array_merge( $ids, $have ), 0, 6 ) ) );
		$log( 'photos', 'claim upload', $old );
		return true;
	}
	$def = DIRECTORYWEB_CLAIM_L[ $key ] ?? null;
	if ( ! $def || 'l_hours' === $key || ! array_key_exists( $key, $c['propose'] ) ) {
		return false;
	}
	$new = (string) $c['propose'][ $key ];
	switch ( $def[1] ) {
		case 'phones':
			$rows  = array();
			$lines = array_filter( explode( "\n", $new ) );
			foreach ( $lines as $line ) {
				$p = array_map( 'trim', explode( '|', $line ) );
				if ( ! directoryweb_claim_phone_ok( $p[0] ) ) {
					continue; // not a phone number: never stored
				}
				$rows[] = array( 'number' => sanitize_text_field( $p[0] ), 'label' => sanitize_text_field( 'WhatsApp' !== ( $p[1] ?? '' ) ? ( $p[1] ?? '' ) : '' ), 'whatsapp' => in_array( 'WhatsApp', $p, true ) );
			}
			if ( $lines && count( $rows ) !== count( $lines ) ) {
				return false; // a line is not a phone number: the list stays as it is, the field is reported as not applied
			}
			$log( 'phone', wp_list_pluck( $rows, 'number' ) );
			directoryweb_set_listing_list( $lid, 'aw_phones', $rows );
			return true;
		case 'services':
			$log( 'services', array_filter( explode( ',', $new ) ) );
			directoryweb_set_item_tags( $lid, array_filter( explode( ',', $new ) ), directoryweb_service_slugs() );
			update_post_meta( $lid, 'aw_services_source', 'organisation' );
			update_post_meta( $lid, 'aw_services_on', wp_date( 'Y-m-d' ) );
			return true;
		case 'about':
			$new = directoryweb_claim_plain( $new ); // tags in a proposed About never reach the listing
			$log( 'about', $new );
			wp_update_post( array( 'ID' => $lid, 'post_content' => wpautop( sanitize_textarea_field( $new ) ) ) );
			return true;
		default:
			$val = directoryweb_claim_clean( $def[1], $new );
			if ( '' === $val && '' !== $new ) {
				return false; // not usable for this field (a link, a date or a UPI ID that does not match)
			}
			$log( $def[2], $val ); // the snapshot keeps a second email or website too, for Undo
			'' === $val ? delete_post_meta( $lid, $def[1] ) : update_post_meta( $lid, $def[1], $val );
			$alt = array( 'aw_email' => 'aw_email_alt', 'aw_website' => 'aw_website_alt' )[ $def[1] ] ?? '';
			if ( '' !== $alt ) {
				delete_post_meta( $lid, $alt ); // the organisation has given its own: an unverified second value goes, as for earlier claims
			}
			return true;
	}
}

add_action(
	'admin_post_aw_claim_ff_decide',
	function () {
		$id = absint( wp_unslash( $_POST['entry'] ?? 0 ) );
		if ( ! current_user_can( DIRECTORYWEB_CAP ) || ! check_admin_referer( 'aw_claim_ff_decide_' . $id ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- DirectoryWeb's own capability (directoryweb-caps.php)
			wp_die( 'Not allowed.', 403 );
		}
		$c    = directoryweb_claim_entry( $id );
		$want = isset( $_POST['do_approve'] ) ? 'approved' : 'rejected';
		// The state table (claim-native.php) decides whether this move is allowed; a form claim only moves out of 'pending' here.
		$can = $c && $c['listing'] && ( function_exists( 'directoryweb_claim_can_transition' ) ? directoryweb_claim_can_transition( (string) ( $c['review']['status'] ?? 'pending' ), $want ) : 'pending' === (string) ( $c['review']['status'] ?? 'pending' ) );
		if ( ! $can ) {
			wp_die( 'This claim was already decided, or its listing is missing.', 409 );
		}
		$lid    = $c['listing'];
		$review = array( 'by' => get_current_user_id(), 'at' => current_time( 'mysql' ) );
		if ( isset( $_POST['do_approve'] ) ) {
			$want = array_map( 'sanitize_key', (array) wp_unslash( $_POST['fields'] ?? array() ) );
			$ok   = array();
			foreach ( $want as $key ) {
				if ( directoryweb_claim_apply_field( $c, $key ) ) {
					$ok[] = $key;
				}
			}
			delete_post_meta( $lid, 'aw_unverified' ); // the organisation has spoken: nothing on the listing is "unverified" any more
			update_post_meta( $lid, 'aw_verified', true );
			update_post_meta( $lid, 'aw_verified_on', wp_date( 'Y-m-d' ) );
			update_post_meta( $lid, 'aw_needs_reverify', false );
			delete_transient( 'aw_verified_count' );
			if ( function_exists( 'directoryweb_org_people_link' ) ) { // one of the listing's people, privately; name and role shown only if they ticked "Show my name"
				directoryweb_org_people_link( $lid, $c['email'], $c['role'], $c['show'] );
			}
			if ( function_exists( 'aw_enrich_after_change' ) ) {
				aw_enrich_after_change( $lid );
			}
			$review += array( 'status' => 'approved', 'fields' => $ok );
		} else {
			$review += array( 'status' => 'rejected' );
		}
		if ( class_exists( '\FluentForm\App\Helpers\Helper' ) ) { // Fluent Forms is the claim form's store; without it there is nothing to write to
			\FluentForm\App\Helpers\Helper::setSubmissionMeta( $id, 'aw_claim_review', wp_json_encode( $review ), directoryweb_claim_ff_id() );
		}
		delete_transient( 'directoryweb_claim_rows' ); // DirectoryWeb's Claims list reads it again.
		wp_safe_redirect( add_query_arg( array( 'post_type' => 'aw_listing', 'page' => 'aw-claims', 'done' => $review['status'] ), admin_url( 'edit.php' ) ) );
		exit;
	}
);
