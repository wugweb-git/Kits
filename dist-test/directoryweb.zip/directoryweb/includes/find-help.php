<?php
/**
 * "Find help near you" (owner-approved plan, 24 Oct 2026; revised by the owner the same day): links from the pages
 * Google crawls every day (News, Library, guides and the lab rules campaign) into the Directory's state and district
 * pages, which Search Console showed as "Discovered – currently not indexed".
 *
 * - Place detection: a News, Library or guide item without a place gets one from the state and district names in its
 *   title and summary (LGD names and the spellings in lgd.json, a few city and neighbourhood names). A name counts only
 *   in the title or the summary's first sentence, or when it is written 2 or more times (owner, 24 Oct 2026: a national
 *   story that mentions a state in passing gets no place). Stored like a place set by hand
 *   (aw_state_code, aw_district_code) with aw_place_auto = 1, on publish and by `wp aw-places detect` for older items.
 *   aw_place_source records who set it: "auto" (detected) or "editor" (changed in the Place box; only a real change
 *   counts, as the box posts the place it loaded with). An item left with no place gets one again on its next save.
 *   Not stored: names that are also ordinary words or people's names, a district name two states share unless its
 *   state is named too, and items that name more than 3 states (national stories).
 * - Delhi's districts named for directions read "South Delhi", "North East Delhi" in the links, and are detected
 *   when written that way.
 * - In More (cross-navigation), for an item with a place: its state and that state's districts with listings, at
 *   most 12, nearest first. Without a place: one line, "Find help near you → All states and districts" and Near me.
 * - Campaign pages: a band of 12 states before the Library band, a window that moves with the campaign's ID.
 * - Only places with at least one listing (stored counts, places.php): those pages are indexed. Same HTML for every
 *   visitor; no query of its own beyond the stored counts.
 *
 * @package directoryweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Links shown at most. */
const AW_FINDHELP_MAX = 12;

/** An item that names more states than this is national: no place is detected. */
const AW_PLACE_DETECT_MAX_STATES = 3;

/** District names that are also ordinary words, people's names or rivers (keys): never detected. Delhi's districts are
 * named for directions ("Central", "North East"); the state is still found from "Delhi". */
const AW_PLACE_DETECT_SKIP = array( 'east', 'west', 'north', 'south', 'central', 'northeast', 'northwest', 'southeast', 'southwest', 'centralnorth', 'anand', 'mon', 'una', 'korea', 'sagar', 'mau', 'dhar', 'guna', 'banda', 'hassan', 'salem', 'pali', 'mandi', 'tapi', 'gomati', 'saran', 'mansa', 'nadia', 'ntr', 'sakti', 'kota', 'siang', 'lohit', 'panna', 'erode', 'noney', 'kamle', 'krishna', 'narmada', 'mahisagar', 'vaishali', 'vidisha', 'kheda' );

/** City and big-city neighbourhood names people write for a district (keys as directoryweb_place_key() makes them) → the LGD
 * district name. Only names no other district shares (not Dwarka: Devbhumi Dwarka is in Gujarat). */
const AW_PLACE_DETECT_CITIES = array(
	'bengaluru'    => 'Bengaluru Urban',
	'noida'        => 'Gautam Buddha Nagar',
	'greaternoida' => 'Gautam Buddha Nagar',
	'navimumbai'   => 'Thane',
	'kochi'        => 'Ernakulam',
	'mangaluru'    => 'Dakshina Kannada',
	'mangalore'    => 'Dakshina Kannada',
	'banaras'      => 'Varanasi',
	'benares'      => 'Varanasi',
	'secunderabad' => 'Hyderabad',
	// Neighbourhoods (owner, 24 Oct 2026).
	'kakkanad'     => 'Ernakulam',
	'edappally'    => 'Ernakulam',
	'aluva'        => 'Ernakulam',
	'andheri'      => 'Mumbai Suburban',
	'bandra'       => 'Mumbai Suburban',
	'borivali'     => 'Mumbai Suburban',
	'goregaon'     => 'Mumbai Suburban',
	'powai'        => 'Mumbai Suburban',
	'colaba'       => 'Mumbai',
	'whitefield'   => 'Bengaluru Urban',
	'koramangala'  => 'Bengaluru Urban',
	'indiranagar'  => 'Bengaluru Urban',
	'jayanagar'    => 'Bengaluru Urban',
	'gachibowli'   => 'Ranga Reddy',
	'banjarahills' => 'Hyderabad',
	'jubileehills' => 'Hyderabad',
	'velachery'    => 'Chennai',
	'adyar'        => 'Chennai',
	'annanagar'    => 'Chennai',
	'saltlake'     => 'North 24 Parganas',
	'hinjewadi'    => 'Pune',
	'kothrud'      => 'Pune',
	// Big cities whose name is not a district's (owner, 24 Oct 2026). Not Imphal: it is in two districts.
	'guwahati'     => 'Kamrup Metro',
	'hubballi'     => 'Dharwad',
	'siliguri'     => 'Darjeeling',
	'durgapur'     => 'Paschim Bardhaman',
	'asansol'      => 'Paschim Bardhaman',
	// Towns people search the Directory for (site searches, 1 Nov 2026).
	'pusad'        => 'Yavatmal',
	'shillong'     => 'East Khasi Hills',
	'itanagar'     => 'Papum Pare',
	'panaji'       => 'North Goa',
	'panjim'       => 'North Goa',
	'margao'       => 'South Goa',
	'portblair'    => 'South Andamans',
	'leh'          => 'Leh Ladakh',
	'dharamshala'  => 'Kangra',
	'rishikesh'    => 'Dehradun',
	'rourkela'     => 'Sundaragada',
	'jamshedpur'   => 'East Singhbum',
	'bhilai'       => 'Durg',
);

/** Delhi's districts named for directions (keys): shown and detected as "South Delhi" etc. */
const AW_PLACE_DELHI_DIRECTIONS = array( 'central', 'centralnorth', 'east', 'north', 'northeast', 'northwest', 'outernorth', 'south', 'southeast', 'southwest', 'west' );

/** A place's name in the links: "South Delhi" for Delhi's direction districts, else its own name. */
function directoryweb_findhelp_place_name( $p ) {
	if ( 'district' === $p->kind && in_array( directoryweb_place_key( $p->name ), AW_PLACE_DELHI_DIRECTIONS, true ) && 'delhi' === directoryweb_place_key( directoryweb_place_state( $p->state )->name, 'state' ) ) {
		return $p->name . ' Delhi';
	}
	return $p->name;
}

/** Whether an item gets the block: News, Library, guides (not research) and campaigns. */
function directoryweb_findhelp_applies( $id ) {
	$type = get_post_type( $id );
	if ( 'publish' !== get_post_status( $id ) ) {
		return false;
	}
	return in_array( $type, array( 'aw_news', 'aw_legal', 'aw_campaign' ), true ) || ( 'post' === $type && function_exists( 'aw_item_kind' ) && 'guide' === aw_item_kind( $id ) );
}

/* ---------- Place detection ---------- */

/** Name keys → places: [states by key, districts by key (a key two districts share lists both)]. */
function directoryweb_place_detect_index() {
	static $ix = null;
	if ( null !== $ix ) {
		return $ix;
	}
	$ix = array( array(), array() );
	foreach ( directoryweb_place_states() as $s ) {
		foreach ( array( $s->name, $s->lgd ) as $n ) {
			$ix[0][ directoryweb_place_key( $n, 'state' ) ] = $s;
		}
	}
	foreach ( directoryweb_lgd()['districts'] as $d ) {
		foreach ( array( $d->name, $d->lgd ) as $n ) {
			$ix[1][ directoryweb_place_key( $n ) ][ $d->code ] = $d;
		}
	}
	foreach ( AW_PLACE_DETECT_CITIES as $k => $name ) {
		$d = directoryweb_place_district_by_name( $name );
		if ( $d ) {
			$ix[1][ $k ] = array( $d->code => $d );
		}
	}
	$delhi = directoryweb_place_state_by_name( 'Delhi' );
	foreach ( $delhi ? directoryweb_place_districts( $delhi->code ) : array() as $d ) {
		if ( in_array( directoryweb_place_key( $d->name ), AW_PLACE_DELHI_DIRECTIONS, true ) ) {
			$ix[1][ directoryweb_place_key( $d->name ) . 'delhi' ] = array( $d->code => $d );
		}
	}
	return $ix;
}

/**
 * Names in a text: states (code => times named) and districts (name key => [candidates], name key => times named).
 * Names count only when written with a capital letter; the longest name wins ("West Bengal", not "West").
 *
 * @param string $text Text.
 * @return array [states, district candidates, district counts]
 */
function directoryweb_place_mentions( $text ) {
	list( $states, $districts ) = directoryweb_place_detect_index();
	preg_match_all( '/\p{L}+|&/u', wp_strip_all_tags( (string) $text ), $m );
	$words = $m[0];
	$n     = count( $words );
	$st    = array();
	$ds    = array();
	$dn    = array();
	for ( $i = 0; $i < $n; $i++ ) {
		if ( ! preg_match( '/^\p{Lu}/u', $words[ $i ] ) ) {
			continue;
		}
		for ( $len = min( 9, $n - $i ); $len >= 1; $len-- ) {
			$phrase = implode( ' ', array_slice( $words, $i, $len ) );
			$ks     = directoryweb_place_key( $phrase, 'state' );
			$kd     = directoryweb_place_key( $phrase );
			if ( $len > 1 && 'Delhi' === $words[ $i + $len - 1 ] && isset( $districts[ $kd . 'delhi' ] ) ) {
				$kd = $kd . 'delhi'; // "South Delhi": lgd.json reads it as "South", a skipped word
			} elseif ( in_array( $kd, AW_PLACE_DETECT_SKIP, true ) ) {
				continue;
			}
			if ( isset( $districts[ $kd ] ) ) { // a district first: Chandigarh and Puducherry are both
				$ds[ $kd ] = $districts[ $kd ];
				$dn[ $kd ] = ( $dn[ $kd ] ?? 0 ) + 1;
			} elseif ( isset( $states[ $ks ] ) ) {
				$c        = $states[ $ks ]->code;
				$st[ $c ] = ( $st[ $c ] ?? 0 ) + 1;
			} else {
				continue;
			}
			$i += $len - 1;
			break;
		}
	}
	return array( $st, $ds, $dn );
}

/**
 * Places named in an item: [state code, district code or 0] pairs, at most AW_PLACE_DETECT_MAX_STATES, or [] when it
 * names none or more states than that. A name counts when it is in the title or the summary's first sentence, or
 * named 2 or more times in all ($strict false: every name counts, the rule before 24 Oct 2026).
 *
 * @param string $title   Title.
 * @param string $summary Summary.
 * @param bool   $strict  Apply the title / first sentence / 2 times rule.
 * @return array
 */
function directoryweb_places_in_text( $title, $summary = '', $strict = true ) {
	$summary              = trim( wp_strip_all_tags( (string) $summary ) );
	$first                = preg_split( '/(?<=[.!?])\s+(?=\p{Lu})/u', $summary, 2 )[0];
	list( $lst, , $ldn )  = directoryweb_place_mentions( $title . ' ' . $first );
	list( $st, $ds, $dn ) = directoryweb_place_mentions( $title . ' ' . $summary );
	$counts               = fn( $lead, $all ) => ! $strict || $lead || $all >= 2;
	$found                = array();
	$named                = array_keys( $st ); // every state named, for the national-story limit
	foreach ( $ds as $k => $cands ) {
		if ( count( $cands ) > 1 ) { // a name two states share: only with its state named too
			$cands = array_filter( $cands, fn( $d ) => isset( $st[ $d->state ] ) );
		}
		if ( 1 !== count( $cands ) ) {
			continue;
		}
		$d       = reset( $cands );
		$named[] = (int) $d->state;
		if ( $counts( isset( $ldn[ $k ] ), $dn[ $k ] ) ) {
			$found[ 'd' . $d->code ] = array( $d->state, $d->code );
		}
	}
	if ( count( array_unique( array_map( 'intval', $named ) ) ) > AW_PLACE_DETECT_MAX_STATES ) {
		return array();
	}
	foreach ( $st as $code => $times ) {
		if ( $counts( isset( $lst[ $code ] ), $times ) && ! array_filter( $found, fn( $p ) => (int) $p[0] === (int) $code ) ) {
			$found[ 's' . $code ] = array( $code, 0 );
		}
	}
	return array_values( $found );
}

/** Whether an item should get a detected place: a News, Library or guide item with no place. */
function directoryweb_place_detect_wanted( $id ) {
	$type = get_post_type( $id );
	if ( ! in_array( $type, array( 'aw_news', 'aw_legal', 'post' ), true ) || ( 'post' === $type && ( ! function_exists( 'aw_item_kind' ) || 'guide' !== aw_item_kind( $id ) ) ) ) {
		return false;
	}
	list( $s, $d ) = directoryweb_item_codes( $id );
	return ! $s && ! $d; // not "removed by an editor": the block editor's Place box posts the empty place it loaded with
}

/**
 * Detect and store an item's place. Returns the places found ([] when none).
 *
 * @param int  $id    Item.
 * @param bool $write Store them (false: only report).
 * @return array
 */
function directoryweb_place_detect( $id, $write = true ) {
	$places = directoryweb_places_in_text( get_the_title( $id ), get_post_field( 'post_excerpt', $id ) );
	if ( $places && $write && directoryweb_set_item_places( $id, $places ) ) {
		update_post_meta( $id, 'aw_place_auto', '1' );
		update_post_meta( $id, 'aw_place_source', 'auto' );
	}
	return $places;
}

// On publish and save: a new item gets its place (after the Place box has saved what an editor chose).
add_action(
	'save_post',
	function ( $id, $post ) {
		if ( 'publish' !== $post->post_status || wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ! directoryweb_place_detect_wanted( $id ) ) {
			return;
		}
		directoryweb_place_detect( $id );
	},
	30,
	2
);

/* ---------- Links ---------- */

/**
 * The places to link for an item with a place: its state, then the state's districts with listings, nearest first
 * (to the item's district; by number of listings when the item names only the state). [place, count] pairs.
 *
 * @param int         $id    Item.
 * @param object|null $place Its place (default: the stored one).
 * @return array
 */
function directoryweb_findhelp_places( $id, $place = null ) {
	$place = $place ? $place : directoryweb_item_place( $id );
	$state = $place ? directoryweb_place_parent_state( $place ) : null;
	if ( ! $state || directoryweb_place_count( $state ) < 1 ) {
		return array();
	}
	$out = array( array( $state, directoryweb_place_count( $state ) ) );
	$ds  = array_filter( directoryweb_place_districts( $state->code ), fn( $d ) => directoryweb_place_count( $d ) > 0 );
	if ( 'district' === $place->kind ) {
		$km = array();
		foreach ( $ds as $code => $d ) {
			$km[ $code ] = $code === $place->code ? -1 : ( directoryweb_district_km( $place->code, $code ) ?? PHP_INT_MAX );
		}
		asort( $km );
		$ds = array_map( fn( $c ) => $ds[ $c ], array_keys( $km ) );
	} else {
		uasort( $ds, fn( $a, $b ) => directoryweb_place_count( $b ) <=> directoryweb_place_count( $a ) );
	}
	foreach ( array_slice( $ds, 0, AW_FINDHELP_MAX - 1 ) as $d ) {
		$out[] = array( $d, directoryweb_place_count( $d ) );
	}
	return $out;
}

/** A campaign's 12 states: a window over the states with listings that moves with its ID, A–Z. */
function directoryweb_findhelp_states_window( $id ) {
	$states = array_values( array_filter( directoryweb_place_states(), fn( $s ) => directoryweb_place_count( $s ) > 0 ) ); // A–Z
	$n      = count( $states );
	if ( $n > AW_FINDHELP_MAX ) {
		$start  = ( (int) $id * 7 ) % $n;
		$states = array_map( fn( $i ) => $states[ ( $start + $i ) % $n ], range( 0, AW_FINDHELP_MAX - 1 ) );
		usort( $states, fn( $a, $b ) => strcmp( $a->name, $b->name ) );
	}
	return array_map( fn( $s ) => array( $s, directoryweb_place_count( $s ) ), $states );
}

/**
 * The list of links (name and count, the Browse by state list's look), or the one line when there are none.
 *
 * @param int    $id     Item.
 * @param array  $places [place, count] pairs.
 * @param string $head   Heading classes.
 * @param bool   $all_of A state reads "All of {state}" (item pages, beside its districts); false: its name alone (the
 *                       campaign band, which lists states only; owner, 24 Oct 2026).
 * @return string
 */
function directoryweb_findhelp_html( $id, $places, $head, $all_of = true ) {
	directoryweb_use_style( 'aw-single' ); // aw-findhelp-line, aw-browse-states, aw-findhelp (item More, campaign band)
	$hid = 'aw-findhelp-' . (int) $id;
	if ( ! $places ) {
		return '<p class="aw-findhelp-line"><strong>' . esc_html__( 'Find help near you', 'directoryweb' ) . '</strong>'
			. '<a href="' . esc_url( home_url( '/directory/' ) ) . '">' . esc_html__( 'All states and districts', 'directoryweb' ) . '</a>'
			. '<a href="' . esc_url( home_url( '/directory/#near-me' ) ) . '">' . directoryweb_icon( 'map-pin' ) . esc_html__( 'Near me', 'directoryweb' ) . '</a></p>';
	}
	$items = '';
	foreach ( $places as list( $p, $n ) ) {
		$label  = 'district' === $p->kind || ! $all_of ? directoryweb_findhelp_place_name( $p ) : sprintf( /* translators: %s: state. */ __( 'All of %s', 'directoryweb' ), $p->name );
		$items .= '<li><a href="' . esc_url( directoryweb_directory_url( $p->slug ) ) . '"><span>' . esc_html( $label ) . '</span>' . directoryweb_count( $n ) . '</a></li>';
	}
	return '<nav class="aw-browse-states aw-findhelp" aria-labelledby="' . esc_attr( $hid ) . '"><h2 class="' . esc_attr( $head ) . '" id="' . esc_attr( $hid ) . '">' . esc_html__( 'Find help near you', 'directoryweb' ) . '</h2>'
		. '<p class="aw-findhelp-lede">' . esc_html__( 'Animal welfare organisations, Gaushalas and government vets, with their contact details.', 'directoryweb' ) . '</p>'
		. '<ul>' . $items . '</ul>'
		. '<p class="kit-more"><a href="' . esc_url( home_url( '/directory/' ) ) . '">' . esc_html__( 'All states and districts', 'directoryweb' ) . '</a></p></nav>';
}

// Item pages: the last part of More.
add_filter(
	'render_block_animal-writes/item-more',
	function ( $html, $block, $instance ) {
		$id = (int) ( $instance->context['postId'] ?? get_queried_object_id() );
		if ( ! function_exists( 'aw_item_here' ) || ! aw_item_here( $id ) || 'aw_campaign' === get_post_type( $id ) || ! directoryweb_findhelp_applies( $id ) ) {
			return $html;
		}
		$near = '<div class="aw-findhelp-group">' . directoryweb_findhelp_html( $id, directoryweb_findhelp_places( $id ), 'aw-more-head has-x-large-font-size' ) . '</div>';
		$end  = strrpos( $html, '</div>' );
		return false !== $end && 0 === strpos( ltrim( $html ), '<div class="aw-more">' ) ? substr_replace( $html, $near, $end, 0 ) : $html . '<div class="aw-more">' . $near . '</div>';
	},
	10,
	3
);

// Campaign pages: a band of its own before the Library band (once).
add_filter(
	'render_block_core/group',
	function ( $html, $block ) {
		static $done = false;
		$class = (string) ( $block['attrs']['className'] ?? '' );
		if ( $done || false === strpos( $class, 'aw-camp-slot--library' ) || ! is_singular( 'aw_campaign' ) ) {
			return $html;
		}
		$id = get_queried_object_id();
		if ( ! directoryweb_findhelp_applies( $id ) ) {
			return $html;
		}
		$done   = true;
		$states = directoryweb_findhelp_states_window( $id );
		if ( ! $states ) {
			return $html;
		}
		$band = '<section class="wp-block-group alignfull is-style-kits-section aw-camp-section aw-camp-tint aw-findhelp-band kit-section has-global-padding is-layout-constrained" id="find-help">' . directoryweb_findhelp_html( $id, $states, 'aw-findhelp-head', false ) . '</section>';
		if ( function_exists( 'kits_group_html' ) ) { // a core Group with the Section style, so its padding comes from Styles
			$band = kits_group_html(
				$band,
				array(
					'tagName'   => 'section',
					'align'     => 'full',
					'className' => 'is-style-kits-section aw-camp-section aw-camp-tint aw-findhelp-band kit-section',
					'layout'    => array( 'type' => 'constrained' ),
				)
			);
		}
		return $band . $html;
	},
	10,
	2
);

/* ---------- WP-CLI: places for older items ---------- */

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	/**
	 * Detect places for published News, Library and guides that have none: `wp aw-places detect [--dry-run]
	 * [--type=aw_news] [--samples=10]`. Prints counts per type and samples.
	 *
	 * --redo-auto: also re-detect items whose place was detected (aw_place_source = auto) and store the new result
	 * where it differs (none: the place is removed). A place an editor changed in the Place box (aw_place_source =
	 * editor) is never touched; an older detected place with no source recorded is left alone and counted.
	 * Prints the changed IDs, for purging.
	 *
	 * `wp aw-places mark-auto <id>...`: record items as detected (aw_place_source = auto), unless an editor set them.
	 */
	WP_CLI::add_command(
		'aw-places detect',
		function ( $args, $assoc ) {
			$dry     = ! empty( $assoc['dry-run'] );
			$types   = ! empty( $assoc['type'] ) ? explode( ',', $assoc['type'] ) : array( 'aw_news', 'aw_legal', 'post' );
			$samples = array();
			$want    = (int) ( $assoc['samples'] ?? 10 );
			$redo    = ! empty( $assoc['redo-auto'] );
			$changed = array();
			$key     = function ( $places ) {
				$k = array_map( fn( $p ) => (int) $p[0] . ':' . (int) $p[1], $places );
				sort( $k );
				return implode( ',', $k );
			};
			foreach ( $types as $t ) {
				$c = array( 'items' => 0, 'had' => 0, 'found' => 0, 'district' => 0, 'edited' => 0, 'nosource' => 0, 'states' => array() );
				foreach ( get_posts( array( 'post_type' => $t, 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC' ) ) as $id ) {
					if ( 'post' === $t && ( ! function_exists( 'aw_item_kind' ) || 'guide' !== aw_item_kind( $id ) ) ) { // what an item is: the legacy Core plugin's
						continue;
					}
					++$c['items'];
					$source = (string) get_post_meta( $id, 'aw_place_source', true );
					if ( $redo && ( 'editor' === $source || ( '' === $source && get_post_meta( $id, 'aw_place_auto', true ) ) ) ) {
						++$c[ 'editor' === $source ? 'edited' : 'nosource' ];
						++$c['had'];
						continue;
					}
					if ( $redo && 'auto' === $source ) {
						list( $ss, $dd ) = directoryweb_item_codes( $id );
						$stored          = array_map( fn( $d ) => array( directoryweb_place_district( $d )->state, $d ), array_filter( $dd, 'directoryweb_place_district' ) );
						foreach ( $ss as $s ) {
							if ( ! array_filter( $stored, fn( $p ) => (int) $p[0] === $s ) ) {
								$stored[] = array( $s, 0 );
							}
						}
						$title = get_the_title( $id );
						$new   = directoryweb_places_in_text( $title, get_post_field( 'post_excerpt', $id ) );
						if ( $key( $stored ) !== $key( $new ) ) {
							$changed[] = $id;
							WP_CLI::log( sprintf( '  redo %s %d  %s  %s  →  %s', $t, $id, mb_substr( $title, 0, 80 ), $stored ? $key( $stored ) : 'none', $new ? $key( $new ) : 'none' ) );
							if ( ! $dry ) {
								if ( $new ) {
									directoryweb_set_item_places( $id, $new );
									update_post_meta( $id, 'aw_place_auto', '1' );
								} else {
									delete_post_meta( $id, 'aw_state_code' );
									delete_post_meta( $id, 'aw_district_code' );
									delete_post_meta( $id, 'aw_place_auto' );
								}
							}
						}
						++$c['had'];
						continue;
					}
					if ( ! directoryweb_place_detect_wanted( $id ) ) {
						++$c['had'];
						continue;
					}
					$found = directoryweb_place_detect( $id, ! $dry );
					if ( ! $found ) {
						continue;
					}
					++$c['found'];
					$changed[] = $id;
					$c['district'] += array_filter( $found, fn( $p ) => $p[1] ) ? 1 : 0;
					foreach ( $found as $p ) {
						$c['states'][ $p[0] ] = 1;
					}
					$samples[ $t ][] = $id;
				}
				WP_CLI::log( sprintf( '%s: %d items, %d already had a place, %d %s a place (%d with a district), %d states', $t, $c['items'], $c['had'], $c['found'], $dry ? 'would get' : 'got', $c['district'], count( $c['states'] ) ) );
				if ( $redo ) {
					WP_CLI::log( sprintf( '  left alone: %d set by an editor, %d detected before 24 Oct with no source recorded', $c['edited'], $c['nosource'] ) );
				}
			}
			foreach ( $samples as $t => $ids ) {
				foreach ( array_slice( $ids, 0, $want ) as $id ) {
					$names = array_map( fn( $p ) => $p[1] ? directoryweb_findhelp_place_name( directoryweb_place_district( $p[1] ) ) . ', ' . directoryweb_place_state( $p[0] )->name : directoryweb_place_state( $p[0] )->name, directoryweb_places_in_text( get_the_title( $id ), get_post_field( 'post_excerpt', $id ) ) );
					WP_CLI::log( sprintf( '  %s %d  %s  →  %s', $t, $id, mb_substr( get_the_title( $id ), 0, 90 ), implode( '; ', $names ) ) );
				}
			}
			if ( $changed ) {
				WP_CLI::log( 'Changed IDs: ' . implode( ' ', $changed ) );
			}
			WP_CLI::success( $dry ? 'Dry run: nothing stored.' : 'Stored.' );
		}
	);

	WP_CLI::add_command(
		'aw-places mark-auto',
		function ( $args ) {
			$n = 0;
			foreach ( array_map( 'absint', $args ) as $id ) {
				if ( $id && get_post( $id ) && 'editor' !== get_post_meta( $id, 'aw_place_source', true ) ) {
					update_post_meta( $id, 'aw_place_source', 'auto' );
					++$n;
				}
			}
			WP_CLI::success( sprintf( '%d of %d items recorded as detected (aw_place_source = auto).', $n, count( $args ) ) );
		}
	);
}
