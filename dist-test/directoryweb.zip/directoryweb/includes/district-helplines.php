<?php
/**
 * District helplines (owner, 20 Oct 2026: "fill phone numbers first from official state lists, then build the helpline
 * blocks on the district pages"). On a Directory district page (page 1, no type filter) a block before the list:
 * "Animal helpline numbers in {District}", in the Helplines component (aw-helplines / aw-helpline cards).
 *
 * The cards, in order:
 *   1. 112, the national emergency number (always the first card, the red one).
 *   2. 1962, when the state's "1962 Mobile Veterinary Unit" listing exists (the card links to it).
 *   3. Official district numbers kept in the option aw_district_helplines: district code => list of
 *      {name, number, line, source, url, checked (Y-m-d)}, each from an official page (e.g. the District Animal
 *      Husbandry Offices on ahd.kerala.gov.in).
 *   4. Up to six listings in the district that have a phone number: ambulance and rescue services first, then
 *      government vets, then the rest; listings reported closed are left out. Each card links to its listing, where
 *      the number's source is shown.
 * Legal aid listings are left out. The block shows only when the district has at least one number of its own (3 or 4); 112 and 1962 alone are in the
 * footer already.
 *
 * Helplines row (owner, 12 Nov 2026, D6-3: "animal helpline number {district}" searches sit at positions 7–11 with no
 * clicks): the same district pages show a short row above the toolbar, so the numbers are in the first screen and the
 * count still leads straight into the list: 1962 (when the state has it), then the first official number or listing
 * numbers, three in all, as tap-to-call chips, and "All numbers" to the block under the list.
 *
 * @package directoryweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Services whose listings come first: the ones people call in an emergency. */
const AW_HELPLINE_FIRST = array( 'ambulance', 'emergency-rescue', 'rescue', 'wildlife-rescue', 'bird-treatment' );

/** Official numbers for a district (option aw_district_helplines). */
function directoryweb_district_official_numbers( $code ) {
	$all = get_option( 'aw_district_helplines', array() );
	return is_array( $all ) && ! empty( $all[ (int) $code ] ) ? (array) $all[ (int) $code ] : array();
}

/** A tel: address for a number as printed. */
function directoryweb_helpline_tel( $num ) {
	$n = preg_replace( '/[^\d+]/', '', (string) $num );
	return 'tel:' . $n;
}

/** Listings in a district with a phone, best first. */
function directoryweb_district_helpline_listings( $code, $max = 6 ) {
	static $memo = array(); // the row and the block both ask for the same district in one request
	$key = (int) $code;
	if ( isset( $memo[ $key ] ) ) {
		return array_slice( $memo[ $key ], 0, $max );
	}
	$ids = get_posts(
		array(
			'post_type'   => 'aw_listing',
			'post_status' => 'publish',
			'numberposts' => 200,
			'fields'      => 'ids',
			'meta_query'  => array(
				array( 'key' => 'aw_district_code', 'value' => (int) $code ),
				array( 'key' => 'aw_phones', 'value' => 0, 'compare' => '>', 'type' => 'NUMERIC' ),
			),
		)
	);
	$rows = array();
	foreach ( $ids as $id ) {
		if ( get_post_meta( $id, 'aw_reported_closed', true ) ) {
			continue;
		}
		$num = function_exists( 'directoryweb_listing_first_phone' ) ? directoryweb_listing_first_phone( $id ) : '';
		if ( ! $num ) {
			$p   = directoryweb_listing_phones( $id );
			$num = $p ? $p[0]['number'] : '';
		}
		if ( ! $num ) {
			continue;
		}
		$types = wp_list_pluck( directoryweb_listing_types( $id ), 'slug' );
		if ( in_array( 'legal-aid', $types, true ) ) {
			continue; // legal services authorities help with cases, not with an animal in need
		}
		$svcs  = wp_list_pluck( directoryweb_item_tags( $id, directoryweb_service_slugs() ), 'slug' );
		$rank  = array_intersect( $svcs, AW_HELPLINE_FIRST ) ? 0 : ( array_intersect( $types, AW_VET_TYPES ) ? 1 : 2 );
		$type  = directoryweb_listing_types( $id );
		$rows[] = array( 'id' => $id, 'num' => $num, 'rank' => $rank, 'type' => $type ? $type[0]->name : '' );
	}
	usort( $rows, fn( $a, $b ) => array( $a['rank'], get_the_title( $a['id'] ) ) <=> array( $b['rank'], get_the_title( $b['id'] ) ) );
	$memo[ $key ] = array_slice( $rows, 0, 6 );
	return array_slice( $memo[ $key ], 0, $max );
}

/** One card. */
function directoryweb_helpline_card( $head, $num, $line, $src, $href = '' ) {
	$h = $href ? '<a href="' . esc_url( $href ) . '">' . esc_html( $head ) . '</a>' : esc_html( $head );
	return '<div class="aw-helpline"><h3>' . $h . '</h3><a class="aw-helpline-num" href="' . esc_attr( directoryweb_helpline_tel( $num ) ) . '">' . esc_html( $num ) . '</a>'
		. ( $line ? '<p>' . esc_html( $line ) . '</p>' : '' ) . ( $src ? '<p class="aw-helpline-src">' . $src . '</p>' : '' ) . '</div>';
}

/** The state's published "1962 Mobile Veterinary Unit" listing for a district place, or null. */
function directoryweb_district_mvu( $d ) {
	$state = directoryweb_place_state( $d->state );
	$mvu   = $state ? get_page_by_path( '1962-mobile-veterinary-unit-' . $state->slug, OBJECT, 'aw_listing' ) : null;
	return $mvu && 'publish' === $mvu->post_status ? $mvu : null;
}

/** Whether this request is a district page that shows the helplines (page 1, no type filter). Returns the place or null. */
function directoryweb_district_helplines_place() {
	if ( ! directoryweb_is_directory_view() || get_query_var( 'aw_dir_type' ) || directoryweb_request_type() || (int) get_query_var( 'paged' ) > 1 ) { // page 2 on (as Core's aw_hub_page())
		return null;
	}
	$d = directoryweb_current_place();
	return $d && 'district' === $d->kind ? $d : null;
}

/**
 * The helplines row above the Directory toolbar on a district page, or ''. Three tap-to-call chips (1962 when the
 * state runs it, then the district's own numbers) and a link to the full block under the list. Shown only when the
 * block is (the district has a number of its own).
 */
function directoryweb_district_helplines_row() {
	$d = directoryweb_district_helplines_place();
	if ( ! $d ) {
		return '';
	}
	$own = array();
	foreach ( directoryweb_district_official_numbers( $d->code ) as $o ) {
		$own[] = array( (string) $o['name'], (string) $o['number'] );
	}
	foreach ( directoryweb_district_helpline_listings( $d->code, 3 ) as $r ) {
		$own[] = array( html_entity_decode( get_the_title( $r['id'] ) ), $r['num'] );
	}
	if ( ! $own ) {
		return '';
	}
	$items = directoryweb_district_mvu( $d ) ? array( array( __( 'Mobile Veterinary Units', 'directoryweb' ), '1962' ) ) : array();
	$items = array_slice( array_merge( $items, $own ), 0, 3 );
	$chips = '';
	foreach ( $items as $it ) {
		$chips .= '<a class="kit-chip" href="' . esc_attr( directoryweb_helpline_tel( $it[1] ) ) . '"><span class="aw-dh-row-name">' . esc_html( $it[0] ) . '</span> <strong>' . esc_html( $it[1] ) . '</strong></a>';
	}
	directoryweb_use_style( 'aw-directory' ); // aw-dh-row
	/* translators: %s: district. */
	$label = sprintf( __( 'Animal helpline numbers in %s', 'directoryweb' ), $d->name );
	return '<nav class="kit-tags aw-dh-row" aria-label="' . esc_attr( $label ) . '"><span class="aw-dh-row-label">' . esc_html__( 'Helplines', 'directoryweb' ) . '</span>'
		. $chips . '<a class="aw-dh-row-all" href="#district-helplines">' . esc_html__( 'All numbers', 'directoryweb' ) . '</a></nav>';
}

/** The block for a district place, or ''. */
function directoryweb_district_helplines_html( $d ) {
	$own = '';
	foreach ( directoryweb_district_official_numbers( $d->code ) as $o ) {
		$src  = esc_html( (string) ( $o['source'] ?? '' ) );
		$src  = ! empty( $o['url'] ) ? '<a href="' . esc_url( $o['url'] ) . '" rel="nofollow noopener" target="_blank">' . $src . '</a>' : $src;
		$src .= ! empty( $o['checked'] ) ? ', checked ' . directoryweb_date( $o['checked'], null, 'aw-date' ) : '';
		$own .= directoryweb_helpline_card( (string) $o['name'], (string) $o['number'], (string) ( $o['line'] ?? '' ), $src );
	}
	foreach ( directoryweb_district_helpline_listings( $d->code ) as $r ) {
		$own .= directoryweb_helpline_card( html_entity_decode( get_the_title( $r['id'] ) ), $r['num'], $r['type'], esc_html__( 'From the listing (source on its page)', 'directoryweb' ), get_permalink( $r['id'] ) );
	}
	if ( '' === $own ) {
		return '';
	}
	$cards = directoryweb_helpline_card( __( 'Emergency', 'directoryweb' ), '112', __( 'Police, fire and ambulance, anywhere in India.', 'directoryweb' ), esc_html__( 'Ministry of Home Affairs', 'directoryweb' ) );
	$state = directoryweb_place_state( $d->state );
	$mvu   = directoryweb_district_mvu( $d );
	if ( $mvu ) {
		$cards .= directoryweb_helpline_card( __( 'Mobile Veterinary Units', 'directoryweb' ), '1962', __( 'A vet comes to the animal.', 'directoryweb' ), esc_html( sprintf( '%s animal husbandry department', $state->name ) ), get_permalink( $mvu ) );
	}
	directoryweb_use_style( 'aw-directory' ); // aw-district-helplines, aw-helpline
	$id = 'aw-dh-' . wp_unique_id();
	/* translators: %s: district. */
	return '<section class="aw-district-helplines" id="district-helplines" aria-labelledby="' . esc_attr( $id ) . '"><h2 id="' . esc_attr( $id ) . '">' . esc_html( sprintf( __( 'Animal helpline numbers in %s', 'directoryweb' ), $d->name ) ) . '</h2>'
		. '<div class="aw-helplines">' . $cards . $own . '</div>'
		. '<p class="aw-emergency">' . esc_html__( 'An animal in danger right now: call 112 first.', 'directoryweb' ) . '</p></section>';
}

// After the list on a district page (page 1, no type filter; owner, 21 Oct 2026: the toolbar's count is followed by the list).
add_filter(
	'render_block_core/query',
	function ( $html, $block ) {
		if ( ! function_exists( 'aw_hub_of_query' ) || 'aw_listing' !== aw_hub_of_query( $block['attrs']['queryId'] ?? 0 ) ) { // the hub Query Loops belong to the legacy Core plugin
			return $html;
		}
		$d = directoryweb_district_helplines_place();
		return $d ? $html . directoryweb_district_helplines_html( $d ) : $html;
	},
	9,
	2
);
