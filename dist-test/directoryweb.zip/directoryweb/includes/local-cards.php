<?php
/**
 * Local cards (owner copy, 9 Oct 2026):
 * - (The News item card "Organisations in {State}" was removed with the one item template, owner 20 Oct 2026: an item
 *   page ends with at most two "More" groups.)
 * - Directory district pages, and district × type pages, with 0–2 listings (owner, 25 Oct 2026): a card after the list
 *   with two ways on: "Volunteer near you" (/volunteer/) and "Add an organisation" (Contact, reason "List your
 *   organisation"), plus the whole state.
 *
 * @package directoryweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** One card. */
function directoryweb_local_card( $head, $line, $actions ) {
	directoryweb_use_style( 'aw-directory' ); // aw-local-card
	$id = 'aw-local-' . wp_unique_id();
	return '<aside class="aw-local-card" aria-labelledby="' . esc_attr( $id ) . '"><h2 class="aw-local-card-head" id="' . esc_attr( $id ) . '">' . esc_html( $head ) . '</h2><p>' . esc_html( $line ) . '</p><div class="aw-local-card-actions">' . $actions . '</div></aside>';
}

// District or district × type page with 0–2 listings: the card after the list.
add_filter(
	'render_block_core/query',
	function ( $html, $block ) {
		if ( 'aw_listing' !== ( $block['attrs']['query']['postType'] ?? '' ) || ! function_exists( 'directoryweb_is_directory_view' ) || ! directoryweb_is_directory_view() ) {
			return $html;
		}
		$d = directoryweb_dir_place( (string) get_query_var( 'aw_place' ) );
		if ( ! $d || 'district' !== $d->kind ) {
			return $html;
		}
		$type  = (string) get_query_var( 'aw_dir_type' );
		$types = '' !== $type ? explode( ',', $type ) : array(); // "veterinary" is every AW_VET_TYPES slug, comma-joined (directory.php)
		$vet   = count( $types ) > 1 || 'veterinary' === $type;
		$term  = 1 === count( $types ) && ! $vet ? get_term_by( 'slug', $type, 'post_tag' ) : null;
		if ( $types && ! $vet && ! $term ) {
			return $html;
		}
		$n = 0;
		if ( $types ) {
			foreach ( directoryweb_place_counts()['pairs'] as $p ) { // stored counts, as the robots rule and the sitemap (a listing with two vet types counts twice: the card is then left out, never shown wrongly)
				if ( (int) $p[0] === (int) $d->code && in_array( $p[1], $vet ? AW_VET_TYPES : $types, true ) ) {
					$n += (int) $p[3];
				}
			}
		} else {
			$n = directoryweb_place_count( $d );
		}
		$state = directoryweb_place_state( $d->state );
		if ( $n >= 3 || ! $state ) {
			return $html;
		}
		$what = $vet ? 'veterinary listings' : ( $term ? mb_strtolower( $term->name ) . ' listings' : 'listings' ); // type names are singular ("Rescue Group")
		return $html . directoryweb_local_card(
			sprintf( 'Few %s in %s yet', $what, $d->name ),
			sprintf( 'If there\'s no group near you, you can volunteer to help animals in %s, or tell us about one we\'ve missed.', $d->name ),
			'<a class="kit-btn" href="' . esc_url( home_url( '/volunteer/' ) ) . '">Volunteer near you</a>'
			. '<a class="kit-btn kit-btn--secondary" href="' . esc_url( home_url( '/contact/?about=listing' ) ) . '">Add an organisation</a>'
			. '<a class="kit-btn kit-btn--ghost" href="' . esc_url( directoryweb_directory_url( $state->slug, $vet ? 'veterinary' : $type ) ) . '">' . esc_html( sprintf( 'See all in %s', $state->name ) ) . '</a>'
		);
	},
	10,
	2
);
