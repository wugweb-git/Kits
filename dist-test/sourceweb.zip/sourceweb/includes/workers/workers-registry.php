<?php
/**
 * Sourcing → Workers: the workflow registry (no functions, so the Deploy check can load it alone).
 *
 * @package aw-sourcing
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * The workflows: an exact copy of docs/workers.json in wugweb-git/animal-writes-workers. That repository's test fails when a
 * workflow's name, schedule or timeout changes without that file; tools/ci/workers_registry_check.php fails when this copy
 * differs from it. interval_min: the longest gap between two scheduled runs. runnow: inputs
 * sent by Run now (none: the workflow's own defaults). late_after_h: hours without a report before the workflow is late
 * (null: never late; owner, 24 Oct 2026). Crons are UTC, as in the workflows.
 */
const AW_WORKERS = array(
	'sourcing.yml'             => array(
		'name'         => 'Sourcing workers',
		'what'         => 'Finds News, Library and press items (Google News, feeds), checks relevance, summarises with AI and sends them to the site',
		'crons'        => array( '17 */6 * * *', '47 2-23/6 * * *' ),
		'interval_min' => 210,
		'timeout_min'  => 45,
		'runnow'       => array( 'dry_run' => 'false' ),
		'late_after_h' => 12,
	),
	'summary-rewrite.yml'      => array(
		'name'         => 'Summaries: rewrite those that break the current rules',
		'what'         => 'Rewrites summaries that break Settings → Sourcing → Rules → Summary rules; starts its next run while items remain',
		'crons'        => array( '7,37 * * * *' ),
		'interval_min' => 30,
		'timeout_min'  => 50,
		'late_after_h' => 12,
	),
	'sources-sync.yml'         => array(
		'name'         => 'Sources sync',
		'what'         => 'Copies the site\'s source lists into sources.yaml (the workers\' fallback) when Workers use these lists is on, and the summary rules and Directory schema into summary_rules.json and directory_schema.json; started from the site when the lists are saved, plus once a day',
		'crons'        => array( '23 2 * * *' ),
		'interval_min' => 1440,
		'timeout_min'  => 5,
		'late_after_h' => 36,
	),
	'tests.yml'                => array(
		'name'         => 'Tests',
		'what'         => 'Runs the workers\' tests on every push and after Sources sync; a failure opens an issue (sourcing is not blocked)',
		'crons'        => array(),
		'after'        => 'Sources sync',
		'interval_min' => 1440,
		'timeout_min'  => 15,
		'late_after_h' => null,
	),
	'focus-keywords.yml'       => array(
		'name'         => 'Focus keywords (Rank Math)',
		'what'         => 'Gives items without a Rank Math focus keyword one (AI, or the best words of the SEO title)',
		'crons'        => array( '30 22 * * *' ),
		'interval_min' => 1440,
		'timeout_min'  => 90,
		'late_after_h' => 36,
	),
	'seo-scores.yml'           => array(
		'name'         => 'SEO scores (Rank Math)',
		'what'         => 'Works out Rank Math SEO scores with Rank Math\'s own analyser for items that have a keyword but no score',
		'crons'        => array( '45 23 * * *' ),
		'interval_min' => 1440,
		'timeout_min'  => 30,
		'late_after_h' => 36,
	),
	'directory-enrichment.yml' => array(
		'name'         => 'Directory enrichment',
		'what'         => 'Finds missing contact details for Directory listings (Google Places free quota, OSM, Wikidata, websites) for review',
		'crons'        => array(),
		'after'        => 'SEO scores (Rank Math)',
		'interval_min' => 1440,
		'timeout_min'  => 170,
		'late_after_h' => 36,
	),
	'research.yml'             => array(
		'name'         => 'Research (India, Europe PMC and Crossref)',
		'what'         => 'Finds new Indian animal-welfare papers (Europe PMC, Crossref) for the Library',
		'crons'        => array( '40 3 * * 1' ),
		'interval_min' => 10080,
		'timeout_min'  => 120,
		'runnow'       => array( 'dry_run' => 'false' ),
		'late_after_h' => 216,
	),
	'backup-offsite.yml'       => array(
		'name'         => 'Site backup copy',
		'what'         => 'Copies the site\'s daily database and code backup to a private GitHub release (kept 14 days)',
		'crons'        => array( '30 23 * * *' ),
		'interval_min' => 1440,
		'timeout_min'  => 360,
		'late_after_h' => 36,
	),
	'keepalive.yml'            => array(
		'name'         => 'Keepalive',
		'what'         => 'Switches scheduled workflows back on and commits when the repository has been quiet for 50 days',
		'crons'        => array( '41 3 1 * *' ),
		'interval_min' => 44640,
		'timeout_min'  => 5,
		'late_after_h' => 840,
	),
	'search-insights.yml'      => array(
		'name'         => 'Search Insights: rising terms',
		'what'         => 'Rising terms for Tools → Search Insights → Rising: Trends trending now, Wikipedia and GDELT daily; autocomplete and Trends related weekly; Trends interest monthly',
		'crons'        => array( '40 2 * * *', '0 3 * * 1', '30 3 1 * *' ),
		'interval_min' => 1440,
		'timeout_min'  => 30,
		'runnow'       => array( 'dry_run' => 'false' ),
		'late_after_h' => 36,
	),
	'crawl-check.yml'          => array(
		'name'         => 'Search Insights: crawler access',
		'what'         => 'Asks the site\'s sample pages from outside with each search and AI crawler\'s user agent, plus a 20-page burst; refusals and challenge pages show in Site Health',
		'crons'        => array( '45 3 * * 1' ),
		'interval_min' => 10080,
		'timeout_min'  => 15,
		'runnow'       => array( 'dry_run' => 'false' ),
		'late_after_h' => 192,
	),
);
