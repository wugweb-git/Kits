<?php
/**
 * Workers on time (owner, 31 Oct 2026). GitHub starts scheduled workflows 3 to 6 hours late. Hostinger's cron (hPanel →
 * Advanced → Cron Jobs) runs this every 15 minutes instead:
 *
 *   cd /home/u544169507/domains/animalwrites.in/public_html && /usr/local/bin/wp aw workers-tick >> /home/u544169507/aw-cron.log 2>&1
 *
 * Each workflow in AW_WORKERS (workers-registry.php) whose cron time has come since the last tick is started through
 * GitHub's API (kits_dispatch_workflow, Kits Core ops/cron-health.php) with the input scheduled_cron, so the run
 * behaves as GitHub's scheduled run for that cron. One start per cron, however many slots were missed; a start GitHub
 * refused is tried again at the next tick. WordPress's own cron is not run here: hPanel already runs wp-cron every
 * 5 minutes (cron-health.php, trigger "hostinger").
 *
 * GitHub's own scheduled runs are skipped while the workers repository's variable AW_SCHEDULER is "site"; unset it to go
 * back to GitHub's schedule. This tick replaces the old hPanel job that started sourcing.yml every 4 hours.
 *
 * @package aw-sourcing
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Not started here: keepalive.yml (GitHub's own). */
const AW_TICK_SKIP = array( 'keepalive.yml' );

/** Longest look back for a missed slot (the server cron was down): one day. */
const AW_TICK_LOOKBACK_MIN = 1440;

/** Exponential retry backoff intervals in seconds: 1m, 5m, 15m, 60m. */
const AW_WORKER_BACKOFF_STEPS = array( 60, 300, 900, 3600 );

/**
 * Record a retry backoff interval for a worker after an upstream refusal or error.
 *
 * @param string $worker_id Worker file name or ID.
 * @param int    $http_code HTTP status or error code.
 * @return array Updated backoff record.
 */
function sourceweb_worker_retry_backoff( $worker_id, $http_code = 0 ) {
	$key   = 'aw_w_backoff_' . substr( md5( (string) $worker_id ), 0, 16 );
	$state = get_transient( $key );
	if ( ! is_array( $state ) ) {
		$state = array( 'attempts' => 0, 'until' => 0, 'code' => 0 );
	}
	$attempts = (int) ( $state['attempts'] ?? 0 ) + 1;
	$idx      = min( $attempts - 1, count( AW_WORKER_BACKOFF_STEPS ) - 1 );
	$delay    = AW_WORKER_BACKOFF_STEPS[ $idx ];
	$until    = time() + $delay;
	$new_state = array(
		'worker'   => $worker_id,
		'attempts' => $attempts,
		'until'    => $until,
		'delay'    => $delay,
		'code'     => (int) $http_code,
	);
	set_transient( $key, $new_state, max( $delay * 2, 7200 ) );
	return $new_state;
}

/**
 * Check if a worker is currently inside a retry backoff window.
 *
 * @param string   $worker_id Worker identifier.
 * @param int|null $now       Current timestamp (or null for time()).
 * @return bool
 */
function sourceweb_worker_is_in_backoff( $worker_id, $now = null ) {
	$key   = 'aw_w_backoff_' . substr( md5( (string) $worker_id ), 0, 16 );
	$state = get_transient( $key );
	if ( ! is_array( $state ) || empty( $state['until'] ) ) {
		return false;
	}
	$now = null === $now ? time() : (int) $now;
	return $now < (int) $state['until'];
}

/**
 * Clear a worker's backoff state upon successful dispatch.
 *
 * @param string $worker_id Worker identifier.
 * @return bool
 */
function sourceweb_worker_clear_backoff( $worker_id ) {
	$key = 'aw_w_backoff_' . substr( md5( (string) $worker_id ), 0, 16 );
	return delete_transient( $key );
}

/**
 * True when one cron field matches a value: *, n, a-b, a-b/n, * /n and lists of these.
 *
 * @param string $field Cron field.
 * @param int    $value Minute, hour, day, month or weekday.
 * @param int    $min   Smallest value of the field.
 * @param int    $max   Largest value of the field.
 * @return bool
 */
function sourceweb_tick_field_matches( $field, $value, $min, $max ) {
	foreach ( explode( ',', $field ) as $part ) {
		$step = 1;
		if ( false !== strpos( $part, '/' ) ) {
			list( $part, $step ) = explode( '/', $part, 2 );
			$step                = max( 1, (int) $step );
		}
		if ( '*' === $part ) {
			list( $lo, $hi ) = array( $min, $max );
		} elseif ( false !== strpos( $part, '-' ) ) {
			list( $lo, $hi ) = array_map( 'intval', explode( '-', $part, 2 ) );
		} else {
			$lo = (int) $part;
			$hi = false !== strpos( $field, '/' ) ? $max : $lo; // "5/15" is 5, 20, 35, 50
		}
		if ( $value >= $lo && $value <= $hi && 0 === ( $value - $lo ) % $step ) {
			return true;
		}
	}
	return false;
}

/**
 * True when a five-field cron (UTC) fires at the minute $ts. Day of month and weekday: either one when both are set.
 *
 * @param string $cron Cron.
 * @param int    $ts   Unix time (any second of the minute).
 * @return bool
 */
function sourceweb_tick_cron_matches( $cron, $ts ) {
	$f = preg_split( '/\s+/', trim( $cron ) );
	if ( 5 !== count( $f ) ) {
		return false;
	}
	$dow = (int) gmdate( 'w', $ts );
	$dom = sourceweb_tick_field_matches( $f[2], (int) gmdate( 'j', $ts ), 1, 31 );
	$wd  = sourceweb_tick_field_matches( $f[4], $dow, 0, 7 ) || ( 0 === $dow && sourceweb_tick_field_matches( $f[4], 7, 0, 7 ) );
	$day = ( '*' !== $f[2] && '*' !== $f[4] ) ? ( $dom || $wd ) : ( $dom && $wd );
	return $day && sourceweb_tick_field_matches( $f[0], (int) gmdate( 'i', $ts ), 0, 59 ) && sourceweb_tick_field_matches( $f[1], (int) gmdate( 'G', $ts ), 0, 23 ) && sourceweb_tick_field_matches( $f[3], (int) gmdate( 'n', $ts ), 1, 12 );
}

/**
 * The latest minute in ($after, $now] at which the cron fires, or 0.
 *
 * @param string $cron  Cron (UTC).
 * @param int    $after Unix time: slots after this minute only.
 * @param int    $now   Unix time.
 * @return int
 */
function sourceweb_tick_last_slot( $cron, $after, $now ) {
	$now   -= $now % 60;
	$after  = max( $after - $after % 60, $now - AW_TICK_LOOKBACK_MIN * 60 );
	for ( $t = $now; $t > $after; $t -= 60 ) {
		if ( sourceweb_tick_cron_matches( $cron, $t ) ) {
			return $t;
		}
	}
	return 0;
}

/**
 * Starts the workflows whose cron came since the last tick. Returns lines for the log.
 *
 * @param int           $now      Unix time.
 * @param callable|null $dispatch fn( $file, $inputs ) => true|WP_Error (default kits_dispatch_workflow).
 * @return string[]
 */
function sourceweb_workers_tick( $now, $dispatch = null ) {
	$dispatch = $dispatch ?? 'kits_dispatch_workflow';
	$state    = (array) get_option( 'aw_workers_tick', array() ); // "file|cron" => last slot started; "_last" => last tick
	$last     = (int) ( $state['_last'] ?? 0 );
	$lines    = array();
	foreach ( AW_WORKERS as $file => $w ) {
		if ( in_array( $file, AW_TICK_SKIP, true ) ) {
			continue;
		}
		if ( sourceweb_worker_is_in_backoff( $file, $now ) ) {
			$lines[] = sprintf( '%s %s: skipped (worker is in retry backoff window)', gmdate( 'Y-m-d H:i', $now ), $file );
			continue;
		}
		foreach ( (array) ( $w['crons'] ?? array() ) as $cron ) {
			$key = $file . '|' . $cron;
			// Slots since this cron's last start, else since the last tick; the very first tick looks back 20 minutes only,
			// so switching over does not start every workflow at once.
			$after = (int) ( $state[ $key ] ?? ( $last ? $last : $now - 20 * 60 ) );
			$slot  = sourceweb_tick_last_slot( $cron, $after, $now );
			if ( ! $slot ) {
				continue;
			}
			$res = call_user_func( $dispatch, $file, array( 'scheduled_cron' => $cron ) );
			if ( true === $res ) {
				sourceweb_worker_clear_backoff( $file );
				$state[ $key ] = $slot;
			} else {
				$code = is_wp_error( $res ) ? (int) $res->get_error_data() : 500;
				sourceweb_worker_retry_backoff( $file, $code );
				$state[ $key ] = $slot - 60; // refused: the same slot is tried again after backoff expires
			}
			$lines[] = sprintf( '%s %s (%s, slot %s UTC): %s', gmdate( 'Y-m-d H:i', $now ), $file, $cron, gmdate( 'H:i', $slot ), true === $res ? 'started' : 'NOT started: ' . ( is_wp_error( $res ) ? $res->get_error_message() : 'unknown' ) );
		}
	}
	$state['_last'] = $now;
	update_option( 'aw_workers_tick', $state, false );
	return $lines;
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	/**
	 * `wp aw workers-tick [--dry-run]`: starts the workflows whose time has come (see above). --dry-run: lists what would
	 * start and starts nothing.
	 */
	WP_CLI::add_command(
		'aw workers-tick',
		function ( $args, $assoc ) {
			$dry = ! empty( $assoc['dry-run'] );
			$now = time();
			if ( ! function_exists( 'kits_dispatch_workflow' ) ) {
				WP_CLI::error( 'kits_dispatch_workflow (Kits Core ops/cron-health.php) is needed.' );
			}
			// One tick at a time: two ticks at once would both start the same slot. add_option fails when the lock exists.
			$held = (int) get_option( 'aw_workers_tick_lock', 0 );
			if ( $held && $now - $held < 10 * MINUTE_IN_SECONDS ) {
				WP_CLI::log( gmdate( 'Y-m-d H:i', $now ) . ' another tick is running (since ' . gmdate( 'H:i', $held ) . ' UTC): nothing done' );
				return;
			}
			if ( $held ) {
				delete_option( 'aw_workers_tick_lock' ); // left by a tick that died more than 10 minutes ago
			}
			if ( ! $dry && ! add_option( 'aw_workers_tick_lock', $now, '', false ) ) {
				WP_CLI::log( gmdate( 'Y-m-d H:i', $now ) . ' another tick started at the same moment: nothing done' );
				return;
			}
			$saved = get_option( 'aw_workers_tick', array() );
			$lines = sourceweb_workers_tick( $now, $dry ? fn() => true : null );
			if ( $dry ) {
				update_option( 'aw_workers_tick', $saved, false ); // a dry run moves nothing on
				$lines = array_map( fn( $l ) => str_replace( ': started', ': would start', $l ), $lines );
			}
			if ( ! $dry ) {
				delete_option( 'aw_workers_tick_lock' );
			}
			foreach ( $lines as $line ) {
				WP_CLI::log( $line );
			}
			WP_CLI::success( count( $lines ) . ( $dry ? ' would start.' : ' started or tried.' ) );
		}
	);
}
