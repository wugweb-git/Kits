<?php
/**
 * SourceWeb: an "About SourceWeb" Help tab and a sidebar on every SourceWeb screen (WP_Screen::add_help_tab). Screens
 * that have their own help keep it; this tab sits beside it.
 *
 * @package aw-sourcing
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'current_screen', 'sourceweb_src_help_tab' );

/**
 * Add the tab when the open admin page is one of SourceWeb's.
 *
 * @param WP_Screen $screen The screen.
 */
function sourceweb_src_help_tab( $screen ) {
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which screen is open; nothing is saved.
	if ( '' === $page || ! is_object( $screen ) ) {
		return;
	}
	$ours = in_array( $page, array( 'aw-review', 'aw-enrich-review' ), true );
	foreach ( array( 'aw-sourcing' ) as $start ) {
		$ours = $ours || 0 === strpos( $page, $start );
	}
	if ( ! $ours ) {
		return;
	}
	$screens = array(
		__( 'Overview', 'sourceweb' ) => __( 'what came in, what waits and what the workers did', 'sourceweb' ),
		__( 'To review, Enrichment review', 'sourceweb' ) => __( 'approve or reject what the workers found', 'sourceweb' ),
		__( 'Sources, Keywords, Rules', 'sourceweb' ) => __( 'what is fetched and what is kept', 'sourceweb' ),
		__( 'AI models', 'sourceweb' ) => __( 'which free models do which job, with daily caps', 'sourceweb' ),
	);
	$list = '';
	foreach ( $screens as $label => $what ) {
		$list .= '<li><strong>' . esc_html( $label ) . '</strong>: ' . esc_html( $what ) . '</li>';
	}
	$screen->add_help_tab(
		array(
			'id'       => 'aw_src-about',
			/* translators: %s: plugin name. */
			'title'    => sprintf( __( 'About %s', 'sourceweb' ), 'SourceWeb' ),
			'content'  => '<p>' . esc_html__( 'What the news workers fetch and how it arrives: sources and feeds, keywords, rules, the review queues and the worker endpoints.', 'sourceweb' ) . '</p><ul>' . $list . '</ul>',
			'priority' => 5,
		)
	);
	$main_file = defined( 'SOURCEWEB_FILE' ) ? SOURCEWEB_FILE : ( file_exists( SOURCEWEB_SOURCING_DIR . 'sourceweb.php' ) ? SOURCEWEB_SOURCING_DIR . 'sourceweb.php' : SOURCEWEB_SOURCING_DIR . 'aw-sourcing.php' );
	$data      = function_exists( 'get_file_data' ) ? get_file_data( $main_file, array( 'Version' => 'Version' ) ) : array();
	$screen->set_help_sidebar(
		'<p><strong>SourceWeb</strong>' . ( empty( $data['Version'] ) ? '' : ' ' . esc_html( $data['Version'] ) ) . '</p>'
		. '<p><a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">' . esc_html__( 'Plugins', 'sourceweb' ) . '</a></p>'
		. '<p><a href="https://wugweb.com" target="_blank" rel="noopener noreferrer">Wugweb<span class="screen-reader-text"> ' . esc_html__( '(opens in a new tab)', 'sourceweb' ) . '</span></a></p>'
	);
}
