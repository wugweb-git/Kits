<?php
/**
 * The site's forms in Fluent Forms (free) and FluentCRM (free), built with their own features (owner, 21 Oct 2026).
 * Newsletter #3, Contact #4, Volunteer sign-up #5, Claim this listing #6, Report a mistake #7 (inactive),
 * Newsletter (full) #9. Fields, conditions, hidden fields, confirmation (with the reference
 * {submission.serial_number}) and each form's Fluent Forms → FluentCRM link are Fluent Forms settings, versioned in
 * /forms/*.json and put on a site with tools/forms/forms.php. Requests are Fluent Forms entries (favourite = needs
 * action, notes = what was done); people are FluentCRM contacts.
 *
 * Custom code here, only where the plugins cannot do it:
 * - Three custom fields: the spam check (ALTCHA, no third party), PIN code → State → District (the official LGD list;
 *   District follows State) and the private upload (claim logo and proof: stored outside the web, opened by an
 *   administrator from the entry's link).
 * - After each form's FluentCRM link: what a link cannot do. A Contact sender who left the newsletter unticked still
 *   becomes a contact (transactional, tag contact-form) with the message as a note; a claimant becomes a contact
 *   (transactional, tag claimant); every contact gets the newsletter box as 1/0 ("Newsletter box (last form)"); a
 *   volunteer's State, District and PIN code from the LGD picker go into their Volunteer fields.
 * - The site's look on Fluent Forms fields (icons, tick-box styles, the browser rules forms.js checks with).
 * - kits_ff_form() shows each form. Fluent Forms is the only form since 25 Oct 2026 (owner): the site's own forms and
 *   their submit handlers were removed, so a missing form shows nothing to visitors and a short note to administrators.
 * - Emails: none since 21 Oct 2026 (owner): nothing is sent when a Fluent Forms form is submitted (kits_ff_mail_off).
 *
 * Moved from Animal Writes Core `includes/forms-fluentforms.php` (18 Nov 2026); options, meta keys, tags, hooks and
 * slugs are unchanged, and the old function names still work (back-compat wrappers).
 *
 * @package kits-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// No email from a Fluent Forms submission, to anyone (owner, 21 Oct 2026): Fluent Forms' own email notifications are
// switched off, and while a submission is handled every wp_mail is dropped (the contact@ alerts for messages,
// volunteers and claims, the newsletter confirmation, any opt-in email). Entries are still saved where they always are.
// On again: Kits → Modules → Emails from forms (or wp option update aw_ff_send_email 1)
function kits_ff_mail_off() {
	return '1' !== (string) get_option( 'aw_ff_send_email', '0' );
}
add_filter(
	'fluentform/global_notification_active_types',
	function ( $keys ) {
		if ( kits_ff_mail_off() ) {
			unset( $keys['notifications'] );
		}
		return $keys;
	},
	999
);
add_action(
	'fluentform/before_insert_submission',
	function () {
		if ( kits_ff_mail_off() ) {
			add_filter( 'pre_wp_mail', '__return_true', 999 ); // "handled": nothing is sent
		}
	},
	0
);

const KITS_FF_OPTION = 'aw_ff_forms'; // key => Fluent Forms form ID
const KITS_FF_FORMS  = array(
	'contact'     => array( 'title' => 'Contact', 'thanks' => 'contact', 'limit' => 5 ),
	'volunteer'   => array( 'title' => 'Volunteer sign-up', 'thanks' => 'volunteer', 'limit' => 5 ),
	'claim'       => array( 'title' => 'Claim this listing', 'thanks' => 'claim', 'limit' => 5 ),
	'report'      => array( 'title' => 'Report a mistake', 'thanks' => 'report', 'limit' => 10 ),
);
/** What the custom fields post (Fluent Forms keeps only fields it knows, plus these). */
const KITS_FF_EXTRA = array( 'aw_t', 'aw_source', 'kits_hp', 'altcha', 'pincode', 'state', 'district', 'logo_token', 'proof_token', 'photo_tokens' );
/** Private uploads: field => most files (photo_tokens: comma-separated tokens; owner, 31 Oct 2026). */
const KITS_FF_UPLOADS = array( 'logo_token' => 1, 'proof_token' => 1, 'photo_tokens' => 5 );

/** Indian phone fields (owner, 31 Oct 2026): +91 shown before the box, 10 digits typed, saved as "+91 98765 43210". */
const KITS_FF_PHONES = array( 'phone', 'whatsapp', 'org_phone', 'l_phone1', 'l_phone2', 'l_phone3' );

/** Claim form social fields => [listing field, link before the username] (the username alone is typed). */
const KITS_FF_SOCIAL = array(
	'l_instagram' => array( 'aw_instagram', 'https://www.instagram.com/%s/' ),
	'l_facebook'  => array( 'aw_facebook', 'https://www.facebook.com/%s' ),
	'l_x'         => array( 'aw_x', 'https://x.com/%s' ),
	'l_youtube'   => array( 'aw_youtube', 'https://www.youtube.com/@%s' ),
	'l_linkedin'  => array( 'aw_linkedin', 'https://www.linkedin.com/company/%s' ),
);

/** Claim form dates: typed and shown in the site's format ("8 Oct 2026"), saved as Y-m-d. */
const KITS_FF_DATES = array( 'l_reg_date', 'l_awbi_rec', 'l_awbi_ren', 'l_awbi_valid' );

/** An Indian number's 10 digits ('' when it is not one): +91, 91 or 0 before it, spaces and dashes allowed. */
if ( ! function_exists( 'kits_ff_phone10' ) ) {
	function kits_ff_phone10( $v ) {
		$d = preg_replace( '/\D+/', '', (string) $v );
		if ( 12 === strlen( $d ) && 0 === strpos( $d, '91' ) ) {
			$d = substr( $d, 2 );
		} elseif ( 11 === strlen( $d ) && '0' === $d[0] ) {
			$d = substr( $d, 1 );
		}
		return preg_match( '/^[1-9]\d{9}$/', $d ) ? $d : '';
	}
}

/** A number as the site saves it: "+91 98765 43210"; anything else unchanged. */
if ( ! function_exists( 'kits_ff_phone_store' ) ) {
	function kits_ff_phone_store( $v ) {
		$d = kits_ff_phone10( $v );
		return '' !== $d ? '+91 ' . substr( $d, 0, 5 ) . ' ' . substr( $d, 5 ) : trim( (string) $v );
	}
}

/** Each social field's own hosts and the path before the username in its links. */
const KITS_FF_SOCIAL_HOSTS = array(
	'l_instagram' => array( 'instagram\.com', '' ),
	'l_facebook'  => array( '(?:facebook|fb)\.com', '' ),
	'l_x'         => array( '(?:x|twitter)\.com', '' ),
	'l_youtube'   => array( 'youtube\.com', '@' ),
	'l_linkedin'  => array( 'linkedin\.com', 'company/' ), // a person's /in/ profile is not reduced: kept as a link
);

/** A social link or "@name" as the username alone ('' when it is not a username or a link of that field's platform). */
if ( ! function_exists( 'kits_ff_social_user' ) ) {
	function kits_ff_social_user( $field, $v ) {
		$v = trim( (string) $v );
		if ( preg_match( '#^(?:https?://)?(?:[a-z]+\.)?[a-z.]+\.[a-z]+/#i', $v ) ) { // a link: only this platform's, in its username form
			$h = KITS_FF_SOCIAL_HOSTS[ $field ] ?? null;
			if ( ! $h || ! preg_match( '#^(?:https?://)?(?:[a-z]+\.)?' . $h[0] . '/' . preg_quote( $h[1], '#' ) . '([A-Za-z0-9._-]{1,100})/?(?:[?\#].*)?$#i', $v, $m ) ) {
				return '';
			}
			$v = $m[1];
		}
		$v = ltrim( $v, '@' );
		return preg_match( '/^[A-Za-z0-9._-]{1,100}$/', $v ) ? $v : '';
	}
}

/** A date typed as "8 Oct 2026" (or 2026-10-08) as Y-m-d; '' when it cannot be read. */
function kits_ff_date_ymd( $v ) {
	$v = trim( (string) $v );
	if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m ) ) {
		return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? $v : ''; // a real calendar date only (not 2026-99-99)
	}
	foreach ( array( '!j M Y', '!j F Y' ) as $fmt ) {
		$d = date_create_immutable_from_format( $fmt, $v );
		$e = date_get_last_errors();
		if ( $d && ( ! $e || ( ! $e['warning_count'] && ! $e['error_count'] ) ) ) { // "31 Feb 2026" is a warning (it would roll over): refused
			return $d->format( 'Y-m-d' );
		}
	}
	return '';
}

/** The form's values as saved (phones +91, claim usernames, claim dates Y-m-d). */
function kits_ff_normalise( $data ) {
	if ( array_key_exists( 'org_listing', $data ) ) { // the Organisation picked from the Directory: only a published listing; its own name
		$lid                 = function_exists( 'aw_org_listing_ok' ) && kits_ff_ticked( $data, 'org_assoc' ) ? aw_org_listing_ok( $data['org_listing'] ) : 0;
		$data['org_listing'] = $lid ? (string) $lid : '';
		if ( $lid ) {
			$data['org_name'] = html_entity_decode( get_the_title( $lid ), ENT_QUOTES );
		}
	}
	if ( kits_ff_ticked( $data, 'wa_same' ) && '' !== trim( (string) ( $data['phone'] ?? '' ) ) ) {
		$data['whatsapp'] = (string) $data['phone']; // "Same as my phone" (entries before 12 Nov 2026)
	}
	if ( kits_ff_ticked( $data, 'wa_optin' ) && '' === trim( (string) ( $data['whatsapp'] ?? '' ) ) && '' !== trim( (string) ( $data['phone'] ?? '' ) ) ) {
		$data['whatsapp'] = (string) $data['phone']; // one Mobile field; "On WhatsApp" ticked = it is their WhatsApp (owner, 12 Nov 2026)
	}
	foreach ( KITS_FF_PHONES as $k ) {
		if ( isset( $data[ $k ] ) && is_string( $data[ $k ] ) && '' !== trim( $data[ $k ] ) ) {
			$data[ $k ] = kits_ff_phone_store( $data[ $k ] );
		}
	}
	foreach ( array_keys( KITS_FF_SOCIAL ) as $k ) {
		$u = isset( $data[ $k ] ) && is_string( $data[ $k ] ) ? kits_ff_social_user( $k, $data[ $k ] ) : '';
		if ( '' !== $u ) {
			$data[ $k ] = $u;
		}
	}
	foreach ( KITS_FF_DATES as $k ) {
		$d = isset( $data[ $k ] ) && is_string( $data[ $k ] ) ? kits_ff_date_ymd( $data[ $k ] ) : '';
		if ( '' !== $d ) {
			$data[ $k ] = $d;
		}
	}
	return $data;
}

/** The Fluent Forms form ID for a form key, or 0 (Fluent Forms off, or the form not set up: nothing shows). */
function kits_ff_id( $key ) {
	if ( ! defined( 'FLUENTFORM' ) ) {
		return 0;
	}
	return (int) ( ( (array) get_option( KITS_FF_OPTION, array() ) )[ $key ] ?? 0 );
}

/** The form key of a Fluent Forms form, or '' when it is not one of these five. */
function kits_ff_key( $form ) {
	$id = (int) ( is_object( $form ) ? $form->id : $form );
	foreach ( (array) get_option( KITS_FF_OPTION, array() ) as $k => $fid ) {
		if ( $id && (int) $fid === $id && isset( KITS_FF_FORMS[ $k ] ) ) {
			return $k;
		}
	}
	return '';
}

/** A form that gets the site's look: the site's forms and Newsletter (full) #9 (the footer box #3 keeps its own). */
function kits_ff_styled( $form ) {
	$id = (int) ( is_object( $form ) ? $form->id : $form );
	return '' !== kits_ff_key( $form ) || ( $id && (int) get_option( 'aw_nl_ff_form_full' ) === $id );
}

/**
 * Whether a Fluent Forms form is being rendered inside one of the site's kit wrappers ([data-kit-form]); set by the
 * wrapper around its do_shortcode() call (kits_ff_kit_wrap()). Such a form gets the kit field icons (owner, 2 Nov 2026).
 */
function kits_ff_in_kit_wrap() {
	return ! empty( $GLOBALS['kits_ff_kit_wrap'] );
}

/**
 * A Fluent Forms shortcode rendered as a kit-wrapped form (the field icons above).
 *
 * @param string $shortcode The [fluentform …] shortcode.
 * @return string
 */
function kits_ff_kit_wrap( $shortcode ) {
	$GLOBALS['kits_ff_kit_wrap'] = true;
	$html                      = do_shortcode( $shortcode );
	$GLOBALS['kits_ff_kit_wrap'] = false;
	return $html;
}

/**
 * A form part's stylesheet from the site's component sheets (the theme layer's kits_use_component_style(), when it is
 * loaded; without it nothing is added).
 *
 * @param string $handle Component sheet handle.
 */
function kits_ff_style( $handle ) {
	if ( function_exists( 'kits_use_component_style' ) ) {
		kits_use_component_style( $handle );
	}
}

/** What a form is shown for (listing, item, source, the update link's contact), while it renders. */
function kits_ff_ctx( $k = null ) {
	$c = (array) ( $GLOBALS['kits_ff_ctx'] ?? array() );
	return null === $k ? $c : ( $c[ $k ] ?? null );
}

/* ---------- Showing the form ---------- */

/**
 * A form, as Fluent Forms renders it, in the site's wrapper (the same classes, so the same look and analytics).
 * Without Fluent Forms or the form's ID (wp aw ff-form): nothing for visitors, a short note for administrators.
 *
 * @param string $key Form key (KITS_FF_FORMS).
 * @param array  $ctx What the form is shown for: listing, item, reason, source, vol_contact.
 * @return string
 */
if ( ! function_exists( 'kits_ff_form' ) ) {
	function kits_ff_form( $key, $ctx = array() ) {
		$id = kits_ff_id( $key );
		if ( ! $id ) {
			return kits_ff_missing( KITS_FF_FORMS[ $key ]['title'] ?? $key, 'wp aw ff-form ' . $key . ' <form ID>' );
		}
		kits_ff_style( 'aw-forms' ); // the kit-form aw-form-ff wrapper
		if ( 'volunteer' === $key ) {
			kits_ff_style( 'aw-volunteer' ); // aw-volunteer-form, aw-vol-roles, aw-vol-role
		}
		$GLOBALS['kits_ff_ctx'] = (array) $ctx + array( 'key' => $key );
		$form                 = do_shortcode( '[fluentform id="' . $id . '"]' );
		$GLOBALS['kits_ff_ctx'] = array();
		$attrs                = '';
		if ( 'contact' === $key ) { // the message placeholder follows the reason (aw.js); #write is the contact form's anchor
			$attrs = ' id="write" data-placeholders="' . esc_attr( wp_json_encode( AW_CONTACT_PLACEHOLDER ) ) . '"';
		}
		$listing = $ctx['listing'] ?? null;
		if ( $listing ) {
			$attrs .= ' data-key="' . esc_attr( (string) $listing->ID ) . '"';
		}
		return '<div class="kit-form aw-form-ff aw-' . esc_attr( str_replace( '_', '-', $key ) ) . '-form" data-kit-form="' . esc_attr( $key ) . '"' . $attrs . '>' . $form . '</div>';
	}
}

/** A form that cannot show (Fluent Forms off, or its ID not set): nothing for visitors, a note for administrators. */
function kits_ff_missing( $title, $fix ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return '';
	}
	return '<p class="aw-form-missing"><strong>Only administrators see this:</strong> the ' . esc_html( $title ) . ' form is missing. '
		. ( defined( 'FLUENTFORM' ) ? 'Set its Fluent Forms ID: <code>' . esc_html( $fix ) . '</code>.' : 'Turn on Fluent Forms.' ) . '</p>';
}

// No browser bubbles: Fluent Forms and the site's messages show the errors.
add_filter( 'fluentform/html_attributes', fn( $a, $form ) => kits_ff_key( $form ) ? $a + array( 'novalidate' => 'novalidate' ) : $a, 10, 2 );

/** The page path a submission comes from (S5.8): the listing's page for claims and reports, else the page. */
function kits_ff_source() {
	$listing = kits_ff_ctx( 'listing' );
	if ( $listing ) {
		return trim( wp_make_link_relative( (string) get_permalink( $listing ) ), '/' );
	}
	$src = (string) kits_ff_ctx( 'source' );
	return '' !== $src ? $src : kits_form_source();
}

/** A Fluent Forms-shaped field group around our own control (so its error messages land in the same place). */
function kits_ff_group( $id, $label, $control, $o = array() ) {
	$opt  = empty( $o['required'] ) ? ' <span class="kit-optional">(optional)</span>' : '';
	$hint = empty( $o['hint'] ) ? '' : '<div class="ff-el-help-message ff_ahm">' . esc_html( $o['hint'] ) . '</div>';
	$icon = empty( $o['icon'] ) ? '' : '<span class="kit-ico kit-ico--' . esc_attr( $o['icon'] ) . ' kit-field-icon" aria-hidden="true"></span>';
	return '<div class="ff-el-group kit-field ' . esc_attr( $o['class'] ?? '' ) . '">'
		. ( '' !== $label ? '<div class="ff-el-input--label"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . $opt . '</label></div>' : '' )
		. '<div class="ff-el-input--content"' . ( empty( $o['data_name'] ) ? '' : ' data-name="' . esc_attr( $o['data_name'] ) . '"' ) . '>' . $hint
		. ( $icon ? '<div class="kit-field-control">' . $icon . $control . '</div>' : $control ) . '</div></div>';
}

/* ---------- The custom fields Fluent Forms (free) has no equivalent for ---------- */

// Three, used in the forms' JSON like any field: the spam check (ALTCHA: no third party, no cookies), PIN code → State
// → District from the official LGD list (District follows State), and the private upload (claim logo and proof).
add_action(
	'init',
	function () {
		if ( ! class_exists( '\FluentForm\App\Services\FormBuilder\BaseFieldManager' ) ) {
			return;
		}
		$fields = array(
			'aw_places' => array( 'PIN code, State and District', 'kits_ff_render_places' ),
			'aw_check'  => array( 'Spam check (ALTCHA)', 'kits_ff_render_check' ),
			'aw_logo'   => array( 'Private upload (logo, proof)', 'kits_ff_render_logo' ),
		);
		foreach ( $fields as $key => $f ) {
			new class( $key, $f[0], $f[1] ) extends \FluentForm\App\Services\FormBuilder\BaseFieldManager {
				private $cb;
				public function __construct( $key, $title, $cb ) {
					$this->cb = $cb;
					parent::__construct( $key, $title, array( 'animal writes' ), 'advanced' );
				}
				public function pushFormInputType( $types ) {
					return $types; // posts its own inputs (see KITS_FF_EXTRA); not an entry column of its own
				}
				public function getComponent() {
					return array(
						'index'          => 90,
						'element'        => $this->key,
						'attributes'     => array( 'name' => $this->key ),
						'settings'       => array( 'label' => $this->title, 'container_class' => '', 'html_codes' => '<p>' . esc_html( $this->title ) . ' (Animal Writes)</p>', 'conditional_logics' => array() ),
						'editor_options' => array( 'title' => $this->title, 'icon_class' => 'ff-edit-html', 'template' => 'customHTML' ),
					);
				}
				public function getGeneralEditorElements() {
					return array( 'label' );
				}
				public function getAdvancedEditorElements() {
					return array( 'container_class' );
				}
				public function render( $element, $form ) {
					echo call_user_func( $this->cb, $element, $form ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped where it is built
				}
			};
		}
	},
	5
);

/** PIN code → State and District (LGD), as in places.php: the PIN fills both (aw.js); never a typed state. Setting
 *  "required": "no" (the Newsletter form) makes the state optional. */
function kits_ff_render_places( $element, $form ) {
	$need = 'no' !== ( $element['settings']['required'] ?? 'yes' );
	$who  = kits_ff_ctx( 'vol_contact' ); // the update link: their State and PIN code to start with
	$cf   = $who ? (array) $who->custom_fields() : array();
	$f    = 'ff' . (int) $form->id;
	$dict = kits_field_dict();
	$pin  = $dict['pincode'];
	$pid  = $f . '-pincode';
	$a    = '';
	foreach ( array_merge( $pin['attrs'], array( 'placeholder' => $pin['placeholder'] ) ) as $k => $v ) {
		$a .= ' ' . esc_attr( $k ) . '="' . esc_attr( (string) $v ) . '"';
	}
	$html  = kits_ff_group( $pid, 'PIN code', '<input type="text" id="' . esc_attr( $pid ) . '" name="pincode" class="ff-el-form-control" value="' . esc_attr( (string) ( $cf['vol_pincode'] ?? '' ) ) . '" aria-describedby="' . esc_attr( $pid ) . '-error"' . $a . '><span class="kit-field-message kit-field-error" id="' . esc_attr( $pid ) . '-error" aria-live="polite"></span>', array( 'icon' => $pin['icon'], 'class' => 'aw-form-ff-half' ) );
	$sid   = $f . '-state';
	$did   = $f . '-district';
	$opts  = '<option value="">Choose a state</option>';
	foreach ( aw_place_states() as $st ) {
		$opts .= '<option value="' . esc_attr( $st->slug ) . '"' . selected( (string) ( $cf['vol_state'] ?? '' ), $st->name, false ) . '>' . esc_html( $st->name ) . '</option>';
	}
	$html .= kits_ff_group( $sid, 'State', '<select id="' . esc_attr( $sid ) . '" name="state" class="ff-el-form-control"' . ( $need ? ' required data-msg-required="Choose a state"' : '' ) . ' autocomplete="address-level1" data-district-select="' . esc_attr( $did ) . '">' . $opts . '</select>', array( 'required' => $need, 'class' => 'aw-form-ff-half' ) );
	$opts  = '<option value="" data-none="Choose a state first" data-all="Choose a district">Choose a state first</option>';
	foreach ( aw_place_states() as $st ) {
		$opts .= '<optgroup label="' . esc_attr( $st->name ) . '" data-state="' . esc_attr( $st->slug ) . '" hidden disabled>';
		foreach ( aw_place_districts( $st->code ) as $d ) {
			$opts .= '<option value="' . esc_attr( $d->slug ) . '">' . esc_html( $d->name ) . '</option>';
		}
		$opts .= '</optgroup>';
	}
	$html .= kits_ff_group( $did, 'District', '<select id="' . esc_attr( $did ) . '" name="district" class="ff-el-form-control" autocomplete="address-level2" disabled>' . $opts . '</select>', array( 'class' => 'aw-form-ff-half' ) );
	return '<div class="aw-ff-places">' . $html . '</div>'; // PIN, State, District as one row from 768 (owner, 31 Oct 2026)
}

/** The spam check: ALTCHA (no third party, no cookies), plus the site's timing, honeypot and source fields. */
function kits_ff_render_check( $element, $form ) {
	$widget = str_replace( '<div class="kit-captcha"', '<div class="kit-captcha" data-placed', kits_altcha_widget() ); // stays here, above Send
	return '<div class="ff-el-group aw-form-ff-check"><div class="ff-el-input--content" data-name="altcha">'
		. '<input type="hidden" name="aw_t" value="' . esc_attr( (string) time() ) . '">'
		. '<input type="hidden" name="aw_source" value="' . esc_attr( kits_ff_source() ) . '">'
		. '<p class="kit-hp" aria-hidden="true"><label>Leave this empty <input type="text" name="kits_hp" tabindex="-1" autocomplete="off"></label></p>'
		. $widget . '</div></div>';
}

/** A private upload: picked → checked and sent at once to the private folder (aw.js), the form then carries its token
 *  (several, comma-separated, for photo_tokens). The field's name (KITS_FF_UPLOADS), label and help come from the form. */
function kits_ff_render_logo( $element, $form ) {
	$name = isset( KITS_FF_UPLOADS[ $element['attributes']['name'] ?? '' ] ) ? $element['attributes']['name'] : 'logo_token';
	$max  = KITS_FF_UPLOADS[ $name ];
	$id   = 'ff' . (int) $form->id . '-' . $name;
	$d    = kits_field_dict()['logo'];
	$ctl  = '<input type="file" id="' . esc_attr( $id ) . '" accept="' . esc_attr( $d['attrs']['accept'] ) . '" data-max-bytes="' . (int) $d['attrs']['data-max-bytes'] . '" data-msg-file="' . esc_attr( $d['attrs']['data-msg-file'] ) . '" data-aw-upload="' . esc_url( admin_url( 'admin-ajax.php?action=aw_ff_upload' ) ) . '"' . ( $max > 1 ? ' multiple data-max-files="' . (int) $max . '" data-msg-files="' . esc_attr( 'Choose up to ' . $max . ' pictures.' ) . '"' : '' ) . ' aria-describedby="' . esc_attr( $id ) . '-error">'
		. '<input type="hidden" name="' . esc_attr( $name ) . '" value="">'
		. '<span class="kit-field-message kit-field-error" id="' . esc_attr( $id ) . '-error" aria-live="polite"></span>';
	$label = wp_strip_all_tags( (string) ( $element['settings']['label'] ?? 'Logo' ) );
	$hint  = (string) ( $element['settings']['help_message'] ?? 'PNG, JPG or WebP, up to 8 MB.' );
	return kits_ff_group( $id, $label, $ctl, array( 'hint' => $hint, 'data_name' => $name ) );
}

/* ---------- Fluent Forms fields: the site's look ---------- */

/** The Volunteer form's ways to help => Kits icon (owner, 31 Oct 2026). */
/** An icon before each choice: field name => ( option value => Kits icon ). Tiles and chips use the same map. */
const KITS_FF_OPTION_ICONS = array(
	'roles'        => array( 'coordinate' => 'campaign', 'letters' => 'send', 'rescue' => 'injured', 'creative' => 'share', 'legal' => 'legal' ),
	'availability' => array( 'weekdays' => 'calendar', 'weekends' => 'sun', 'evenings' => 'moon', 'emergencies' => 'siren' ),
	'travel_range' => array( '5km' => 'map-pin', 'district' => 'map', 'state' => 'landmark', 'anywhere' => 'world' ),
	'skills'       => array( 'first_aid' => 'briefcase-medical', 'driving' => 'car', 'foster' => 'home', 'photo_video' => 'camera', 'social' => 'share', 'languages' => 'languages' ),
);

/** Icons inside fields, as the site's own forms have them. Social link boxes take the "Elsewhere" icons (aw_social_icon, pages.php). */
const KITS_FF_ICONS = array(
	'name'         => 'name',
	'email'        => 'mail',
	'l_email'      => 'mail',
	'phone'        => 'phone',
	'whatsapp'     => 'brand-whatsapp',
	'org_name'     => 'building',
	'org_phone'    => 'phone',
	'l_phone1'     => 'phone',
	'l_phone2'     => 'phone',
	'l_phone3'     => 'phone',
	'org_district' => 'map-pin',
	'city'         => 'map-pin',
	'l_maps'       => 'map-pin',
	'org_website'  => 'world',
	'l_website'    => 'world',
	'opp_link'     => 'link',
	'page'         => 'link',
	'l_volunteer'  => 'link',
	'l_adopt'      => 'link',
);

foreach ( array( 'input_text', 'input_email', 'input_url', 'textarea', 'select', 'input_checkbox', 'input_radio', 'input_hidden' ) as $kits_ff_el ) {
	// The step check (forms.js) uses the browser's rules with the site's words.
	add_filter(
		'fluentform/rendering_field_data_' . $kits_ff_el,
		function ( $data, $form ) {
			if ( ! kits_ff_styled( $form ) ) {
				return $data;
			}
			$rules = (array) ( $data['settings']['validation_rules'] ?? array() );
			if ( in_array( $data['element'] ?? '', array( 'input_text', 'input_email', 'input_url', 'textarea', 'select' ), true ) && empty( $data['settings']['conditional_logics']['status'] ) ) {
				if ( ! empty( $rules['required']['value'] ) ) {
					$data['attributes']['required']          = 'required';
					$data['attributes']['data-msg-required'] = (string) $rules['required']['message'];
				}
				if ( ! empty( $rules['email']['value'] ) ) {
					$data['attributes']['data-msg-email'] = (string) $rules['email']['message'];
				}
			}
			$data = function_exists( 'kits_ff_update_values' ) ? kits_ff_update_values( $data, $form ) : $data; // the update link (volunteers.php)
			$name = (string) ( $data['attributes']['name'] ?? '' );
			if ( 'org_name' === $name && 'volunteer' === kits_ff_key( $form ) ) { // the Directory picker (aw.js, org-people.php)
				kits_ff_style( 'aw-directory' ); // aw.js adds aw-org-host and aw-org-list
				$data['attributes']['data-aw-org-search'] = admin_url( 'admin-ajax.php?action=aw_org_search' );
			}
			if ( in_array( $name, KITS_FF_PHONES, true ) && is_string( $data['attributes']['value'] ?? null ) && '' !== kits_ff_phone10( $data['attributes']['value'] ) ) {
				$data['attributes']['value'] = kits_ff_phone10( $data['attributes']['value'] ); // the 10 digits after the "+91" in front of the box
			}
			return $data;
		},
		10,
		2
	);
	add_filter(
		'fluentform/rendering_field_html_' . $kits_ff_el,
		function ( $html, $data, $form ) {
			if ( ! kits_ff_styled( $form ) ) { // a form in a kit wrapper ([data-kit-form]) gets the field icons only
				$name = is_array( $data ) ? (string) ( $data['attributes']['name'] ?? '' ) : '';
				$icon = KITS_FF_ICONS[ $name ] ?? '';
				return kits_ff_in_kit_wrap() && $icon && is_array( $data ) && in_array( $data['element'] ?? '', array( 'input_text', 'input_email', 'input_url' ), true ) && empty( $data['settings']['prefix_label'] )
					? (string) preg_replace( '/(<input\b[^>]*>)/', '<div class="kit-field-control"><span class="kit-ico kit-ico--' . $icon . ' kit-field-icon" aria-hidden="true"></span>$1</div>', $html, 1 )
					: $html;
			}
			if ( ! is_array( $data ) ) { // Fluent Forms passes the markup in place of the field for tick boxes
				$data = array( 'element' => false !== strpos( $html, 'ff-el-form-check' ) ? 'input_checkbox' : '', 'attributes' => array( 'name' => preg_match( '/name=[\'"]([a-z_]+)/', $html, $m ) ? $m[1] : '' ) );
			}
			$name = (string) ( $data['attributes']['name'] ?? '' );
			$el   = $data['element'] ?? '';
			if ( in_array( $el, array( 'input_checkbox', 'input_radio' ), true ) || false !== strpos( $html, 'ff-el-form-check' ) ) { // the site's tick boxes (and the volunteer cards)
				$cls  = 'roles' === rtrim( $name, '[]' ) ? ' kit-checkbox aw-vol-role' : ' kit-checkbox';
				$html = str_replace( "class='ff-el-form-check-label", "class='ff-el-form-check-label" . $cls, $html );
			}
			if ( in_array( $el, array( 'input_checkbox', 'input_radio' ), true ) && preg_match( '#<div class=[\'"]ff-el-input--label[^>]*>\s*<label\b([^>]*)>#', $html, $lm ) ) { // a group of ticks or choices: named by its label (WCAG 1.3.1)
				$gid = preg_match( '#\bid=[\'"]([^\'"]+)#', $lm[1], $im ) ? $im[1] : 'aw-g-' . (int) $form->id . '-' . sanitize_key( rtrim( $name, '[]' ) );
				if ( empty( $im ) ) {
					$html = (string) preg_replace( '#(<div class=[\'"]ff-el-input--label[^>]*>\s*)<label\b#', '$1<label id="' . $gid . '"', $html, 1 );
				}
				$html = (string) preg_replace( '#<div class=([\'"])ff-el-input--content\1#', '<div role="' . ( 'input_radio' === $el ? 'radiogroup' : 'group' ) . '" aria-labelledby="' . $gid . '" class=$1ff-el-input--content$1', $html, 1 );
			}
			$opt_icons = KITS_FF_OPTION_ICONS[ rtrim( $name, '[]' ) ] ?? array(); // each choice with its icon: role tiles, chips and the segment
			foreach ( $opt_icons as $val => $ico ) {
				$html = (string) preg_replace( '#(value=[\'"]' . preg_quote( $val, '#' ) . '[\'"][^>]*>)(\s*)<span>#', '$1$2<span class="kit-ico kit-ico--' . $ico . ' aw-ff-opt-ico" aria-hidden="true"></span><span>', $html, 1 );
			}
			$prefix = (string) ( $data['settings']['prefix_label'] ?? '' );
			$social = '' !== $prefix && '+91' !== $prefix ? aw_social_icon( $prefix ) : '';
			$icon   = KITS_FF_ICONS[ $name ] ?? ( '' === $prefix ? '' : ( '+91' === $prefix ? 'phone' : ( '' !== $social ? $social : 'world' ) ) );
			$boxes  = array( 'input_text', 'input_email', 'input_url' );
			if ( $icon && '' !== $prefix && in_array( $el, $boxes, true ) ) { // the icon, then the fixed part ("+91", "instagram.com/") as plain text inside the same box
				$value = $data['attributes']['value'] ?? '';
				$link  = '' !== $social && is_string( $value ) && preg_match( '#^(?:https?://)?(?:[a-z]+\.)?[a-z.]+\.[a-z]+/#i', $value ); // a full link already: no "facebook.com/" before it
				$html  = (string) preg_replace(
					'#<div class=[\'"]ff_input-group[\'"]>\s*<div class=[\'"]ff_input-group-prepend[\'"]>\s*<span class=[\'"]ff_input-group-text[\'"]>.*?</span>\s*</div>\s*(<input\b[^>]*>)\s*</div>#s',
					$link
						? '<div class="kit-field-control"><span class="kit-ico kit-ico--' . $icon . ' kit-field-icon" aria-hidden="true"></span>$1</div>'
						: '<div class="kit-field-control aw-ff-prefixed" style="--aw-ff-prefix:' . ( mb_strlen( $prefix ) + 1 ) . 'ch"><span class="kit-ico kit-ico--' . $icon . ' kit-field-icon" aria-hidden="true"></span><span class="aw-ff-prefix" aria-hidden="true">' . esc_html( $prefix ) . '</span>$1</div>',
					$html,
					1
				);
			} elseif ( $icon && in_array( $el, $boxes, true ) ) {
				$html = preg_replace( '/(<input\b[^>]*>)/', '<div class="kit-field-control"><span class="kit-ico kit-ico--' . $icon . ' kit-field-icon" aria-hidden="true"></span>$1</div>', $html, 1 );
			}
			return $html;
		},
		10,
		3
	);
}

/* ---------- Submitting ---------- */

// The values the FluentCRM links and the follow-up below see: the same as saved (+91 numbers and so on).
add_filter( 'fluentform/submission_form_data', fn( $data, $insert_id, $form ) => kits_ff_key( $form ) ? kits_ff_normalise( (array) $data ) : $data, 10, 3 );

// The custom fields' inputs are kept with the entry.
add_filter( 'fluentform/white_listed_fields', fn( $f, $form_id ) => kits_ff_key( $form_id ) ? array_merge( $f, KITS_FF_EXTRA ) : $f, 10, 2 );

/** Was a Fluent Forms tick box ticked? Fluent Forms saves nothing for an unticked box: empty is 0. */
function kits_ff_ticked( $data, $name ) {
	return (bool) array_filter( (array) ( $data[ $name ] ?? array() ), fn( $v ) => '' !== (string) $v && '0' !== (string) $v );
}

/** An upload for this form (its token), as a file in the private folder, or ''. */
function kits_ff_logo_file( $token ) {
	$token = (string) $token;
	return preg_match( '/^[a-f0-9]{32}$/', $token ) && is_file( kits_private_dir() . '/tmp-' . $token . '.png' ) ? 'tmp-' . $token . '.png' : '';
}

/** An upload moved from its temporary name to its own, or ''. */
function kits_ff_keep_upload( $token ) {
	$file = kits_ff_logo_file( $token );
	if ( ! $file ) {
		return '';
	}
	$final = wp_generate_password( 20, false ) . '.png';
	return rename( kits_private_dir() . '/' . $file, kits_private_dir() . '/' . $final ) ? $final : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- a rename inside our own private folder; WP_Filesystem::move() may need FTP credentials here.
}

/** A submission's reference: the form's prefix and Fluent Forms' serial number for the entry (AW-12, AW-C-3 …). */
function kits_ff_ref( $key, $entry_id ) {
	$prefix = array( 'contact' => 'AW-', 'volunteer' => 'AW-V-', 'claim' => 'AW-C-', 'report' => 'AW-R-' );
	if ( ! class_exists( '\FluentForm\App\Models\Submission' ) ) {
		return ''; // Fluent Forms is off: no serial number to give
	}
	$serial = (int) \FluentForm\App\Models\Submission::where( 'id', (int) $entry_id )->value( 'serial_number' );
	return $serial ? ( $prefix[ $key ] ?? 'AW-' ) . $serial : '';
}

/**
 * The custom fields' own checks: a real State and District from the LGD picker (the Volunteer form needs a state) and
 * an upload that arrived. Everything else (required, email, web address) is Fluent Forms' own validation.
 */
function kits_ff_errors( $key, $data ) {
	$errors = array();
	if ( 'volunteer' === $key ) {
		$errors = array_intersect_key( kits_volunteer_errors( kits_volunteer_values( $data ) ), array_flip( array( 'state', 'district', 'pincode' ) ) );
	}
	$lid  = 'claim' === $key ? absint( $data['listing'] ?? 0 ) : 0;
	$have = $lid && function_exists( 'aw_listing_phones' ) ? array_map( fn( $r ) => preg_replace( '/\D+/', '', $r['number'] ), aw_listing_phones( $lid ) ) : array();
	foreach ( KITS_FF_PHONES as $k ) {
		$v = trim( (string) ( is_string( $data[ $k ] ?? '' ) ? ( $data[ $k ] ?? '' ) : '' ) );
		if ( '' !== $v && '' === kits_ff_phone10( $v ) && ! in_array( preg_replace( '/\D+/', '', $v ), $have, true ) ) { // a listing's own number may stay as it is (helplines like 1962)
			$errors[ $k ] = in_array( $k, array( 'phone', 'whatsapp' ), true ) ? 'Enter 10 digits.' : 'Enter a 10-digit number, like 9876543210.'; // Mobile wording: owner, 12 Nov 2026
		}
	}
	if ( 'claim' === $key ) {
		foreach ( array_keys( KITS_FF_SOCIAL ) as $k ) {
			$v = trim( (string) ( $data[ $k ] ?? '' ) );
			$own = (bool) preg_match( '#^(?:https?://)?(?:[a-z]+\.)?' . KITS_FF_SOCIAL_HOSTS[ $k ][0] . '/#i', $v ); // a link of this platform the box cannot reduce (a channel, an /in/ profile) is kept
			if ( '' !== $v && '' === kits_ff_social_user( $k, $v ) && ! $own ) {
				$errors[ $k ] = 'Enter the username only, like animalwrites.';
			}
		}
		foreach ( KITS_FF_DATES as $k ) {
			$v = trim( (string) ( $data[ $k ] ?? '' ) );
			if ( '' !== $v && '' === kits_ff_date_ymd( $v ) ) {
				$errors[ $k ] = 'Enter a date like 8 Oct 2026.';
			}
		}
		$y = trim( (string) ( $data['l_founded'] ?? '' ) );
		if ( '' !== $y && ! preg_match( '/^(18|19|20)\d{2}$/', $y ) ) {
			$errors['l_founded'] = 'Enter a year, like 2010.';
		}
	}
	foreach ( KITS_FF_UPLOADS as $up => $max ) {
		$tokens = array_filter( explode( ',', (string) ( $data[ $up ] ?? '' ) ) );
		if ( count( $tokens ) > $max || array_filter( $tokens, fn( $t ) => ! kits_ff_logo_file( $t ) ) ) {
			$errors[ $up ] = 1 < $max ? 'Add up to ' . $max . ' pictures again: one was not received.' : 'Add this file again: it was not received.';
		}
	}
	return $errors;
}

/** Rate-limit key: per form and connection (the key the site's own forms used, so counts carry on). */
function kits_ff_rl( $key ) {
	return 'aw_rl_aw_' . $key . '_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
}

add_filter(
	'fluentform/validation_errors',
	function ( $errors, $data, $form, $fields ) {
		$key = kits_ff_key( $form );
		if ( ! $key ) {
			return $errors;
		}
		// Bots (honeypot filled, or sent within 3 seconds) see a success; nothing is saved.
		if ( ! empty( $data['kits_hp'] ) || ( time() - (int) ( $data['aw_t'] ?? 0 ) ) < 3 ) {
			wp_send_json_success( array( 'insert_id' => 0, 'result' => array( 'redirectUrl' => kits_thanks_url( KITS_FF_FORMS[ $key ]['thanks'] ), 'message' => '' ) ) );
		}
		foreach ( kits_ff_errors( $key, $data ) as $field => $msg ) {
			if ( empty( $errors[ $field ] ) ) {
				$errors[ $field ] = array( 'aw' => $msg );
			}
		}
		if ( $errors ) {
			return $errors; // the ALTCHA answer is checked (and used up) only when everything else is right
		}
		if ( (int) get_transient( kits_ff_rl( $key ) ) >= KITS_FF_FORMS[ $key ]['limit'] ) {
			return array( 'aw_form' => array( 'aw' => 'Too many tries. Wait a minute, then try again.' ) );
		}
		if ( ! kits_altcha_verify( (string) ( $data['altcha'] ?? '' ) ) ) {
			return array( 'altcha' => array( 'aw' => 'Couldn\'t verify you\'re not a bot. Try again.' ) );
		}
		return $errors;
	},
	20,
	4
);

// The private uploads (claim logo, photos and proof): on submit each file moves from its temporary name to its own, and the
// entry keeps a link only an administrator can open (aw_ff_file) in place of each token (photos: comma-separated links).
add_filter(
	'fluentform/insert_response_data',
	function ( $data, $form_id ) {
		if ( ! kits_ff_key( $form_id ) ) {
			return $data;
		}
		$data = kits_ff_normalise( $data ); // phones +91, claim usernames and dates as saved
		foreach ( KITS_FF_UPLOADS as $up => $max ) {
			$links = array();
			foreach ( array_slice( array_filter( explode( ',', (string) ( $data[ $up ] ?? '' ) ) ), 0, $max ) as $token ) {
				$file = kits_ff_keep_upload( $token );
				if ( $file ) {
					$links[] = add_query_arg( array( 'action' => 'aw_ff_file', 'f' => $file ), admin_url( 'admin-post.php' ) );
				}
			}
			if ( $links ) {
				$data[ $up ] = implode( ',', $links );
			}
		}
		return $data;
	},
	10,
	2
);
add_action(
	'admin_post_aw_ff_file',
	function () {
		$file = basename( sanitize_file_name( wp_unslash( $_GET['f'] ?? '' ) ) ); // phpcs:ignore WordPress.Security.NonceVerification -- administrators only, read only
		$path = kits_private_dir() . '/' . $file;
		if ( ! current_user_can( 'edit_aw_volunteers' ) || ! preg_match( '/^[A-Za-z0-9]{20}\.png$/', $file ) || ! is_file( $path ) ) {
			wp_die( 'Not allowed.', 403 );
		}
		nocache_headers();
		header( 'Content-Type: image/png' );
		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}
);

// Each send counts towards the per-connection limit (kits_ff_rl()). What happens next for the sender's contact is
// MailWeb's (mailweb/includes/fluentcrm.php, the same hook and priority).
add_action(
	'fluentform/submission_inserted',
	function ( $entry_id, $data, $form ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundBeforeLastUsed -- the hook's arguments
		$key = kits_ff_key( $form );
		if ( $key ) {
			set_transient( kits_ff_rl( $key ), (int) get_transient( kits_ff_rl( $key ) ) + 1, HOUR_IN_SECONDS );
		}
	},
	20,
	3
);

/** The upload (claim logo and proof): checked like the site's own form, kept in the private folder until sent. */
function kits_ff_upload() {
	nocache_headers();
	$rl = 'aw_rl_aw_ff_upload_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	if ( (int) get_transient( $rl ) >= 20 ) { // a claim can send 7 (logo, 5 photos, proof)
		wp_send_json_error( 'Too many tries. Wait a minute, then try again.' );
	}
	$logo = $_FILES['logo'] ?? null; // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput -- checked in aw_claim_logo_ok()
	$why = dw_claim_upload_error( $logo );
	if ( '' !== $why ) {
		wp_send_json_error( $why );
	}
	foreach ( (array) glob( kits_private_dir() . '/tmp-*.png' ) as $old ) { // uploads never sent with a claim go after a day
		if ( $old && filemtime( $old ) < time() - DAY_IN_SECONDS ) {
			wp_delete_file( $old );
		}
	}
	$token = bin2hex( random_bytes( 16 ) );
	if ( ! aw_claim_logo_store( $logo['tmp_name'], 'tmp-' . $token . '.png' ) ) {
		wp_send_json_error( 'We could not read this picture. Try another file, or a smaller one.' );
	}
	set_transient( $rl, (int) get_transient( $rl ) + 1, HOUR_IN_SECONDS );
	wp_send_json_success( array( 'token' => $token ) );
}
add_action( 'wp_ajax_nopriv_aw_ff_upload', 'kits_ff_upload' );
add_action( 'wp_ajax_aw_ff_upload', 'kits_ff_upload' );

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	// wp aw ff-form <key> <id>: which Fluent Forms form shows as the site's <key> form (a setup tool: needed again
	// whenever a form is rebuilt with a new ID). The forms themselves are built in Fluent Forms and versioned in
	// /forms/*.json (tools/forms/forms.php).
	WP_CLI::add_command(
		'aw ff-form',
		function ( $args ) {
			$key = (string) ( $args[0] ?? '' );
			$id  = (int) ( $args[1] ?? 0 );
			if ( ! isset( KITS_FF_FORMS[ $key ] ) || ! $id ) {
				WP_CLI::error( 'Use: wp aw ff-form <' . implode( '|', array_keys( KITS_FF_FORMS ) ) . '> <form ID>' );
			}
			$ids         = (array) get_option( KITS_FF_OPTION, array() );
			$ids[ $key ] = $id;
			update_option( KITS_FF_OPTION, $ids, false );
			WP_CLI::success( "{$key}: form {$id}" );
		}
	);
}

// Pages whose own content shows a form (contact, volunteer, claim, report, and the thank-you page, which shows the full
// newsletter form after a footer sign-up): Fluent Forms' stylesheets keep blocking there, so the form near the top never
// shows unstyled (kits-core performance.php).
add_filter(
	'kits_page_has_form',
	fn( $has ) => $has || ( is_singular() && preg_match( '/\[aw_(contact_form|claim_page|report_page|volunteer_update|thank_you)|wp:animal-writes\/volunteer/', (string) get_post_field( 'post_content', get_queried_object_id() ) ) )
);
