<?php
/**
 * Campaign letters: anonymous statistics and the opt-in at send (owner, 17 Oct 2026; Privacy Policy section 7,
 * "Campaign actions and sign-ups"). The letter itself still goes from the visitor's own email; we never receive it.
 *
 * - Anonymous statistics: each time a letter is sent from the letter tool ([aw_letter_tool], campaign.js), one row in
 *   {prefix}aw_camp_letters: campaign, the city as typed (trimmed, title case), the grounds ticked, the route (gmail,
 *   outlook, mailto, copy), the device type (phone, tablet, desktop, from the screen width), the date, and the
 *   newsletter box and the WhatsApp tick as 1/0 (owner, 21 Oct 2026). No name, email or IP address is read or kept.
 *   Kept to report on campaigns.
 * - At send: name, city and email are required, WhatsApp is optional with its own tick. Every sender joins the
 *   newsletter and the volunteers in FluentCRM (Newsletter list, tags newsletter, volunteer, campaign-<slug>), whatever
 *   the box says (owner, 18 Oct 2026), through FluentCRM's own API (aw_crm_campaign_signer), with the box as 1/0, the
 *   WhatsApp number and tick, and a reference (AW-L-<n>) shown to them after sending.
 * - Bot check on the sign-up (audit item 4, owner 25 Oct 2026): the site's own ALTCHA (proof of work in the visitor's
 *   browser; no third party, no cookies, nothing about the visitor kept), on both the Fluent Forms Campaign form and the
 *   older endpoint below. No double opt-in (owner: every sender joins).
 * - WP Admin → Campaigns → Letter report: totals, by city, by ground, by route, by device and by day, with a CSV export
 *   of the anonymous rows.
 *
 * @package kits-core
 *
 * SITE MODULE (Animal Writes only): not part of the generic Kits Core product. It stays in this plugin for now because the Campaign form handler (forms/campaign-form.php) calls aw_cl_* and AW_CL_* straight, so the two move together;
 * moving it to the theme's site layer (assets/site/) would break that load order. Listed in docs/awcore-retirement.md (not in this repo) §7.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const AW_CL_DB_VERSION = '3'; // 2: nl_optin and wa_optin (owner, 21 Oct 2026); 3: send_id, one row per letter from either call
const AW_CL_OPTIN      = 'Email me updates on this campaign and future Animal Writes campaigns, and add me as a volunteer. I can unsubscribe at any time.';
const AW_CL_CONSENT    = 'v3-campaign-optin-volunteer-preticked'; // the wording above; ticked by default, newsletter and volunteers (owner, 18 Oct 2026)
const AW_CL_ROUTES     = array( 'gmail' => 'Gmail', 'outlook' => 'Outlook', 'mailto' => 'Email app', 'copy' => 'Copied' );
const AW_CL_DEVICES    = array( 'phone' => 'Phone', 'tablet' => 'Tablet', 'desktop' => 'Desktop' );
/**
 * Anonymous rows the open /letter call adds per campaign per minute (audit item 5, owner 25 Oct 2026, option b). No IP
 * address is read: the cap is per campaign. The busiest day so far (24 Oct 2026) had 744 letters, about 0.5 a minute.
 * A letter over the cap still gets its row from the sign-up call, which carries the same send_id and needs ALTCHA.
 */
const AW_CL_LETTER_CAP = 30;

function aw_cl_table() {
	global $wpdb;
	return $wpdb->prefix . 'aw_camp_letters';
}

add_action(
	'init',
	function () {
		if ( AW_CL_DB_VERSION === get_option( 'aw_camp_letters_db' ) ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta(
			'CREATE TABLE ' . aw_cl_table() . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			campaign_id bigint(20) unsigned NOT NULL,
			city varchar(60) NOT NULL DEFAULT '',
			grounds varchar(120) NOT NULL DEFAULT '',
			route varchar(20) NOT NULL DEFAULT '',
			device varchar(10) NOT NULL DEFAULT '',
			sent_on date NOT NULL,
			nl_optin tinyint(1) NULL,
			wa_optin tinyint(1) NULL,
			send_id char(16) NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY send_id (send_id),
			KEY campaign (campaign_id, sent_on)
			) {$wpdb->get_charset_collate()};"
		);
		update_option( 'aw_camp_letters_db', AW_CL_DB_VERSION, false );
	},
	5
);

/** The next signer reference number (AW-L-<n>), one series for every campaign. */
function aw_cl_next_ref() {
	global $wpdb;
	add_option( 'aw_cl_ref', 0, '', false );
	$wpdb->query( "UPDATE {$wpdb->options} SET option_value = option_value + 1 WHERE option_name = 'aw_cl_ref'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	wp_cache_delete( 'aw_cl_ref', 'options' );
	return (int) $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'aw_cl_ref'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

/** A box sent by campaign.js ('1' / '0') as 1 or 0. */
function aw_cl_tick( $v ) {
	return '1' === (string) $v ? 1 : 0;
}

/** A city as typed, tidied: trimmed, single spaces, title case, at most 60 characters. */
function aw_cl_city( $city ) {
	$city = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $city ) ) );
	return mb_substr( mb_convert_case( mb_strtolower( $city ), MB_CASE_TITLE ), 0, 60 );
}

/** Ground numbers as "1,2,6" (1-99, unique, sorted). */
function aw_cl_grounds( $grounds ) {
	$n = array_unique( array_filter( array_map( 'intval', is_array( $grounds ) ? $grounds : explode( ',', (string) $grounds ) ), fn( $g ) => $g > 0 && $g < 100 ) );
	sort( $n );
	return implode( ',', $n );
}

/** The campaign's grounds as written on its page (the list with class aw-letter-grounds): number => short label. */
function aw_cl_ground_labels( $campaign ) {
	$html = (string) get_post_field( 'post_content', $campaign );
	if ( ! preg_match( '#<ol class="wp-block-list aw-letter-grounds">(.*?)</ol>#s', $html, $m ) ) {
		return array();
	}
	preg_match_all( '#<li>(.*?)</li>#s', $m[1], $li );
	$out = array();
	foreach ( $li[1] as $i => $t ) {
		$out[ $i + 1 ] = preg_match( '#<strong>(.*?)</strong>#s', $t, $s ) ? rtrim( wp_strip_all_tags( $s[1] ), ': ' ) : wp_trim_words( wp_strip_all_tags( $t ), 8 );
	}
	return $out;
}

/** A random id campaign.js makes for one letter (16 hex characters), or '' when it sent none (an older cached script). */
function aw_cl_send_id( $v ) {
	return preg_match( '/^[a-f0-9]{16}$/', (string) $v ) ? (string) $v : '';
}

/**
 * The anonymous row for one letter. Both calls (letter and optin) carry it, so the row is saved when either arrives; the
 * send_id keeps it to one row (INSERT IGNORE on its unique key). The send_id is never stored with the person.
 */
function aw_cl_record_letter( $id, $req ) {
	global $wpdb;
	$route  = sanitize_key( (string) $req['route'] );
	$device = sanitize_key( (string) $req['device'] );
	$send   = aw_cl_send_id( $req['send_id'] );
	$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->prepare(
			'INSERT IGNORE INTO ' . aw_cl_table() . ' (campaign_id, city, grounds, route, device, sent_on, nl_optin, wa_optin, send_id) VALUES (%d, %s, %s, %s, %s, %s, %d, %d, ' . ( $send ? '%s' : 'NULL' ) . ')', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- the table name is the plugin's own; every value is a placeholder
			...array_merge(
				array(
					$id,
					aw_cl_city( $req['city'] ),
					aw_cl_grounds( $req['grounds'] ),
					isset( AW_CL_ROUTES[ $route ] ) ? $route : '',
					isset( AW_CL_DEVICES[ $device ] ) ? $device : '',
					wp_date( 'Y-m-d', null, new DateTimeZone( 'Asia/Kolkata' ) ),
					aw_cl_tick( $req['nl_optin'] ),
					aw_cl_tick( $req['wa_optin'] ),
				),
				$send ? array( $send ) : array()
			)
		)
	);
}

/**
 * The sign-up's bot check (audit item 4, owner 25 Oct 2026): the site's own ALTCHA (kits-core altcha.php), solved in the
 * letter tool while the visitor fills it in. One solved check covers one letter (send_id): the Fluent Forms Campaign
 * form and the older endpoint below both accept it, and a retried call for the same letter is not asked again.
 *
 * @param string $send    The letter's send_id ('' when the script sent none).
 * @param string $payload The ALTCHA answer.
 * @return bool
 */
function aw_cl_human( $send, $payload ) {
	if ( $send && get_transient( 'aw_cl_h_' . $send ) ) {
		return true;
	}
	if ( ! function_exists( 'kits_altcha_verify' ) || ! kits_altcha_verify( (string) $payload ) ) {
		return false;
	}
	if ( $send ) {
		set_transient( 'aw_cl_h_' . $send, 1, HOUR_IN_SECONDS );
	}
	return true;
}

/* ---------- REST: a letter sent (anonymous), and the opt-in ---------- */
add_action(
	'rest_api_init',
	function () {
		$open = function ( $id ) {
			$id = aw_camp_id( (int) $id );
			return $id && 'publish' === get_post_status( $id ) && aw_camp_is_open( $id ) ? $id : 0;
		};
		register_rest_route(
			'aw/v1',
			'/campaign/(?P<id>\d+)/letter',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => function ( WP_REST_Request $req ) use ( $open ) {
					$id = $open( $req['id'] );
					if ( ! $id ) {
						return new WP_Error( 'aw_closed', 'Not open', array( 'status' => 404 ) );
					}
					// One counter per campaign: [minute, rows in that minute].
					$min = (int) floor( time() / MINUTE_IN_SECONDS );
					$cap = get_transient( 'aw_cl_cap_' . $id );
					$n   = is_array( $cap ) && (int) ( $cap[0] ?? 0 ) === $min ? (int) ( $cap[1] ?? 0 ) : 0;
					if ( $n >= AW_CL_LETTER_CAP ) {
						return new WP_Error( 'aw_letter_busy', 'Busy. Try again in a minute.', array( 'status' => 429 ) );
					}
					set_transient( 'aw_cl_cap_' . $id, array( $min, $n + 1 ), 2 * MINUTE_IN_SECONDS );
					aw_cl_record_letter( $id, $req );
					return array( 'ok' => true );
				},
			)
		);
		register_rest_route(
			'aw/v1',
			'/campaign/(?P<id>\d+)/optin',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => function ( WP_REST_Request $req ) use ( $open ) {
					$raw = function_exists( 'aw_raw_save' ) ? aw_raw_save( 'campaign-old', (int) $req['id'], $req->get_params() ) : 0; // the raw copy, before any check (campaign-form.php)
					$id    = $open( $req['id'] );
					$email = sanitize_email( (string) $req['email'] );
					if ( ! $id ) {
						return new WP_Error( 'aw_closed', 'Not open', array( 'status' => 404 ) );
					}
					if ( ! is_email( $email ) || ! function_exists( 'aw_crm_campaign_signer' ) ) {
						return new WP_Error( 'aw_optin', 'Check the email address.', array( 'status' => 400 ) );
					}
					$name    = mb_substr( sanitize_text_field( (string) $req['name'] ), 0, 80 );
					$city    = aw_cl_city( $req['city'] );
					$slug    = get_post_field( 'post_name', $id );
					// Every sender joins the newsletter and the volunteers, box ticked or not (owner, 18 Oct 2026); the box is
					// recorded as 1/0 (it was dropped before 21 Oct 2026). FluentCRM's own API; no team email.
					$wa  = trim( sanitize_text_field( (string) $req['whatsapp'] ) );
					$wa  = '' !== $wa && kits_clean_phone( $wa ) ? kits_clean_phone( $wa ) : substr( $wa, 0, 20 );
					// the letter's row too, in case its own call was lost (only when this script sent the letter's fields)
					$send = aw_cl_send_id( $req['send_id'] );
					if ( $send && '' !== (string) $req['route'] ) {
						aw_cl_record_letter( $id, $req );
					}
					// a retried call (the first answer lost) gets the same reference, not a new one
					$ref = $send ? get_transient( 'aw_cl_s_' . $send ) : '';
					if ( $ref ) {
						return array( 'ok' => true, 'ref' => $ref );
					}
					// At most 20 new sign-ups an hour from one connection, counted as the site's forms count theirs
					// (kits_form_guard; plugin audit 4). A retried call above is not counted.
					$rl = 'aw_rl_campaign-optin_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
					if ( (int) get_transient( $rl ) >= 20 ) {
						return new WP_Error( 'aw_optin_limit', 'Too many tries. Wait a minute, then try again.', array( 'status' => 429 ) );
					}
					if ( ! aw_cl_human( $send, (string) $req['altcha'] ) ) {
						return new WP_Error( 'aw_optin_check', 'Couldn\'t verify you\'re not a bot. Try again.', array( 'status' => 403 ) );
					}
					$ref = 'AW-L-' . aw_cl_next_ref();
					if ( $send ) {
						set_transient( 'aw_cl_s_' . $send, $ref, DAY_IN_SECONDS );
					}
					aw_crm_campaign_signer( $email, $name, $city, $slug, 1 === aw_cl_tick( $req['consent'] ), $wa, 1 === aw_cl_tick( $req['wa_optin'] ), $ref, AW_CL_CONSENT );
					if ( function_exists( 'kits_form_count' ) ) {
						kits_form_count( $rl );
					}
					if ( $raw ) {
						aw_raw_mark( $raw, 'saved' );
					}
					return array( 'ok' => true, 'ref' => $ref );
				},
			)
		);
	}
);

/* ---------- WP Admin: Campaigns → Letter report ---------- */
add_action(
	'admin_menu',
	fn() => add_submenu_page( 'edit.php?post_type=aw_campaign', 'Letter report', 'Letter report', 'edit_posts', 'aw-letter-report', 'aw_cl_report_page' )
);

/** Campaigns with letters, newest first: [id => title]. */
function aw_cl_campaigns() {
	global $wpdb;
	$out = array();
	foreach ( (array) $wpdb->get_col( 'SELECT campaign_id FROM ' . aw_cl_table() . ' GROUP BY campaign_id ORDER BY MAX(id) DESC' ) as $cid ) { // phpcs:ignore
		$out[ (int) $cid ] = get_the_title( (int) $cid );
	}
	return $out;
}

add_filter(
	'kits_frame_extra_screens',
	function ( $screens ) {
		$screens['aw-letter-report'] = array( 'edit_posts', '' );
		return $screens;
	}
);

/** Campaigns → Letter report, in the Kits frame (admin-kits-frame.php). */
function aw_cl_report_page() {
	kits_frame_screen( 'aw-letter-report', 'Letter report', 'aw_cl_report_body' );
}

/** What the Letter report prints inside the frame. */
function aw_cl_report_body() {
	global $wpdb;
	$all = aw_cl_campaigns();
	$cid = isset( $_GET['campaign'] ) ? absint( $_GET['campaign'] ) : (int) array_key_first( $all ); // phpcs:ignore WordPress.Security.NonceVerification
	$t   = aw_cl_table();
	echo '<p class="description">One row each time a letter is sent from a campaign\'s letter tool: the city as typed, the grounds, how it was sent, the device type and the date. No names, emails or IP addresses. "Letters sent" on the campaign counts the "Yes, I sent it" clicks.</p>';
	if ( ! $all ) {
		echo '<p>No letters recorded yet.</p>';
		return;
	}
	echo '<form method="get"><input type="hidden" name="post_type" value="aw_campaign"><input type="hidden" name="page" value="aw-letter-report"><label for="aw-cl-c">Campaign </label><select id="aw-cl-c" name="campaign">';
	foreach ( $all as $id => $title ) {
		echo '<option value="' . (int) $id . '"' . selected( $cid, $id, false ) . '>' . esc_html( $title ) . '</option>';
	}
	echo '</select> ' . get_submit_button( 'Show', 'secondary', '', false ) . ' <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=aw_cl_csv&campaign=' . $cid ), 'aw_cl_csv' ) ) . '">Export CSV</a></form>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_submit_button() is core's escaped button
	$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE campaign_id = %d", $cid ) ); // phpcs:ignore
	echo '<h2>' . esc_html( sprintf( /* translators: %s: number of letters. */ _n( '%s letter sent', '%s letters sent', $total, 'kits-core' ), number_format_i18n( $total ) ) ) . '</h2>';
	$table = function ( $title, $rows, $head ) {
		echo '<h2>' . esc_html( $title ) . '</h2>';
		$cells = array();
		foreach ( $rows as $label => $n ) {
			$cells[] = array( 'label' => esc_html( '' === (string) $label ? '(not given)' : $label ), 'n' => esc_html( number_format_i18n( $n ) ) );
		}
		aw_core_simple_table( 'letters', array( 'label' => esc_html( $head ), 'n' => 'Letters' ), $cells, array( 'empty' => 'None yet.' ) );
	};
	$pairs = fn( $sql ) => wp_list_pluck( (array) $wpdb->get_results( $wpdb->prepare( $sql, $cid ) ), 'n', 'k' ); // phpcs:ignore
	$day   = $pairs( "SELECT sent_on AS k, COUNT(*) AS n FROM {$t} WHERE campaign_id = %d GROUP BY sent_on ORDER BY sent_on DESC" );
	$route = array();
	foreach ( $pairs( "SELECT route AS k, COUNT(*) AS n FROM {$t} WHERE campaign_id = %d GROUP BY route ORDER BY n DESC" ) as $k => $n ) {
		$route[ AW_CL_ROUTES[ $k ] ?? $k ] = $n;
	}
	$device = array();
	foreach ( $pairs( "SELECT device AS k, COUNT(*) AS n FROM {$t} WHERE campaign_id = %d GROUP BY device ORDER BY n DESC" ) as $k => $n ) {
		$device[ AW_CL_DEVICES[ $k ] ?? $k ] = $n;
	}
	$labels = aw_cl_ground_labels( $cid );
	$ground = array();
	foreach ( (array) $wpdb->get_col( $wpdb->prepare( "SELECT grounds FROM {$t} WHERE campaign_id = %d", $cid ) ) as $g ) { // phpcs:ignore
		foreach ( array_filter( explode( ',', (string) $g ) ) as $n ) {
			$ground[ (int) $n ] = ( $ground[ (int) $n ] ?? 0 ) + 1;
		}
	}
	arsort( $ground );
	$ground_rows = array();
	foreach ( $ground as $n => $c ) {
		$ground_rows[ $n . '. ' . ( $labels[ $n ] ?? '' ) ] = $c;
	}
	$table( 'By ground', $ground_rows, 'Ground' );
	$table( 'By city (top 50)', $pairs( "SELECT city AS k, COUNT(*) AS n FROM {$t} WHERE campaign_id = %d GROUP BY city ORDER BY n DESC LIMIT 50" ), 'City' );
	$table( 'How it was sent', $route, 'Route' );
	$table( 'Device', $device, 'Device' );
	$table( 'By day (IST)', $day, 'Date' );
}

add_action(
	'admin_post_aw_cl_csv',
	function () {
		global $wpdb;
		check_admin_referer( 'aw_cl_csv' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( 'Not allowed' );
		}
		$cid  = absint( $_GET['campaign'] ?? 0 );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT sent_on, city, grounds, route, device FROM ' . aw_cl_table() . ' WHERE campaign_id = %d ORDER BY id', $cid ), ARRAY_A ); // phpcs:ignore
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=letters-' . sanitize_file_name( get_post_field( 'post_name', $cid ) ) . '-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'date', 'city', 'grounds', 'route', 'device' ) );
		foreach ( $rows as $r ) {
			fputcsv( $out, array_map( fn( $v ) => preg_match( '/^[=+\-@]/', (string) $v ) ? "'" . $v : $v, $r ) ); // no spreadsheet formulas from typed cities
		}
		exit;
	}
);

/**
 * Dashboard box "Campaign letters" (owner, 19 Oct 2026): for the newest campaign with letters, the total, the last
 * 7 days (IST), the top 3 grounds and cities, and a link to the full Letter report.
 */
add_action(
	'wp_dashboard_setup',
	function () {
		if ( current_user_can( 'edit_posts' ) && aw_cl_campaigns() ) {
			wp_add_dashboard_widget( 'aw_cl_widget', 'Campaign letters', 'aw_cl_widget' );
		}
	}
);

function aw_cl_widget() {
	global $wpdb;
	$all   = aw_cl_campaigns();
	$cid   = (int) array_key_first( $all );
	$t     = aw_cl_table();
	$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE campaign_id = %d", $cid ) ); // phpcs:ignore
	$week  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE campaign_id = %d AND sent_on >= %s", $cid, wp_date( 'Y-m-d', strtotime( '-6 days' ) ) ) ); // phpcs:ignore
	$labels = aw_cl_ground_labels( $cid );
	$ground = array();
	foreach ( (array) $wpdb->get_col( $wpdb->prepare( "SELECT grounds FROM {$t} WHERE campaign_id = %d", $cid ) ) as $g ) { // phpcs:ignore
		foreach ( array_filter( explode( ',', (string) $g ) ) as $n ) {
			$ground[ (int) $n ] = ( $ground[ (int) $n ] ?? 0 ) + 1;
		}
	}
	arsort( $ground );
	$cities = wp_list_pluck( (array) $wpdb->get_results( $wpdb->prepare( "SELECT city AS k, COUNT(*) AS n FROM {$t} WHERE campaign_id = %d AND city <> '' GROUP BY city ORDER BY n DESC LIMIT 3", $cid ) ), 'n', 'k' ); // phpcs:ignore
	echo '<p><strong>' . esc_html( $all[ $cid ] ) . '</strong></p>';
	if ( function_exists( 'kits_dash_cards' ) ) { // Dashboard cards and chart (owner, 3 Nov 2026)
		$prev  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE campaign_id = %d AND sent_on >= %s AND sent_on < %s", $cid, wp_date( 'Y-m-d', strtotime( '-13 days' ) ), wp_date( 'Y-m-d', strtotime( '-6 days' ) ) ) ); // phpcs:ignore
		$today = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE campaign_id = %d AND sent_on >= %s", $cid, wp_date( 'Y-m-d' ) ) ); // phpcs:ignore
		echo kits_dash_cards( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			array(
				array( 'label' => 'Sent', 'value' => number_format_i18n( $total ) ),
				array( 'label' => 'Last 7 days', 'value' => number_format_i18n( $week ), 'delta' => $week - $prev, 'delta_text' => 'on the 7 days before' ),
				array( 'label' => 'Today so far', 'value' => number_format_i18n( $today ) ),
			)
		);
		$per  = wp_list_pluck( (array) $wpdb->get_results( $wpdb->prepare( "SELECT DATE(sent_on) AS k, COUNT(*) AS n FROM {$t} WHERE campaign_id = %d AND sent_on >= %s GROUP BY DATE(sent_on)", $cid, wp_date( 'Y-m-d', strtotime( '-13 days' ) ) ) ), 'n', 'k' ); // phpcs:ignore
		$bars = array();
		for ( $i = 13; $i >= 0; $i-- ) {
			$d                                    = wp_date( 'Y-m-d', strtotime( "-{$i} days" ) );
			$bars[ wp_date( 'j M', strtotime( $d ) ) ] = (int) ( $per[ $d ] ?? 0 );
		}
		echo kits_dash_bars( $bars, 'Letters per day, last 14 days', true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	} else {
		echo '<p style="font-size:14px">' . esc_html( sprintf( '%s sent · %s in the last 7 days', number_format_i18n( $total ), number_format_i18n( $week ) ) ) . '</p>';
	}
	// Two sub-sections (owner, 3 Nov 2026), each opening to its table: Top grounds open, Top cities closed.
	$list = function ( $title, $rows, $col, $open ) {
		echo '<details style="margin:12px 0 0"' . ( $open ? ' open' : '' ) . '><summary><strong>' . esc_html( $title ) . '</strong></summary>';
		if ( ! $rows ) {
			echo '<p class="description">None yet.</p></details>';
			return;
		}
		echo '<table class="widefat striped" style="margin-top:6px"><thead><tr><th scope="col">' . esc_html( $col ) . '</th><th scope="col">Letters</th></tr></thead><tbody>';
		foreach ( $rows as $label => $n ) {
			echo '<tr><td>' . esc_html( $label ) . '</td><td>' . esc_html( number_format_i18n( $n ) ) . '</td></tr>';
		}
		echo '</tbody></table></details>';
	};
	$top = array();
	foreach ( array_slice( $ground, 0, 3, true ) as $n => $c ) {
		$top[ $n . '. ' . ( $labels[ $n ] ?? '' ) ] = $c;
	}
	$list( 'Top grounds', $top, 'Ground', true );
	$list( 'Top cities', $cities, 'City', false );
	echo '<p style="margin-top:12px"><a href="' . esc_url( admin_url( 'edit.php?post_type=aw_campaign&page=aw-letter-report&campaign=' . $cid ) ) . '">Full letter report →</a></p>';
}
