<?php
/**
 * Canonical URLs Rank Math cannot work out (og:url follows the canonical):
 * - section hub Pages and Directory places: the Page path with /page/N/, without filters;
 * - filtered or sorted lists (?tag=, ?state=, ?category_name= …): the list with its filters in a fixed order, so each
 *   filtered list is its own indexed page (owner, 10 Oct 2026); the sort order is left out. A hub's ?category_name= and
 *   ?tag= views follow filtered-views.php (15 Oct 2026: ?tag= points at the tag page);
 * - /claim/?listing=ID: its own URL as canonical (the claim page is noindex, follow in Rank Math, like /report/: owner,
 *   24 Oct 2026; it was one indexed page per listing).
 * A canonical typed in Rank Math always wins. Items keep Rank Math's own canonical.
 *
 * @package rankweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Query parameters that filter a list: such a URL is indexed with its own canonical (owner, 10 Oct 2026). */
// AW_FILTER_PARAMS: RankWeb → Settings (settings.php).

/** Canonical URL of a hub page: its path without filters, with /page/N/. */
function rankweb_hub_canonical() {
	if ( ! function_exists( 'aw_hub_base_url' ) || ! function_exists( 'aw_hub_page' ) ) { // the hubs (Animal Writes Core) are not loaded
		return rankweb_list_canonical();
	}
	return strtok( aw_hub_base_url(), '?' ) . ( aw_hub_page() > 1 ? 'page/' . aw_hub_page() . '/' : '' );
}

/** Whether the current URL is a filtered or sorted list (?tag=, ?state=, ?q=, ?category_name= …). */
function rankweb_is_filtered_list() {
	$is_list = ( function_exists( 'aw_hub_type' ) && aw_hub_type() ) || ( function_exists( 'directoryweb_is_directory_view' ) && directoryweb_is_directory_view() ) || is_page( 'directory' );
	if ( is_singular() && ! $is_list ) {
		return false;
	}
	foreach ( AW_FILTER_PARAMS as $k ) {
		if ( isset( $_GET[ $k ] ) && '' !== $_GET[ $k ] ) { // phpcs:ignore WordPress.Security.NonceVerification
			return true;
		}
	}
	return false;
}

/** Canonical URL of the current list page: its path (with /page/N/) plus its filters, in a fixed order. */
function rankweb_list_canonical() {
	if ( is_search() || is_404() || ( is_singular() && ! rankweb_is_filtered_list() ) ) { // hub pages are Pages: filtered ones still count
		return '';
	}
	$path = (string) wp_parse_url( (string) wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$url  = home_url( user_trailingslashit( $path ) );
	$args = array();
	foreach ( AW_FILTER_PARAMS as $k ) {
		if ( 'sort' !== $k && isset( $_GET[ $k ] ) && '' !== $_GET[ $k ] && is_string( $_GET[ $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$args[ $k ] = sanitize_text_field( wp_unslash( $_GET[ $k ] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
	}
	return $args ? add_query_arg( array_map( 'rawurlencode', $args ), $url ) : $url;
}

/** The listing a /claim/?listing=ID page is for (0 elsewhere). */
function rankweb_claim_listing() {
	$id = is_page( 'claim' ) ? absint( $_GET['listing'] ?? 0 ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	return ( $id && 'aw_listing' === get_post_type( $id ) && 'publish' === get_post_status( $id ) ) ? $id : 0;
}

/**
 * Canonical URL of the current view: hub, claim page or filtered list by the rules above; items their own URL;
 * other views their path.
 *
 * @return string
 */
function rankweb_seo_canonical() {
	$url = '';
	if ( function_exists( 'aw_hub_type' ) && aw_hub_type() && ! is_404() ) {
		$url = rankweb_hub_canonical();
	}
	if ( '' === $url && rankweb_claim_listing() ) {
		$url = add_query_arg( 'listing', rankweb_claim_listing(), get_permalink() );
	}
	if ( rankweb_is_filtered_list() ) {
		$view = function_exists( 'rankweb_seo_filtered_view' ) ? rankweb_seo_filtered_view() : null;
		$url  = ( $view && '' !== $view['canonical'] ) ? $view['canonical'] : ( $view && ! $view['index'] ? rankweb_hub_canonical() : rankweb_list_canonical() ); // filtered-views.php: noindex views point at the section page
	}
	if ( '' !== $url ) {
		return $url;
	}
	if ( is_singular() ) {
		$c = wp_get_canonical_url();
		return $c ? $c : (string) get_permalink();
	}
	$path = (string) wp_parse_url( (string) wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	return home_url( user_trailingslashit( $path ) );
}

add_filter(
	'rank_math/frontend/canonical',
	function ( $url ) {
		if ( is_404() || '' !== rankweb_seo_typed( 'canonical_url' ) || ( ! rankweb_seo_is_list_view() && ! rankweb_claim_listing() ) ) {
			return $url; // typed in Rank Math, or an item: Rank Math's own
		}
		$ours = rankweb_seo_canonical();
		return '' !== $ours ? $ours : $url;
	},
	20
);

add_filter(
	'get_canonical_url',
	function ( $url ) {
		if ( is_404() || ( function_exists( 'rankweb_seo_typed' ) && '' !== rankweb_seo_typed( 'canonical_url' ) ) || ( ! rankweb_seo_is_list_view() && ! rankweb_claim_listing() ) ) {
			return $url;
		}
		$ours = rankweb_seo_canonical();
		return '' !== $ours ? $ours : $url;
	},
	20
);
