<?php
/**
 * RankWeb → Settings (owner, 25 Oct 2026: settings per module, like Rank Math's). Loaded first.
 *
 * rankweb_seo_modules() lists every module: label, whether it can be switched off, the files it loads, and its settings.
 * Each setting is one of the plugin's former constants; its default is the value the code had, so nothing changes
 * until a setting is saved. The constants are defined here from option aw_seo_settings ({module: {CONST: value, on}}).
 * Foundation modules (General, Titles, Canonicals, Robots, Filtered lists, Schema) are always on: the others call them.
 * A module switched off is not loaded (rankweb.php). The Settings screen is on the Kits shell (rankweb-ui.php);
 * it reads and saves through the rankweb/v1 settings routes (rankweb-rest.php), which call rankweb_seo_settings_save().
 * Every option that screen saves is registered with register_setting() (rankweb_seo_registered_settings()), so each
 * update_option() runs its sanitize callback, whoever writes it, and /wp/v2/settings shows it to administrators.
 *
 * @package rankweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const AW_SEO_SETTINGS = 'aw_seo_settings';

/** Every module and its settings. */
function rankweb_seo_modules(): array {
	static $m = null;
	if ( null !== $m ) {
		return $m;
	}
	$m = array(
		'general' => array(
			'label'  => 'General',
			'switch' => false,
			'files'  => array( 'helpers' ),
			'desc'   => 'Shared rules: description length, the section hubs\' titles and descriptions, share images.',
			'fields' => array(
				'AW_SEO_DESC_MAX' => array( 'type' => 'int', 'label' => 'Longest description (characters)', 'help' => 'Search descriptions are cut at a word before this.', 'default' => 155 ),
				'AW_HUB_TITLES' => array( 'type' => 'map', 'label' => 'Section hub titles', 'help' => 'One per line: post type | title.', 'default' => array() ),
				'AW_HUB_DESCRIPTIONS' => array( 'type' => 'map', 'label' => 'Section hub descriptions', 'help' => 'One per line: post type | description. %s is the number of listings (Directory).', 'default' => array() ),
				'AW_ARCHIVE_DESCRIPTIONS' => array( 'type' => 'map', 'label' => 'Archive descriptions', 'help' => 'One per line: post type | description.', 'default' => array() ),
				'AW_SEO_LISTING_SHARE_IMAGE' => array( 'tab' => 'share', 'type' => 'int', 'label' => 'Listing share image (attachment ID)', 'help' => 'Used when a listing has no logo of its own.', 'default' => 0 ),
				'AW_SEO_SOURCE_IMAGE_TYPES' => array( 'tab' => 'share', 'type' => 'list', 'label' => 'Types that share the publisher\'s image', 'help' => 'One post type per line.', 'default' => array() ),
			),
		),
		'titles' => array(
			'label'  => 'Titles and descriptions',
			'switch' => false,
			'files'  => array( 'titles' ),
			'desc'   => 'Search titles and descriptions of items and of list pages (hubs, Directory places, categories, tags), built from their own counts and places.',
			'fields' => array(
				'AW_SEO_ITEM_TYPES' => array( 'type' => 'list', 'label' => 'Item types', 'help' => 'Post types whose items get titles, descriptions and focus keywords. One per line.', 'default' => array( 'post', 'page' ) ),
				'AW_SEO_BREAKDOWN' => array( 'type' => 'list', 'label' => 'Directory place breakdown', 'help' => 'Listing types counted in a place\'s description, in this order. One tag slug per line.', 'default' => array() ),
				'AW_SEO_TERM_TITLES' => array( 'type' => 'map', 'label' => 'Category and tag titles', 'help' => 'One per line: taxonomy:slug | title. Others get the rule-based title.', 'default' => array() ),
			),
		),
		'canonical' => array(
			'label'  => 'Canonicals',
			'switch' => false,
			'files'  => array( 'canonical' ),
			'desc'   => 'Canonical addresses Rank Math cannot work out: hub pages, Directory places, filtered lists.',
			'fields' => array(
				'AW_FILTER_PARAMS' => array( 'type' => 'list', 'label' => 'Filter parameters', 'help' => 'Query parameters that make a filtered list. One per line.', 'default' => array( 'tag', 'state', 'district', 'q', 'category_name', 'verified', 'gov', 'sort', 'publisher', 'court', 'issuer' ) ),
			),
		),
		'robots' => array(
			'label'  => 'Robots rules',
			'switch' => false,
			'files'  => array( 'robots' ),
			'desc'   => 'Noindex rules that depend on an item\'s state or a list\'s size.',
			'fields' => array(
				'AW_SEO_NOINDEX_PROTECTED' => array( 'type' => 'int', 'label' => 'Keep password-protected items out of search (1 on, 0 off)', 'help' => 'A password-protected item hides its content, so it is set to noindex.', 'default' => 1 ),
				'AW_THIN_DISTRICT_TYPE' => array( 'type' => 'int', 'label' => 'Fewest listings for an indexed Directory page', 'help' => 'A district × type page with fewer listings than this is noindex and left out of the Directory sitemap, unless it is on the "Thin pages kept indexed" list. At 1, the default, only a page with no listings is noindex.', 'default' => 1 ),
				'AW_DIRECTORY_KEEP_INDEXED' => array( 'type' => 'list', 'label' => 'Thin pages kept indexed', 'help' => 'Paths under /directory/ that stay indexed anyway. One per line.', 'default' => array() ),
			),
		),
		'filtered' => array(
			'label'  => 'Filtered lists',
			'switch' => false,
			'files'  => array( 'filtered-views' ),
			'desc'   => 'A hub filtered by one category or tag is a page of its own (title, description, canonical, sitemap) from a minimum number of items.',
			'fields' => array(
				'AW_FILTERED_MIN_ITEMS' => array( 'type' => 'int', 'label' => 'Fewest items for an indexed filtered list', 'help' => 'Below this a filtered list is noindex.', 'default' => 3 ),
				'AW_FILTERED_CATEGORY_HUBS' => array( 'type' => 'list', 'label' => 'Hubs with filtered pages', 'help' => 'One post type per line.', 'default' => array() ),
				'AW_FILTERED_TITLE_WORDS' => array( 'type' => 'maplist', 'label' => 'Filtered list titles', 'help' => 'One per line: post type | title | shorter title …, %s is the category or tag.', 'default' => array() ),
				'AW_FILTERED_STATE_NOINDEX' => array( 'type' => 'list', 'label' => 'Hubs whose state views are noindex', 'help' => 'One post type per line.', 'default' => array() ),
			),
		),
		'video' => array(
			'label'  => 'Video',
			'switch' => true,
			'files'  => array( 'video' ),
			'desc'   => 'Finds YouTube and Vimeo videos in content, adds a VideoObject to the schema, and lists them in a video sitemap. No paid API: a YouTube video gets its title and thumbnail, not its duration or date.',
			'fields' => array(
				'AW_VIDEO_TYPES' => array( 'type' => 'list', 'label' => 'Post types scanned for videos', 'help' => 'Items of these types are scanned for YouTube and Vimeo videos. One per line. Empty: nothing runs.', 'default' => array( 'post' ) ),
			),
		),
		'redirect-tools' => array(
			'label'  => 'Redirect tools',
			'switch' => true,
			'files'  => array( 'redirect-tools' ),
			'desc'   => 'Export and import redirects as CSV, export Rank Math\'s 404 log, and an Apache .htaccess block. Redirects stay in Rank Math\'s one list.',
			'fields' => array(
				'AW_REDIRECT_HTACCESS' => array( 'type' => 'int', 'label' => 'Allow writing redirects to .htaccess (1 on, 0 off)', 'help' => 'Off by default. Apache or LiteSpeed only; a backup is written first. The download works whether this is on or off.', 'default' => 0 ),
			),
		),
		'schema' => array(
			'label'  => 'Schema',
			'switch' => false,
			'files'  => array( 'schema' ),
			'desc'   => 'The site\'s own JSON-LD nodes in Rank Math\'s graph (organisations, Library documents, campaigns, opportunities, lists).',
			'fields' => array(
				'AW_SITE_ALT_NAMES' => array( 'type' => 'list', 'label' => 'Other names of the site', 'help' => 'The WebSite node\'s alternateName. One per line.', 'default' => array() ),
			),
		),
		'schema-plus' => array(
			'label'  => 'Custom schema',
			'switch' => true,
			'files'  => array( 'schema-custom' ),
			'desc'   => 'A per-item JSON-LD box (several nodes), Speakable, about and mentions, import schema from a URL, and a Rich Results Test link.',
			'fields' => array(
				'AW_SCHEMA_TYPES' => array( 'type' => 'list', 'label' => 'Post types with the custom-schema box', 'help' => 'Items of these types get the Custom schema box. One per line. Empty: none.', 'default' => array( 'post', 'page' ) ),
			),
		),
		'faq' => array(
			'label'  => 'FAQ',
			'switch' => true,
			'files'  => array( 'faq', 'faq-data' ),
			'desc'   => 'The FAQ box on the edit screen of every public post type and taxonomy (which ones: Plugins → RankWeb → FAQ), and the questions and answers with FAQPage schema on the page. Automatic questions from a page\'s own fields fill the box where the site provides them.',
			'fields' => array(
				'AW_FAQ_MIN' => array( 'type' => 'int', 'label' => 'Fewest questions (pages and every other type)', 'help' => 'Fewer than this: no FAQ and no schema.', 'default' => 3 ),
				'AW_FAQ_MIN_GUIDE' => array( 'type' => 'int', 'label' => 'Fewest questions on a post (Resources guides)', 'help' => '', 'default' => 2 ),
				'AW_FAQ_MAX' => array( 'type' => 'int', 'label' => 'Most questions shown', 'help' => '', 'default' => 6 ),
				'AW_FAQ_WORDS' => array( 'type' => 'int', 'label' => 'Longest answer (words)', 'help' => 'Longer answers are flagged by the checks.', 'default' => 50 ),
				'AW_FAQ_HUBS' => array( 'type' => 'map', 'label' => 'Pages with a subject in the FAQ heading', 'help' => 'One per line: page slug | subject (the heading: "Questions about <subject>"). Their FAQ sits under the list, wide. Other pages: the page title.', 'default' => array(
						'directory'     => 'the Directory',
						'volunteer'     => 'volunteering',
						'claim'         => 'claiming a listing',
						'opportunities' => 'Opportunities',
					) ),
			),
		),
		'rank-math-schema' => array(
			'label'  => 'Rank Math schema entries',
			'switch' => true,
			'files'  => array( 'rank-math-schema' ),
			'desc'   => 'Rank Math\'s own schema entries naming each item\'s real schema type, so its screens show it.',
			'fields' => array(
				'AW_RM_SCHEMA_TYPES' => array( 'type' => 'list', 'label' => 'Post types', 'help' => 'One per line.', 'default' => array( 'post', 'page' ) ),
			),
		),
		'opengraph' => array(
			'label'  => 'Share images and Open Graph',
			'switch' => true,
			'files'  => array( 'opengraph' ),
			'desc'   => 'Share images and texts Rank Math\'s settings cannot express; a choice made in Rank Math wins.',
			'fields' => array(
				'AW_SEO_ARTICLE_TYPES' => array( 'type' => 'list', 'label' => 'Types shared as articles', 'help' => 'One post type per line.', 'default' => array( 'post' ) ),
			),
		),
		'sitemap' => array(
			'label'  => 'Directory sitemap',
			'switch' => true,
			'files'  => array( 'sitemap' ),
			'desc'   => 'The Directory\'s place pages and the filtered lists in Rank Math\'s sitemap.',
			'fields' => array(
			),
		),
		'redirects' => array(
			'label'  => 'Redirects',
			'switch' => true,
			'files'  => array( 'redirects' ),
			'desc'   => 'Clean-up redirects and author archives; forms, merges and imports add to Rank Math\'s Redirections.',
			'fields' => array(
			),
		),
		'breadcrumbs' => array(
			'label'  => 'Breadcrumbs',
			'switch' => true,
			'files'  => array( 'breadcrumbs' ),
			'desc'   => 'The breadcrumb trail for places and hubs.',
			'fields' => array(
			),
		),
		'focus-keywords' => array(
			'label'  => 'Focus keywords',
			'switch' => true,
			'files'  => array( 'focus-keywords' ),
			'desc'   => 'Listings get their name as focus keyword; the workers\' job fills the rest through the site\'s API.',
			'fields' => array(
				'AW_SEO_GENERIC_WORDS' => array( 'type' => 'list', 'label' => 'Words that alone make no keyword', 'help' => 'One per line.', 'default' => array( 'save', 'help', 'news', 'care', 'update', 'updates', 'issue', 'case', 'story' ) ),
			),
		),
		'health' => array(
			'label'  => 'Sitemap and llms.txt check',
			'switch' => true,
			'files'  => array( 'health' ),
			'desc'   => 'Hourly: both must answer; flush once, then email the admin and show a notice.',
			'fields' => array(
			),
		),
		'llms' => array(
			'label'  => 'llms.txt',
			'switch' => true,
			'files'  => array( 'llms' ),
			'desc'   => 'llms.txt order, descriptions and the Directory section (Rank Math writes the file).',
			'fields' => array(
				'AW_LLMS_PAGE_ORDER' => array( 'type' => 'list', 'label' => 'Page order', 'help' => 'Page slugs in order, one per line; "/" is the home page.', 'default' => array( '', 'news', 'library', 'resources', 'directory', 'opportunities', 'campaigns', 'press-coverage', 'categories', 'about', 'editorial-policy', 'corrections', 'contact', 'privacy-policy', 'terms', 'disclaimer', 'volunteer', 'claim' ) ),
				'AW_LLMS_GUIDE_TYPES' => array( 'type' => 'list', 'label' => 'Guide tags', 'help' => 'Tags whose Resources items are listed as guides. One per line.', 'default' => array( 'guide', 'faq' ) ),
			),
		),
		'site-tags' => array(
			'label'  => 'Search engines and crawlers',
			'switch' => true,
			'files'  => array( 'site-tags' ),
			'desc'   => 'Verification tags for Google, Bing, Yandex and Pinterest, and crawlers kept out in robots.txt. Both are empty until you set them.',
			'fields' => array(
				'RANKWEB_VERIFY_GOOGLE'    => array( 'type' => 'text', 'label' => 'Google Search Console code', 'help' => 'The code, or the whole meta tag Google gives you.', 'default' => '' ),
				'RANKWEB_VERIFY_BING'      => array( 'type' => 'text', 'label' => 'Bing Webmaster code', 'help' => 'The code, or the whole meta tag.', 'default' => '' ),
				'RANKWEB_VERIFY_YANDEX'    => array( 'type' => 'text', 'label' => 'Yandex code', 'help' => '', 'default' => '' ),
				'RANKWEB_VERIFY_PINTEREST' => array( 'type' => 'text', 'label' => 'Pinterest code', 'help' => '', 'default' => '' ),
				'RANKWEB_BLOCK_CRAWLERS'   => array( 'type' => 'list', 'label' => 'Crawlers kept out of the whole site', 'help' => 'One name per line, e.g. GPTBot, ClaudeBot, CCBot, Google-Extended, PerplexityBot, Bytespider. A crawler that ignores robots.txt is not stopped.', 'default' => array() ),
			),
		),
		'markdown' => array(
			'label'  => 'Markdown for agents',
			'switch' => true,
			'files'  => array( 'markdown' ),
			'desc'   => 'Home and single pages as Markdown when a request asks for text/markdown; browsers get the HTML.',
			'fields' => array(
				'AW_MD_VARY_HTML' => array( 'type' => 'int', 'label' => 'Vary: Accept on the HTML (1 on, 0 off)', 'help' => 'Set 0 if the CDN stops storing Home and single pages (x-hcdn-cache-status never HIT).', 'default' => 1 ),
			),
		),
		'bulk' => array(
			'label'  => 'Bulk edit',
			'switch' => true,
			'files'  => array( 'bulk-edit', 'bulk-csv' ),
			'desc'   => 'SEO columns, filters, Quick Edit and Bulk Edit on the post-list screens, and a CSV export and import of the SEO fields (RankWeb → SEO CSV).',
			'fields' => array(
				'AW_BULK_TYPES' => array( 'type' => 'list', 'label' => 'Post types with the list-screen SEO tools', 'help' => 'One per line. Empty: none.', 'default' => array( 'post', 'page' ) ),
			),
		),
		'media' => array(
			'label'  => 'Images',
			'switch' => true,
			'files'  => array( 'media-seo' ),
			'desc'   => 'Find and replace across image alt text, title and caption, and fill missing captions (RankWeb → Images).',
			'fields' => array(
				'AW_MEDIA_CAPTION' => array( 'type' => 'text', 'label' => 'Caption pattern for missing captions', 'help' => 'Placeholders: {title}, {filename}, {sitename}.', 'default' => '{title}' ),
			),
		),
		'agent' => array(
			'label'  => 'Agent tools',
			'switch' => true,
			'files'  => array( 'agent-tools' ),
			'desc'   => 'RankWeb\'s work as WordPress abilities (the Abilities API, 6.9+), exposed to AI agents by the MCP adapter. Reads only, unless writes are allowed below.',
			'fields' => array(
				'AW_AGENT_WRITES' => array( 'type' => 'int', 'label' => 'Allow write abilities (1 on, 0 off)', 'help' => 'Off by default. The reads are always registered; the writes (set SEO, add redirect, set schema) are registered only when this is on, and each still checks the capability.', 'default' => 0 ),
			),
		),
		'analysis' => array(
			'label'  => 'Content analysis',
			'switch' => true,
			'files'  => array( 'analysis', 'content-advice' ),
			'desc'   => 'Rank Math\'s analyzer reads the published page for Pages built from blocks; the RankWeb content panel in the editor.',
			'fields' => array(
				'AW_SEO_RENDERED_TYPES' => array( 'type' => 'list', 'label' => 'Types analysed as rendered', 'help' => 'One post type per line.', 'default' => array( 'post', 'page' ) ),
				'AW_SEO_SUMMARY_SKIP_TESTS' => array( 'type' => 'list', 'label' => 'Rank Math tests skipped on summaries', 'help' => 'One test ID per line.', 'default' => array( 'lengthContent', 'keywordDensity', 'keywordInSubheadings', 'contentHasTOC' ) ),
				'AW_SEO_COVERED_TESTS' => array( 'type' => 'list', 'label' => 'Rank Math tests RankWeb covers', 'help' => 'Skipped on every item: RankWeb does this work instead. One test ID per line.', 'default' => array( 'hasContentAI' ) ),
			),
		),
		'internal-links' => array(
			'label'  => 'Internal links',
			'switch' => true,
			'files'  => array( 'internal-links', 'link-audit', 'link-anchors', 'silos' ),
			'desc'   => 'Links items to each other from their link keywords, and records every link in each item. Adds no link until a post type is listed.',
			'fields' => array(
				'AW_LINK_TYPES' => array( 'type' => 'list', 'label' => 'Post types linked', 'help' => 'Items of these types get links and can be linked to. One post type per line. Empty: no links are added.', 'default' => array() ),
				'AW_LINK_MAX' => array( 'type' => 'int', 'label' => 'Most links added to one item', 'help' => '', 'default' => 5 ),
				'AW_LINK_MAX_PER_TARGET' => array( 'type' => 'int', 'label' => 'Most links to the same page in one item', 'help' => '', 'default' => 1 ),
				'AW_LINK_FIRST_ONLY' => array( 'type' => 'int', 'label' => 'Link only the first time a keyword appears (1 on, 0 off)', 'help' => '', 'default' => 1 ),
				'AW_LINK_NO_SELF' => array( 'type' => 'int', 'label' => 'Never link an item to itself (1 on, 0 off)', 'help' => '', 'default' => 1 ),
				'AW_LINK_SKIP_LINKED' => array( 'type' => 'int', 'label' => 'Skip a page the item already links to by hand (1 on, 0 off)', 'help' => '', 'default' => 1 ),
				'AW_LINK_EXCLUDE' => array( 'type' => 'list', 'label' => 'Items left out', 'help' => 'Never linked from or to. One item ID per line.', 'default' => array() ),
				'AW_LINK_AUDIT_DEPTH' => array( 'type' => 'int', 'label' => 'Audit: most clicks from the home page', 'help' => 'An item further away than this is listed as too deep.', 'default' => 3 ),
				'AW_LINK_AUDIT_MAX' => array( 'type' => 'int', 'label' => 'Audit: most links in one item', 'help' => 'An item with more links than this is listed as having too many.', 'default' => 100 ),
				'AW_LINK_ANCHOR_EXACT_MAX' => array( 'type' => 'int', 'label' => 'Anchors: most exact match, in percent', 'help' => 'An item whose links in have more exact-match anchors than this share is warned about, and the auto-linker uses another keyword.', 'default' => 20 ),
				'AW_LINK_ANCHOR_TYPE_MAX' => array( 'type' => 'int', 'label' => 'Anchors: most of any other type, in percent', 'help' => 'The same for every other anchor type.', 'default' => 60 ),
				'AW_LINK_ANCHOR_MIN' => array( 'type' => 'int', 'label' => 'Anchors: fewest links before a warning', 'help' => 'An item with fewer links in gets no warning.', 'default' => 5 ),
				'AW_LINK_BRAND' => array( 'type' => 'list', 'label' => 'Anchors: brand names', 'help' => 'An anchor with one of these words is branded. One per line.', 'default' => array( rankweb_site_name() ) ),
				'AW_LINK_GENERIC' => array( 'type' => 'list', 'label' => 'Anchors: generic anchors', 'help' => 'These anchors are generic. One per line.', 'default' => array( 'click here', 'here', 'read more', 'learn more', 'more', 'this page', 'this article', 'this link', 'link' ) ),
				'AW_LINK_LONG_WORDS' => array( 'type' => 'int', 'label' => 'Anchors: words in a long-tail anchor', 'help' => 'An anchor with more words than this is long-tail.', 'default' => 6 ),
				'AW_SILO_MAX' => array( 'type' => 'int', 'label' => 'Silos: most links an item shows', 'help' => 'The silo links at the end of an item. In virtual mode the others are listed from the next one round, so every item gets links.', 'default' => 10 ),
				'AW_SILO_MIN' => array( 'type' => 'int', 'label' => 'Silos: fewest items', 'help' => 'A silo with fewer items (the hub counts) is flagged.', 'default' => 5 ),
				'AW_SILO_DEPTH' => array( 'type' => 'int', 'label' => 'Silos: most folders deep', 'help' => 'An item whose address is deeper (/library/guides/page/ is 3) is flagged.', 'default' => 3 ),
				'AW_LINK_AUDIT_AVOID' => array( 'type' => 'list', 'label' => 'Audit: addresses not to link to', 'help' => 'A link whose address contains one of these words is listed (thank-you and download pages). One per line.', 'default' => array( 'thank-you', 'thanks', 'download' ) ),
			),
		),
	);
	/**
	 * The modules and their settings, before they are read: a site changes a default or adds a field here.
	 *
	 * @param array $m Modules.
	 */
	$m = (array) apply_filters( 'rankweb_modules', $m );
	return $m;
}

/** Saved settings (all modules). */
function rankweb_seo_saved(): array {
	return (array) get_option( AW_SEO_SETTINGS, array() );
}

/** Whether a module is on (foundation modules always are). */
function rankweb_seo_module_on( string $key ): bool {
	$mods = rankweb_seo_modules();
	if ( empty( $mods[ $key ]['switch'] ) ) {
		return true;
	}
	$saved = rankweb_seo_saved();
	return ! isset( $saved[ $key ]['on'] ) || ! empty( $saved[ $key ]['on'] );
}

/** Files a switched-off module would load: rankweb.php skips them. */
function rankweb_seo_files_off(): array {
	$off = array();
	foreach ( rankweb_seo_modules() as $key => $mod ) {
		if ( ! rankweb_seo_module_on( $key ) ) {
			$off = array_merge( $off, $mod['files'] );
		}
	}
	return $off;
}

// The constants, from the saved settings or the defaults.
foreach ( rankweb_seo_modules() as $aw_seo_key => $aw_seo_mod ) {
	$rankweb_seo_saved = rankweb_seo_saved()[ $aw_seo_key ] ?? array();
	foreach ( $aw_seo_mod['fields'] as $aw_seo_const => $aw_seo_field ) {
		if ( ! defined( $aw_seo_const ) ) {
			define( $aw_seo_const, array_key_exists( $aw_seo_const, $rankweb_seo_saved ) ? $rankweb_seo_saved[ $aw_seo_const ] : $aw_seo_field['default'] );
		}
	}
}
unset( $aw_seo_key, $aw_seo_mod, $rankweb_seo_saved, $aw_seo_const, $aw_seo_field );

/* ---------- Text in the form and back ---------- */

/** A value as the text in its field. */
function rankweb_seo_field_text( string $type, $value ): string {
	switch ( $type ) {
		case 'int':
			return (string) (int) $value;
		case 'text':
			return (string) $value;
		case 'list':
			return implode( "\n", array_map( fn( $v ) => '' === (string) $v ? '/' : (string) $v, (array) $value ) );
		case 'map':
			return implode( "\n", array_map( fn( $k, $v ) => $k . ' | ' . $v, array_keys( (array) $value ), (array) $value ) );
		case 'maplist':
			return implode( "\n", array_map( fn( $k, $v ) => $k . ' | ' . implode( ' | ', (array) $v ), array_keys( (array) $value ), (array) $value ) );
	}
	return '';
}

/** The text of a field as its value. */
function rankweb_seo_field_value( string $type, string $text ) {
	$lines = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $text ) ), 'strlen' ) );
	switch ( $type ) {
		case 'int':
			return max( 0, (int) $text );
		case 'text':
			return sanitize_text_field( $text );
		case 'list':
			return array_map( fn( $l ) => '/' === $l ? '' : sanitize_text_field( $l ), $lines );
		case 'map':
		case 'maplist':
			$out = array();
			foreach ( $lines as $l ) {
				$parts = array_map( 'trim', explode( '|', $l ) );
				$k     = sanitize_text_field( (string) array_shift( $parts ) );
				if ( '' === $k || ! $parts ) {
					continue;
				}
				$parts     = array_map( 'sanitize_text_field', $parts );
				$out[ $k ] = 'map' === $type ? implode( ' | ', $parts ) : $parts;
			}
			return $out;
	}
	return null;
}

/* ---------- RankWeb → Settings ---------- */

/**
 * The Settings tabs and the modules whose settings each shows. The settings stay stored per module; a field with its
 * own 'tab' shows on that tab. Modules holds every on/off switch. Search Insights moved to InsightWeb on 11 Nov 2026;
 * its numbers stay in this option under 'search-insights', and InsightWeb's Settings tab writes them.
 */
function rankweb_seo_setting_tabs(): array {
	return array(
		'modules'         => array(
			'label'   => 'Modules',
			'modules' => array(),
		),
		'titles'          => array(
			'label'   => 'Titles and descriptions',
			'modules' => array( 'general', 'titles', 'breadcrumbs', 'bulk' ),
		),
		'indexing'        => array(
			'label'   => 'Indexing',
			'modules' => array( 'canonical', 'robots', 'filtered', 'sitemap', 'redirects', 'redirect-tools', 'health', 'video' ),
		),
		'schema'          => array(
			'label'   => 'Schema and FAQ',
			'modules' => array( 'schema', 'schema-plus', 'faq', 'rank-math-schema' ),
		),
		'share'           => array(
			'label'   => 'Share images and Open Graph',
			'modules' => array( 'opengraph', 'media' ),
		),
		'analysis'        => array(
			'label'   => 'Focus keywords and content analysis',
			'modules' => array( 'focus-keywords', 'analysis' ),
		),
		'ai'              => array(
			'label'   => 'AI agents',
			'modules' => array( 'llms', 'markdown', 'agent' ),
		),
		'links'           => array(
			'label'   => 'Internal links',
			'modules' => array( 'internal-links' ),
		),
	);
}

/** The tab a module's settings are on. */
function rankweb_seo_module_tab( string $module ): string {
	foreach ( rankweb_seo_setting_tabs() as $tab => $t ) {
		if ( in_array( $module, $t['modules'], true ) ) {
			return $tab;
		}
	}
	return 'modules';
}

/**
 * The fields a tab shows, by module: {module: {CONST: field}}.
 *
 * @param string $tab Tab key.
 */
function rankweb_seo_tab_fields( string $tab ): array {
	$out = array();
	foreach ( rankweb_seo_modules() as $key => $mod ) {
		foreach ( $mod['fields'] as $const => $f ) {
			if ( ( $f['tab'] ?? rankweb_seo_module_tab( $key ) ) === $tab ) {
				$out[ $key ][ $const ] = $f;
			}
		}
	}
	return $out;
}

add_action(
	'admin_init',
	function () {
		// The settings are read on every request: autoload them (a save sets it too; this covers the option as it is).
		if ( function_exists( 'wp_set_option_autoload' ) && false !== get_option( AW_SEO_SETTINGS, false ) && ! array_key_exists( AW_SEO_SETTINGS, wp_load_alloptions() ) ) { // false passed: the registered default (array()) would hide a missing option
			wp_set_option_autoload( AW_SEO_SETTINGS, true );
		}
		// An old link to Search Insights' module tab: its numbers are on Search Insights → Settings (InsightWeb).
		if ( 'aw-seo-settings' === sanitize_key( wp_unslash( $_GET['page'] ?? '' ) ) && 'search-insights' === sanitize_key( wp_unslash( $_GET['tab'] ?? '' ) ) && function_exists( 'aw_si_url' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- navigation only
			wp_safe_redirect( aw_si_url( 'settings' ) );
			exit;
		}
	}
);

add_action(
	'admin_menu',
	function () {
		add_submenu_page( AW_SEO_MENU, 'RankWeb settings', 'Settings', 'manage_options', 'aw-seo-settings', 'rankweb_seo_settings_page' );
	},
	200 // last under RankWeb
);

/**
 * Settings address at a group (#tab), or at the group a module's settings are in.
 *
 * @param string $key Tab or module key.
 */
function rankweb_seo_settings_url( string $key = 'modules' ): string {
	$tabs = rankweb_seo_setting_tabs();
	if ( ! isset( $tabs[ $key ] ) && isset( rankweb_seo_modules()[ $key ] ) ) {
		$key = rankweb_seo_module_tab( $key );
	}
	return add_query_arg( 'page', 'aw-seo-settings', admin_url( 'admin.php' ) ) . '#' . ( isset( $tabs[ $key ] ) ? $key : 'modules' );
}

/** RankWeb → Settings on the Kits shell (rankweb-ui.php). */
function rankweb_seo_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.', 403 );
	}
	rankweb_ui_page( 'settings' );
}

/**
 * Save one Settings tab (the RankWeb settings route, rankweb-rest.php, calls this). Only values that differ from the
 * default are stored, the rest of the option (other tabs, and InsightWeb's 'search-insights' numbers) is kept as it
 * is, and nothing is written when nothing changed (a Save with no change leaves the option byte for byte as it was,
 * or absent when it was absent).
 *
 * @param string $tab    Tab key.
 * @param array  $posted Field texts by constant (a field not posted goes back to its default).
 * @param bool   $reset  Restore the tab's defaults.
 * @param array  $on     Modules tab: switchable module keys that are on (key => truthy).
 * @return array The stored settings after the save.
 */
function rankweb_seo_settings_save( string $tab, array $posted, bool $reset = false, array $on = array() ): array {
	$before = rankweb_seo_saved();
	$all    = $before;
	if ( 'modules' === $tab ) {
		foreach ( rankweb_seo_modules() as $key => $mod ) {
			if ( empty( $mod['switch'] ) ) {
				continue;
			}
			// No 'on' key means on (rankweb_seo_module_on()), so only "off" is stored; an 'on' => true from an older save stays.
			if ( empty( $on[ $key ] ) ) {
				$all[ $key ]['on'] = false;
			} elseif ( isset( $all[ $key ]['on'] ) && ! $all[ $key ]['on'] ) {
				unset( $all[ $key ]['on'] );
			}
		}
	} else {
		foreach ( rankweb_seo_tab_fields( $tab ) as $key => $list ) {
			foreach ( $list as $const => $f ) {
				unset( $all[ $key ][ $const ] );
				if ( $reset || ! isset( $posted[ $const ] ) ) {
					continue;
				}
				$value = rankweb_seo_field_value( $f['type'], (string) $posted[ $const ] );
				if ( $value !== $f['default'] ) { // store only what differs, so a later default change reaches unchanged fields
					$all[ $key ][ $const ] = $value;
				}
			}
		}
	}
	$all = array_filter( $all );
	if ( rankweb_seo_settings_sorted( $all ) === rankweb_seo_settings_sorted( $before ) ) {
		return $before; // the same settings (perhaps in another key order): nothing to write
	}
	update_option( AW_SEO_SETTINGS, $all, true ); // read on every request (the constants), so autoloaded
	return $all;
}

/**
 * A settings array with its keys sorted at every level, to compare two saves without the key order.
 *
 * @param mixed $value Settings or a part of them.
 * @return mixed
 */
function rankweb_seo_settings_sorted( $value ) {
	if ( ! is_array( $value ) ) {
		return $value;
	}
	ksort( $value );
	return array_map( 'rankweb_seo_settings_sorted', $value );
}

/* ---------- The options, registered with the Settings API ---------- */

const AW_SEO_DELETE_DATA = 'aw_seo_delete_data'; // 1: uninstall.php deletes RankWeb's own data. Default 0: it keeps everything.

/**
 * One stored setting value, cleaned by its field type. Values the screen stored come back unchanged (the same clean-up
 * as rankweb_seo_field_value()), so a save that changes nothing still writes nothing.
 *
 * @param string $type int, text, list, map, maplist, or '' (a key no field knows: kept, its texts cleaned).
 * @param mixed  $v    Value.
 * @return mixed
 */
function rankweb_seo_setting_clean( string $type, $v ) {
	switch ( $type ) {
		case 'int':
			return max( 0, (int) $v );
		case 'text':
			return sanitize_text_field( (string) $v );
		case 'list':
			return array_values( array_map( fn( $x ) => sanitize_text_field( (string) $x ), (array) $v ) );
		case 'map':
		case 'maplist':
			$out = array();
			foreach ( (array) $v as $k => $x ) {
				$k = sanitize_text_field( (string) $k );
				if ( '' === $k ) {
					continue;
				}
				$out[ $k ] = 'map' === $type ? sanitize_text_field( (string) ( is_array( $x ) ? implode( ' | ', $x ) : $x ) ) : array_values( array_map( fn( $y ) => sanitize_text_field( (string) $y ), (array) $x ) );
			}
			return $out;
	}
	if ( is_array( $v ) ) {
		return array_map( fn( $x ) => rankweb_seo_setting_clean( '', $x ), $v );
	}
	return is_string( $v ) ? sanitize_text_field( $v ) : ( is_scalar( $v ) || null === $v ? $v : '' );
}

/**
 * Sanitize callback of aw_seo_settings ({module: {CONST: value, on: bool}}). Runs on every write of the option: this
 * plugin's Settings route, InsightWeb's numbers (key 'search-insights', AW_SI_* whole numbers), Kits → Tools import
 * and /wp/v2/settings. Every module key is kept, a known field is cleaned by its type, 'on' is a boolean.
 *
 * @param mixed $value Value to store.
 */
function rankweb_seo_settings_sanitize( $value ): array {
	$mods = rankweb_seo_modules();
	$out  = array();
	foreach ( (array) $value as $key => $part ) {
		if ( ! is_array( $part ) ) {
			continue;
		}
		$key = sanitize_key( (string) $key );
		foreach ( $part as $name => $v ) {
			$name = (string) $name;
			if ( 'on' === $name ) {
				$out[ $key ]['on'] = in_array( $v, array( true, false, 0, 1 ), true ) ? $v : (bool) $v; // stored as it was (an older save left 1)
				continue;
			}
			$type               = $mods[ $key ]['fields'][ $name ]['type'] ?? ( 0 === strpos( $name, 'AW_SI_' ) ? 'int' : '' );
			$out[ $key ][ $name ] = rankweb_seo_setting_clean( $type, $v );
		}
	}
	return $out;
}

/**
 * Every option the RankWeb Settings screen saves, as register_setting() arguments. The names and stored shapes are the
 * ones used before (no migration); the default is what the code reads when the option is missing.
 */
function rankweb_seo_registered_settings(): array {
	return array(
		AW_SEO_SETTINGS          => array(
			'type'              => 'object',
			'description'       => 'RankWeb settings by module: the values that differ from the defaults, and the module switches.',
			'default'           => array(),
			'sanitize_callback' => 'rankweb_seo_settings_sanitize',
			'show_in_rest'      => array(
				'schema' => array(
					'type'                 => 'object',
					'additionalProperties' => array(
						'type'                 => 'object',
						'additionalProperties' => true,
					),
				),
			),
		),
		'aw_faq_off_types'       => array(
			'type'              => 'array',
			'description'       => 'Post types and taxonomies without the FAQ box.',
			'default'           => array(),
			'sanitize_callback' => fn( $v ) => array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $v ) ) ) ),
			'show_in_rest'      => array(
				'schema' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
			),
		),
		'aw_seo_keep_listings'   => array(
			'type'              => 'array',
			'description'       => 'Directory listings kept indexed though they have no contact.',
			'default'           => array(),
			'sanitize_callback' => fn( $v ) => array_values( array_unique( array_filter( array_map( 'absint', (array) $v ) ) ) ),
			'show_in_rest'      => array(
				'schema' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'integer' ),
				),
			),
		),
		'aw_default_share_image' => array(
			'type'              => 'integer',
			'description'       => 'The site\'s default share image (attachment ID, 0 for none).',
			'default'           => 0,
			'sanitize_callback' => 'absint',
			'show_in_rest'      => array( 'schema' => array( 'type' => 'integer' ) ),
		),
		AW_SEO_DELETE_DATA       => array(
			'type'              => 'boolean',
			'description'       => 'Delete RankWeb\'s own data when the plugin is deleted.',
			'default'           => false,
			'sanitize_callback' => fn( $v ) => rest_sanitize_boolean( $v ) ? 1 : 0,
			'show_in_rest'      => array( 'schema' => array( 'type' => 'boolean' ) ),
		),
	);
}

add_action(
	'init',
	function () {
		foreach ( rankweb_seo_registered_settings() as $name => $args ) {
			register_setting( 'rankweb', $name, $args );
		}
	}
);

/** Whether RankWeb's data goes when the plugin is deleted (Modules group). */
function rankweb_seo_delete_data_on(): bool {
	return (bool) get_option( AW_SEO_DELETE_DATA, 0 );
}

/**
 * Save "Delete this plugin's data when it is deleted". Nothing is written when it is already so.
 *
 * @param bool $on On.
 */
function rankweb_seo_delete_data_save( bool $on ): bool {
	if ( rankweb_seo_delete_data_on() === $on ) {
		return false;
	}
	update_option( AW_SEO_DELETE_DATA, $on ? 1 : 0, false );
	return true;
}

/**
 * "Reset this section": every registered setting the group shows goes back to its registered default. The listings
 * kept indexed are a hand-made list of listing IDs, not a setting with a default, so they stay.
 *
 * @param string $tab Tab key.
 */
function rankweb_seo_settings_reset( string $tab ): void {
	$defaults = rankweb_seo_registered_settings();
	if ( 'modules' === $tab ) {
		rankweb_seo_settings_save( 'modules', array(), false, array_fill_keys( array_keys( rankweb_seo_modules() ), true ) ); // every module on
		rankweb_seo_delete_data_save( (bool) $defaults[ AW_SEO_DELETE_DATA ]['default'] );
		return;
	}
	rankweb_seo_settings_save( $tab, array(), true );
	if ( 'schema' === $tab && function_exists( 'rankweb_faq_type_choices' ) && array() !== rankweb_faq_off_types() ) {
		update_option( 'aw_faq_off_types', $defaults['aw_faq_off_types']['default'], false ); // stored (not deleted), so the one-time move from the old list does not run again
		delete_transient( 'aw_faq_index' );
	}
	if ( 'share' === $tab && (int) get_option( 'aw_default_share_image', 0 ) !== $defaults['aw_default_share_image']['default'] ) {
		update_option( 'aw_default_share_image', $defaults['aw_default_share_image']['default'] );
	}
}
