<?php
/**
 * Filtered hub lists (owner approved, 15 Oct 2026): /news/?category_name=wildlife, /library/?tag=rule …
 *
 * - One filter with one value, ?category_name= or ?tag=, on a section hub (not a Directory place) is a page of its own
 *   when it holds 3 or more items: its own title and description, a self-canonical, a breadcrumb step and an entry in
 *   the "filtered" sitemap. With fewer items it is noindex (links followed).
 * - ?tag= on its own section hub lists the same items as the tag page (/tag/{slug}/, indexed from 3 items, its own
 *   sitemap entry), so such a view points its canonical at the tag page instead of competing with it.
 * - Several filters at once (?category_name=a&state=b) or several values (?tag=a,b) are noindex: the combinations
 *   would multiply without end. A parameter the hub does not filter by is noindex too.
 * - ?state= and ?publisher= (one value) follow the ?category_name= rule (16 Oct 2026): from 3 items their own title
 *   ("Animal Welfare News from Kerala", "Animal Welfare News from LiveLaw"), description, breadcrumb step,
 *   self-canonical and filtered-sitemap.xml entry; fewer, noindex. They had the hub's own title before, so each one
 *   duplicated it.
 * - A view kept out of the index has the section page (without filters) as its canonical URL (owner, 17 Oct 2026).
 *   Rank Math prints no canonical tag on a noindex page, so the value shows in its data (og:url), not as a tag.
 * - ?state= on the News, Library and Opportunities hubs is noindex, follow, with the unfiltered hub as canonical, and is out of the
 *   filtered sitemap, whatever its count (owner, 24 Oct 2026: places stored on News and Library items would otherwise
 *   make some 36 such lists indexable). Opportunities too (owner, 24 Oct 2026).
 * - ?q= (a name or word search inside a list, the Directory's included) is a site search result: noindex, links
 *   followed (Google's guidance on internal search result pages).
 * - Any other single filter keeps the earlier rule (indexed, canonical with the filter).
 *
 * @package rankweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Fewest items for a filtered list to be indexed. */
// AW_FILTERED_MIN_ITEMS: RankWeb → Settings (settings.php).

/** Hubs whose ?category_name= views can be indexed (Directory listings have no categories as a filter). */
// AW_FILTERED_CATEGORY_HUBS: RankWeb → Settings (settings.php).

/**
 * Title shapes of a filtered view per section (words from the hub titles), longest first; %s is the category name.
 * No colon or comma: the only separator in a title is the " – " before Animal Writes (owner, 15 Oct 2026).
 */
// AW_FILTERED_TITLE_WORDS: RankWeb → Settings (settings.php).

/** Hubs whose ?state= views are never indexed (owner, 24 Oct 2026: News, Library, Opportunities). */
// AW_FILTERED_STATE_NOINDEX: RankWeb → Settings (settings.php).

/** Title shapes of a ?state= or ?publisher= view, longest first; %s is the state or publisher name. */
const AW_FILTERED_PLACE_TITLE_WORDS = array(
	'state'     => array(
		'aw_news'        => array( 'Animal Welfare News from %s', '%s Animal Welfare News', '%s News' ),
		'aw_legal'       => array( 'Animal Laws and Court Orders in %s', 'Animal Laws in %s', '%s Animal Laws' ),
		'aw_opportunity' => array( 'Animal Welfare Volunteer Roles and Jobs in %s', 'Animal Welfare Opportunities in %s', '%s Opportunities' ),
	),
	'publisher' => array(
		'aw_news' => array( 'Animal Welfare News from %s', '%s Animal Welfare News', '%s News' ),
	),
);

/**
 * Name and item count of a ?state= or ?publisher= view on a hub, counted with the hub's own filter clauses (open
 * opportunities only; preview-only items left out). ['', 0] when the value names nothing.
 */
function rankweb_seo_filtered_place( $type, $key, $slug ) {
	$name = '';
	if ( 'state' === $key && function_exists( 'directoryweb_place_by_slug' ) ) {
		$p    = directoryweb_place_by_slug( $slug );
		$name = $p && empty( $p->parent ) ? (string) $p->name : '';
	} elseif ( 'publisher' === $key && function_exists( 'aw_filter_values' ) ) {
		$one  = get_posts( array( 'post_type' => $type, 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => 'aw_publisher', 'meta_value' => $slug ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$vals = $one ? aw_filter_values( $one, 'publisher' ) : array();
		$name = (string) ( $vals[ $slug ][0] ?? '' );
	}
	if ( '' === $name || ! function_exists( 'aw_filter_clauses' ) ) {
		return array( '', 0 );
	}
	$n = rankweb_seo_cached(
		"filtered_place|{$type}|{$key}|{$slug}", // kept until the next post change (rankweb_seo_cached)
		function () use ( $type, $key, $slug ) {
			list( $tq, $mq ) = aw_filter_clauses( $type, array( $key => array( $slug ) ) );
			$v = array( 'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => false, 'tax_query' => $tq, 'meta_query' => $mq ); // phpcs:ignore WordPress.DB.SlowDBQuery
			return (int) ( new WP_Query( rankweb_seo_hub_rules( $type, $v ) ) )->found_posts;
		}
	);
	return array( $name, (int) $n );
}

/** Filter parameters present on this request (sort is an order, not a filter): param => raw string. */
function rankweb_seo_filter_params() {
	$out = array();
	foreach ( array_merge( AW_FILTER_PARAMS, array( 'format' ) ) as $k ) {
		if ( 'sort' !== $k && isset( $_GET[ $k ] ) && '' !== $_GET[ $k ] ) { // phpcs:ignore WordPress.Security.NonceVerification
			$out[ $k ] = is_string( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '[]'; // phpcs:ignore WordPress.Security.NonceVerification
		}
	}
	return $out;
}

/**
 * Items a hub list holds for one category or tag, with the hub's own rules (open opportunities only; preview-only
 * items left out). The same count on the page and in the sitemap. Kept until the next post change (rankweb_seo_cached).
 *
 * @param string $type Post type of the hub.
 * @param string $key  category_name|tag.
 * @param string $slug Term slug (for the Directory, a listing type such as "veterinary" too).
 * @return int
 */
function rankweb_seo_filtered_count( $type, $key, $slug ) {
	return (int) rankweb_seo_cached(
		"filtered_count|{$type}|{$key}|{$slug}", // kept until the next post change (rankweb_seo_cached)
		function () use ( $type, $key, $slug ) {
			$v = array(
				'post_type'      => $type,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
				'tax_query'      => array( array( 'taxonomy' => 'tag' === $key ? 'post_tag' : 'category', 'field' => 'slug', 'terms' => 'aw_listing' === $type && function_exists( 'directoryweb_listing_type_query' ) ? explode( ',', directoryweb_listing_type_query( $slug ) ) : array( $slug ), 'include_children' => true ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
			);
			return (int) ( new WP_Query( rankweb_seo_hub_rules( $type, $v ) ) )->found_posts;
		}
	);
}

/**
 * The filtered hub view of this request, or null when the request is not a filtered hub list.
 *
 * @return array|null [type, key, slug, name, n, index (bool), canonical (url or '')]
 */
function rankweb_seo_filtered_view() {
	static $view = false;
	if ( false !== $view ) {
		return $view;
	}
	$view = null;
	$type = function_exists( 'aw_hub_type' ) ? aw_hub_type() : '';
	if ( ! $type || is_404() || ( function_exists( 'directoryweb_current_place' ) && directoryweb_current_place() ) || get_query_var( 'aw_dir_type' ) ) {
		return $view; // not a hub, or a Directory place (its own rules, programmatic.php)
	}
	$params = rankweb_seo_filter_params();
	if ( ! $params ) {
		return $view;
	}
	$view  = array( 'type' => $type, 'key' => '', 'slug' => '', 'name' => '', 'n' => 0, 'index' => false, 'canonical' => '' );
	$key   = (string) array_key_first( $params );
	$own   = 'aw_listing' === $type ? array( 'tag', 'q', 'verified', 'gov' ) : array_column( defined( 'AW_LIST_FILTERS' ) ? ( AW_LIST_FILTERS[ $type ] ?? array() ) : array(), 0 );
	$value = (string) $params[ $key ];
	if ( count( $params ) > 1 || ! in_array( $key, $own, true ) || preg_match( '/,|%2C|\[\]/i', $value ) ) {
		return $view; // several filters, several values, or not a filter of this hub: noindex
	}
	if ( 'q' === $key ) {
		return $view; // a search inside the list: noindex, follow
	}
	if ( isset( AW_FILTERED_PLACE_TITLE_WORDS[ $key ][ $type ] ) ) { // ?state=, ?publisher=: as a category view
		$slug = sanitize_title( $value );
		list( $name, $n ) = rankweb_seo_filtered_place( $type, $key, $slug );
		if ( '' === $name ) {
			return $view; // names nothing: noindex
		}
		$view = array_merge( $view, array( 'key' => $key, 'slug' => $slug, 'name' => rankweb_plain_text( html_entity_decode( $name, ENT_QUOTES, 'UTF-8' ) ), 'n' => $n ) );
		if ( $n >= AW_FILTERED_MIN_ITEMS && ! ( 'state' === $key && in_array( $type, AW_FILTERED_STATE_NOINDEX, true ) ) ) {
			$view['index']     = true;
			$view['canonical'] = add_query_arg( $key, rawurlencode( $slug ), rankweb_hub_canonical() );
		}
		return $view;
	}
	if ( ! in_array( $key, array( 'category_name', 'tag' ), true ) ) {
		$view['index'] = true; // any other single filter: as before (indexed, canonical with the filter)
		$view['key']   = $key;
		return $view;
	}
	$slug = sanitize_title( $value );
	$term = get_term_by( 'slug', $slug, 'tag' === $key ? 'post_tag' : 'category' );
	$name = $term ? $term->name : ( 'aw_listing' === $type && 'tag' === $key && function_exists( 'directoryweb_listing_type_name' ) ? directoryweb_listing_type_name( $slug ) : '' );
	if ( '' === $name ) {
		return $view; // no such category or tag
	}
	$view['key']  = $key;
	$view['slug'] = $slug;
	$view['name'] = rankweb_plain_text( html_entity_decode( $name, ENT_QUOTES, 'UTF-8' ) );
	$view['n']    = rankweb_seo_filtered_count( $type, $key, $slug );
	if ( $view['n'] < AW_FILTERED_MIN_ITEMS ) {
		return $view;
	}
	if ( 'tag' === $key && $term && (int) $term->count >= AW_FILTERED_MIN_ITEMS ) {
		$view['canonical'] = rankweb_seo_term_url( $term ); // the tag page lists the same items and is the indexed one
		$view['index']     = true;
		return $view;
	}
	$view['index']     = true;
	$view['canonical'] = add_query_arg( $key, rawurlencode( $slug ), rankweb_hub_canonical() );
	return $view;
}

/** Whether this request is a filtered hub list that is kept out of the index. */
function rankweb_seo_filtered_noindex() {
	$v = rankweb_seo_filtered_view();
	return null !== $v && ! $v['index'];
}

/** Whether this request is a filtered hub list with a category or tag of its own (title, description, breadcrumb). */
function rankweb_seo_filtered_named() {
	$v = rankweb_seo_filtered_view();
	return null !== $v && '' !== $v['name'];
}

/**
 * "Wildlife News from India – Animal Writes": the longest shape that fits 60 characters, skipping shapes that repeat a
 * word of the category name ("Laws and Rules Laws and Court Orders").
 */
function rankweb_seo_filtered_title() {
	$v = rankweb_seo_filtered_view();
	if ( ! rankweb_seo_filtered_named() ) {
		return '';
	}
	if ( 'tag' === $v['key'] && function_exists( 'rankweb_seo_term_title' ) && ( $term = get_term_by( 'slug', $v['slug'], 'post_tag' ) ) ) {
		return rankweb_seo_title_with_page( rankweb_seo_term_title( $term ) ); // the tag page's own title (its canonical, or the same list)
	}
	$name = str_replace( ' & ', ' and ', $v['name'] );
	if ( isset( AW_FILTERED_PLACE_TITLE_WORDS[ $v['key'] ][ $v['type'] ] ) ) { // a state or publisher
		$tries = array();
		foreach ( AW_FILTERED_PLACE_TITLE_WORDS[ $v['key'] ][ $v['type'] ] as $shape ) {
			$tries[] = rankweb_seo_branded( sprintf( $shape, $name ) );
		}
		foreach ( AW_FILTERED_PLACE_TITLE_WORDS[ $v['key'] ][ $v['type'] ] as $shape ) {
			$tries[] = sprintf( $shape, $name );
		}
		return rankweb_seo_title_with_page( rankweb_seo_fit( $tries, 60 - mb_strlen( rankweb_seo_page_suffix() ) ) );
	}
	$what = array();
	$words = fn( $t ) => array_diff( preg_split( '/\W+/u', mb_strtolower( $t ), -1, PREG_SPLIT_NO_EMPTY ), array( 'and', 'in', 'on', 'of', 'the', 'from', 'india' ) );
	$all   = AW_FILTERED_TITLE_WORDS[ $v['type'] ] ?? array( '%s' );
	foreach ( $all as $shape ) {
		if ( ! array_intersect( $words( $name ), $words( str_replace( '%s', '', $shape ) ) ) ) {
			$what[] = sprintf( $shape, $name );
		}
	}
	$what  = $what ? $what : array( sprintf( (string) end( $all ), $name ) );
	$room  = 60 - mb_strlen( rankweb_seo_page_suffix() );
	$tries = array();
	foreach ( $what as $w ) {
		$tries[] = rankweb_seo_branded( $w );
	}
	foreach ( $what as $w ) {
		$tries[] = $w;
	}
	return rankweb_seo_title_with_page( rankweb_seo_fit( $tries, $room ) );
}

/** "199 stories on wildlife. Animal-welfare news from across India, summarised with a link to every source." */
function rankweb_seo_filtered_description() {
	$v = rankweb_seo_filtered_view();
	if ( ! rankweb_seo_filtered_named() ) {
		return '';
	}
	if ( 'tag' === $v['key'] && function_exists( 'rankweb_seo_tag_description' ) && ( $term = get_term_by( 'slug', $v['slug'], 'post_tag' ) ) ) {
		return rankweb_seo_with_page( rankweb_seo_tag_description( $term ) ); // as the tag page
	}
	$count = function_exists( 'aw_hub_count_label' ) ? aw_hub_count_label( $v['type'] ) : '';
	$about = 'state' === $v['key'] ? ' in ' . $v['name'] : ( 'publisher' === $v['key'] ? ' from ' . $v['name'] : ' on ' . rankweb_seo_sentence_case( str_replace( ' & ', ' and ', $v['name'] ) ) );
	$lead = '' !== $count ? $count . $about . '. ' : '';
	$desc = $lead . ( AW_ARCHIVE_DESCRIPTIONS[ $v['type'] ] ?? '' );
	return rankweb_seo_with_page( rankweb_seo_cut( $desc, 155 - mb_strlen( rankweb_seo_page_suffix() ) ) );
}

// Robots: the filtered views that are not their own page.
add_filter(
	'rank_math/frontend/robots',
	function ( $robots ) {
		$search = function_exists( 'aw_hub_type' ) && aw_hub_type() && isset( $_GET['q'] ) && '' !== $_GET['q']; // phpcs:ignore WordPress.Security.NonceVerification
		if ( rankweb_seo_filtered_noindex() || $search ) { // ?q= on a Directory place too
			$robots['index'] = 'noindex';
		}
		return $robots;
	},
	22
);

// Title and description of a named filtered view (they win over the hub Page's own, which belong to the plain list).
// The Directory's filtered views keep the titles built for them in titles.php and programmatic.php.
add_filter(
	'rank_math/frontend/title',
	function ( $title ) {
		$v    = rankweb_seo_filtered_view();
		$ours = $v && 'aw_listing' !== $v['type'] ? rankweb_seo_filtered_title() : '';
		return '' !== $ours ? $ours : $title;
	},
	25
);
add_filter(
	'rank_math/frontend/description',
	function ( $desc ) {
		$v    = rankweb_seo_filtered_view();
		$ours = $v && 'aw_listing' !== $v['type'] ? rankweb_seo_filtered_description() : '';
		return '' !== $ours ? $ours : $desc;
	},
	25
);

/* ---------- The URLs of filtered-sitemap.xml (the sitemap itself: sitemap.php, rebuilt daily) ---------- */

/**
 * The indexable ?category_name=, ?state= and ?publisher= views of every hub (3 or more items each). ?tag= views are
 * not listed: their tag pages are (Rank Math's tag sitemap).
 *
 * @return array List of ['loc' => URL].
 */
function rankweb_sitemap_filtered_build() {
	$urls = array();
	if ( ! function_exists( 'aw_hub_url' ) ) { // the hubs (Animal Writes Core) are not loaded
		return $urls;
	}
	foreach ( AW_FILTERED_CATEGORY_HUBS as $type ) {
		$cats = function_exists( 'aw_section_categories' ) ? aw_section_categories( $type ) : array();
		foreach ( (array) $cats as $slug ) {
			if ( rankweb_seo_filtered_count( $type, 'category_name', (string) $slug ) >= AW_FILTERED_MIN_ITEMS ) {
				$urls[] = array( 'loc' => add_query_arg( 'category_name', rawurlencode( (string) $slug ), aw_hub_url( $type ) ) );
			}
		}
	}
	foreach ( AW_FILTERED_PLACE_TITLE_WORDS as $key => $types ) { // ?state= and ?publisher= views from 3 items (17 Oct 2026)
		foreach ( array_keys( $types ) as $type ) {
			if ( 'state' === $key && in_array( $type, AW_FILTERED_STATE_NOINDEX, true ) ) {
				continue; // noindex (owner, 24 Oct 2026)
			}
			foreach ( rankweb_sitemap_filtered_values( $type, $key ) as $slug ) {
				if ( rankweb_seo_filtered_place( $type, $key, $slug )[1] >= AW_FILTERED_MIN_ITEMS ) {
					$urls[] = array( 'loc' => add_query_arg( $key, rawurlencode( $slug ), aw_hub_url( $type ) ) );
				}
			}
		}
	}
	return $urls;
}

/**
 * Candidate ?state= or ?publisher= values of a hub: the states and publishers its published items carry at least
 * AW_FILTERED_MIN_ITEMS times (the exact count, with the hub's own rules, comes from rankweb_seo_filtered_place()).
 *
 * @return string[] URL values (state slugs, publisher keys).
 */
function rankweb_sitemap_filtered_values( $type, $key ) {
	global $wpdb;
	$meta = 'state' === $key ? 'aw_state_code' : 'aw_publisher';
	$rows = $wpdb->get_col( $wpdb->prepare( "SELECT m.meta_value FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = %s AND p.post_type = %s AND p.post_status = 'publish' GROUP BY m.meta_value HAVING COUNT( DISTINCT p.ID ) >= %d", $meta, $type, AW_FILTERED_MIN_ITEMS ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	if ( 'publisher' === $key ) {
		return array_values( array_filter( array_map( 'sanitize_title', $rows ) ) );
	}
	$out = array();
	foreach ( $rows as $code ) {
		$s = function_exists( 'directoryweb_place_state' ) ? directoryweb_place_state( $code ) : null;
		if ( $s ) {
			$out[] = (string) $s->slug;
		}
	}
	return array_values( array_unique( $out ) );
}
