<?php
/**
 * The site's own JSON-LD nodes, put into Rank Math's one graph (Rank Math's schema templates cannot build these from
 * the site's fields):
 *
 * - Listings: NGO / VeterinaryCare / AnimalShelter / GovernmentOffice (by listing type, several allowed) with
 *   name, URL, logo, locality/region, contact details when present, the official website as sameAs, identifiers
 *   (AWBI code, registration, 12A, 80G, Darpan), services, opening hours, donate and volunteer actions.
 * - News, Library and Resources: one purpose-made node per type and sub-type (rankweb_article_nodes: NewsArticle,
 *   Legislation, Article on a court ruling / press release / government document, DigitalDocument, Article,
 *   Article on a ScholarlyArticle). A guide's FAQPage is Rank Math's own (its FAQ block). Opportunities: JobPosting for
 *   open jobs, internships, fellowships and volunteering (none once closed, none for events or fostering). Campaigns:
 *   Event when the day and the place are stored, else CreativeWork. Rank Math's Titles & Meta hold each type's schema type; these
 *   nodes replace its default, which cannot carry these properties.
 * - Section hubs, Directory places and category pages: CollectionPage + ItemList of the page's items. Categories
 *   page: CollectionPage + ItemList of the categories. Media & PR: CollectionPage of press items. Contact: ContactPage. About: AboutPage.
 * - FAQPage (listings, Library documents, type/service/category pages, four hubs): parsed from the page's own FAQ
 *   accordion (faq.php, in this plugin), so its text is the visible text; isPartOf the page, about its main entity.
 * - Every page: the publisher (Organization, with publishing and corrections policies) and the site (WebSite),
 *   replacing Rank Math's defaults (same @id); the WebSite has no SearchAction. The BreadcrumbList is Rank Math's
 *   own (breadcrumbs.php gives it the trail people see).
 *   Every node's inLanguage is en-IN (Rank Math writes the WordPress locale, en-US, on its WebPage).
 * - Every picture in these nodes is a share-safe address (rankweb_seo_share_safe_url(): never AVIF or WebP, like og:image),
 *   in its own shape (og:image is the 1080x1080 share square).
 *
 * @package rankweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A phone number as schema.org wants it, in E.164 ("+919962998886"): the digits with the country code and no spaces,
 * dashes or trunk 0 (directoryweb_normalise_phone in animal-writes-core). A short helpline code such as 1962 is left as it is.
 *
 * @param string $raw The number as stored ("+91 99629 98886", "0471-2467700", "1962").
 * @return string '' when the number has no digits.
 */
function rankweb_seo_e164( $raw ) {
	$d = function_exists( 'directoryweb_normalise_phone' ) ? directoryweb_normalise_phone( $raw ) : preg_replace( '/\D+/', '', (string) $raw );
	if ( '' === $d ) {
		return '';
	}
	return strlen( $d ) <= 5 ? $d : '+' . $d;
}

/**
 * Organization data for a listing.
 *
 * @param int $id Post ID.
 * @return array
 */
function rankweb_listing_schema( $id ) {
	if ( ! function_exists( 'directoryweb_listing_place' ) || ! function_exists( 'directoryweb_listing_sources' ) ) { // DirectoryWeb is off
		return array();
	}
	list( $state, $district ) = directoryweb_listing_place( $id );
	$m    = fn( $k ) => trim( (string) get_post_meta( $id, $k, true ) );
	// schema.org type by listing type; a listing with several types gets several (@type as a list).
	$map   = array(
		'VeterinaryCare'         => array( 'veterinary-hospital', 'veterinary-clinic', 'veterinary-dispensary', 'bird-hospital', 'mobile-veterinary-unit' ),
		'AnimalShelter'          => array( 'animal-shelter', 'gaushala', 'sanctuary' ),
		'GovernmentOffice'       => array( 'veterinary-office', 'mobile-veterinary-unit' ), // a government office the public visits
	);
	$stype = array();
	foreach ( $map as $t => $slugs ) {
		if ( has_term( $slugs, 'post_tag', $id ) ) {
			$stype[] = $t;
		}
	}
	if ( in_array( 'VeterinaryCare', $stype, true ) && ! in_array( 'GovernmentOffice', $stype, true ) && array_intersect( array( 'gov', 'gujforest' ), wp_list_pluck( directoryweb_listing_sources( $id ), 0 ) ) ) {
		$stype[] = 'GovernmentOffice'; // a government vet (from a government list)
	}
	$srcs = wp_list_pluck( directoryweb_listing_sources( $id ), 0 );
	if ( has_term( 'legal-aid', 'post_tag', $id ) && in_array( 'nalsa', $srcs, true ) ) {
		$stype[] = 'GovernmentOffice'; // a District Legal Services Authority: a government office, not an NGO
	}
	$ngo = array( 'animal-welfare-organisation', 'abc-centre', 'rescue-group', 'adoption-network', 'feeder-network', 'emergency-rescue', 'wildlife-rescue', 'animal-ambulance' );
	if ( ! in_array( 'nalsa', $srcs, true ) ) {
		$ngo[] = 'legal-aid';
	}
	if ( ! $stype || has_term( $ngo, 'post_tag', $id ) ) {
		array_unshift( $stype, 'NGO' );
	}
	$stype = array_values( array_unique( $stype ) );
	$site  = $m( 'aw_website' );
	$org   = array(
		'@type'       => 1 === count( $stype ) ? $stype[0] : $stype,
		'@id'         => get_permalink( $id ) . '#organization',
		'name'        => rankweb_plain_text( get_post_field( 'post_title', $id ) ), // no "Private:" prefix
		'url'         => $site ? $site : get_permalink( $id ),                 // the organisation's own site when known
		'mainEntityOfPage' => get_permalink( $id ),                           // this profile
		'description' => rankweb_plain_text( get_the_excerpt( $id ) ),
	);
	$logo = rankweb_schema_safe_url( (string) get_the_post_thumbnail_url( $id, 'medium' ) );
	if ( $logo ) {
		$org['logo']  = $logo;
		$org['image'] = $logo;
	}
	if ( $state || $district ) {
		$street = $m( 'aw_address' ) ? $m( 'aw_address' ) : $m( 'aw_area' ); // the full address when a source gives it
		$rest   = str_ireplace( array_filter( array( $district, $state, (string) apply_filters( 'rankweb_country_name', '' ) ) ), '', $street );
		if ( '' === trim( preg_replace( '/[\s,.\-–]+/u', '', $rest ) ) ) {
			$street = ''; // only repeats the district and state
		}
		$org['address'] = array_filter( array( '@type' => 'PostalAddress', 'streetAddress' => $street, 'addressLocality' => $district, 'addressRegion' => $state, 'postalCode' => $m( 'aw_pincode' ), 'addressCountry' => 'IN' ) );
		$org['areaServed'] = array_values( array_filter( array( $district ? array( '@type' => 'AdministrativeArea', 'name' => $district ) : null, $state ? array( '@type' => 'State', 'name' => $state ) : null ) ) );
		foreach ( array_filter( array_map( 'trim', explode( ',', $m( 'aw_areas_served' ) ) ) ) as $area ) { // as the organisation states them
			if ( ! in_array( $area, array( $district, $state ), true ) ) {
				$org['areaServed'][] = array( '@type' => 'Place', 'name' => $area );
			}
		}
	}
	// Phone numbers from the list: every number as telephone (one, or a list), and each number marked WhatsApp as a
	// WhatsApp contact point.
	$phones = function_exists( 'directoryweb_listing_phones' ) ? directoryweb_listing_phones( $id ) : array();
	$tels   = array_values( array_unique( array_filter( array_map( 'rankweb_seo_e164', wp_list_pluck( $phones, 'number' ) ) ) ) );
	if ( $tels ) {
		$org['telephone'] = 1 === count( $tels ) ? $tels[0] : $tels;
	}
	if ( $m( 'aw_email' ) ) {
		$org['email'] = $m( 'aw_email' );
	}
	$wa = array();
	foreach ( $phones as $p ) {
		if ( $p['whatsapp'] ) {
			$wa[] = array( '@type' => 'ContactPoint', 'contactType' => 'WhatsApp', 'telephone' => rankweb_seo_e164( $p['number'] ), 'availableLanguage' => array( 'en', 'hi' ) );
		}
	}
	if ( $wa ) {
		$org['contactPoint'] = 1 === count( $wa ) ? $wa[0] : $wa;
	}
	$same = array_values( array_filter( array( $site, $m( 'aw_g_profile' ), $m( 'aw_instagram' ), $m( 'aw_facebook' ), $m( 'aw_x' ), $m( 'aw_youtube' ), $m( 'aw_linkedin' ), $m( 'aw_wikidata' ) ? 'https://www.wikidata.org/wiki/' . $m( 'aw_wikidata' ) : '' ) ) );
	if ( $same ) {
		$org['sameAs'] = $same;
	}
	if ( $m( 'aw_maps_url' ) ) {
		$org['hasMap'] = $m( 'aw_maps_url' );
	}
	if ( is_numeric( $m( 'aw_lat' ) ) && is_numeric( $m( 'aw_lng' ) ) ) {
		$org['geo'] = array( '@type' => 'GeoCoordinates', 'latitude' => (float) $m( 'aw_lat' ), 'longitude' => (float) $m( 'aw_lng' ) );
	}
	// The Google rating is shown on the page only: Google does not accept third-party ratings in an organisation's schema.
	$own    = function_exists( 'directoryweb_listing_photo_ids' ) ? directoryweb_listing_photo_ids( $id ) : array_filter( explode( ',', $m( 'aw_gallery' ) ) ); // never stock or CC images
	$photos = array_values( array_filter( array_map( fn( $p ) => rankweb_schema_safe_url( (string) wp_get_attachment_image_url( (int) $p, 'large' ) ), $own ) ) );
	if ( $photos ) {
		$org['image'] = array_values( array_unique( array_merge( (array) ( $org['image'] ?? array() ), $photos ) ) );
	}
	if ( $m( 'aw_founded' ) ) {
		$org['foundingDate'] = $m( 'aw_founded' );
	}
	if ( $m( 'aw_languages' ) ) {
		$org['knowsLanguage'] = array_values( array_filter( array_map( 'trim', explode( ',', $m( 'aw_languages' ) ) ) ) );
	}
	// Opening hours by day, from the list.
	$spec = function_exists( 'directoryweb_hours_rows_spec' ) ? directoryweb_hours_rows_spec( directoryweb_listing_hours( $id ) ) : array();
	if ( $spec ) {
		$org['openingHoursSpecification'] = $spec;
	}

	$svc = function_exists( 'directoryweb_listing_service_names' ) ? directoryweb_listing_service_names( $id ) : array();
	if ( $svc ) {
		$org['knowsAbout'] = array_values( $svc ); // the fixed services list
	} elseif ( $m( 'aw_services' ) ) {
		$org['knowsAbout'] = array_values( array_filter( array_map( 'trim', preg_split( '/[,;\n]+/', wp_strip_all_tags( $m( 'aw_services' ) ) ) ) ) );
	}
	// Everything else the listing states (owner, 12 Oct 2026): services as a catalogue, the head of the organisation,
	// and the donate / volunteer links as actions.
	if ( ! empty( $org['knowsAbout'] ) ) {
		$org['hasOfferCatalog'] = array(
			'@type'           => 'OfferCatalog',
			'name'            => 'Services',
			'itemListElement' => array_map( fn( $s ) => array( '@type' => 'Offer', 'itemOffered' => array( '@type' => 'Service', 'name' => $s ) ), $org['knowsAbout'] ),
		);
	}
	if ( $m( 'aw_head' ) ) { // "Name, Role" as the organisation states it
		$head            = array_map( 'trim', explode( ',', wp_strip_all_tags( $m( 'aw_head' ) ), 2 ) );
		$org['founder']  = null; // only when the stated role says so
		$person          = array_filter( array( '@type' => 'Person', 'name' => $head[0], 'jobTitle' => $head[1] ?? '' ) );
		if ( isset( $head[1] ) && preg_match( '/found/i', $head[1] ) ) {
			$org['founder'] = $person;
		} else {
			$org['employee'] = $person;
		}
		$org = array_filter( $org, fn( $v ) => null !== $v );
	}
	$acts = array();
	// No DonateAction: no money anywhere on the site (owner, 31 Oct 2026).
	if ( $m( 'aw_volunteer_url' ) ) {
		$acts[] = array( '@type' => 'JoinAction', 'name' => 'Volunteer', 'target' => esc_url_raw( $m( 'aw_volunteer_url' ) ) );
	}
	if ( $acts ) {
		$org['potentialAction'] = 1 === count( $acts ) ? $acts[0] : $acts;
	}
	$types = function_exists( 'directoryweb_listing_types' ) ? directoryweb_listing_types( $id ) : array();
	if ( $types ) {
		$org['keywords'] = implode( ', ', array_filter( array_merge( wp_list_pluck( $types, 'name' ), array( $m( 'aw_g_category' ) ) ) ) ); // additionalType must be a URL; the type names (and Google's category) go here
	}
	$code = $m( 'aw_awbi_code' );
	if ( $code ) {
		$org['identifier'] = array( '@type' => 'PropertyValue', 'propertyID' => 'AWBI recognition code', 'value' => $code );
		if ( $m( 'aw_awbi_dropped' ) ) { // on an older AWBI list only
			$org['identifier']['description'] = 'Not on the AWBI list of ' . wp_date( 'j M Y', strtotime( $m( 'aw_awbi_dropped' ) ) ) . '; recognition may have lapsed';
		}
	}
	$ids = isset( $org['identifier'] ) ? array( $org['identifier'] ) : array();
	foreach ( array( 'aw_registration' => 'Registration', 'aw_reg_12a' => '12A', 'aw_reg_80g' => '80G', 'aw_fcra' => 'FCRA', 'aw_darpan_id' => 'NGO Darpan ID' ) as $k => $pid ) {
		if ( $m( $k ) ) { // as the organisation states them; words without a number are a note, not an identifier
			$ids[] = preg_match( '/\d/', $m( $k ) ) ? array( '@type' => 'PropertyValue', 'propertyID' => $pid, 'value' => $m( $k ) ) : array( '@type' => 'PropertyValue', 'propertyID' => $pid, 'description' => $m( $k ) );
		}
	}
	if ( $ids ) {
		$org['identifier'] = 1 === count( $ids ) ? $ids[0] : $ids;
	}
	if ( function_exists( 'directoryweb_featured_subject_schema' ) && directoryweb_featured_subject_schema( $id ) ) {
		$org['subjectOf'] = directoryweb_featured_subject_schema( $id ); // what it is featured in: news, Library, resources, press, campaigns
	}
	if ( function_exists( 'directoryweb_org_people_schema' ) && directoryweb_org_people_schema( $id ) ) {
		$org['member'] = directoryweb_org_people_schema( $id ); // volunteers shown on the page (OrganizationRole, roleName Volunteer)
	}
	return array_filter( $org );
}

/* ---------- Site and content pages ---------- */

/**
 * A Rank Math setting (Titles & Meta → Local SEO / Social Meta), '' when Rank Math does not hold it.
 *
 * @param string $key Setting under "titles.".
 * @return mixed
 */
function rankweb_seo_rm_setting( $key ) {
	return class_exists( '\RankMath\Helper' ) ? \RankMath\Helper::get_settings( 'titles.' . $key ) : '';
}

/**
 * The publisher's profiles (sameAs): Rank Math's Facebook URL and additional profiles (Titles & Meta → Social Meta),
 * else the profiles the site footer links to. One node for both: Rank Math's own publisher is replaced by this one.
 *
 * @return array
 */
function rankweb_publisher_profiles() {
	$list = array_merge( array( (string) rankweb_seo_rm_setting( 'social_url_facebook' ) ), preg_split( '/\s+/', (string) rankweb_seo_rm_setting( 'social_additional_profiles' ) ) );
	$list = array_values( array_unique( array_filter( array_map( 'trim', $list ), fn( $u ) => (bool) wp_http_validate_url( $u ) ) ) );
	return $list ? $list : (array) rankweb_site_default( 'same_as', array() ); // the site's profiles, set in Rank Math or RankWeb; none by default
}

/**
 * Profile links in the graph use x.com: Rank Math builds https://twitter.com/{Twitter username} from its Social Meta
 * setting (kept for the twitter:site tag) next to the x.com address in the additional profiles. Each sameAs list is
 * rewritten to x.com and de-duplicated, in any node.
 *
 * @param mixed $node Graph or node.
 * @return mixed
 */
function rankweb_schema_x_profiles( $node ) {
	if ( ! is_array( $node ) ) {
		return $node;
	}
	foreach ( $node as $k => $v ) {
		if ( 'sameAs' === $k && ( is_array( $v ) || is_string( $v ) ) ) {
			$list = array_map( fn( $u ) => is_string( $u ) ? preg_replace( '#^https?://(www\.)?twitter\.com/#i', 'https://x.com/', $u ) : $u, (array) $v );
			$node[ $k ] = is_string( $v ) ? $list[0] : array_values( array_unique( $list, SORT_REGULAR ) );
		} elseif ( is_array( $v ) ) {
			$node[ $k ] = rankweb_schema_x_profiles( $v );
		}
	}
	return $node;
}

/**
 * The publisher as schema.org Organization: name, URL, logo, email, description and profiles from
 * Rank Math's Knowledge Graph settings (Titles & Meta → Local SEO, Social Meta), so the settings and the graph agree;
 * the alternate names, policies, categories and country served are added here (Rank Math has no fields for them).
 */
function rankweb_publisher_schema() {
	$logo  = (string) rankweb_seo_rm_setting( 'knowledgegraph_logo' );
	$logo  = '' !== $logo ? $logo : get_site_icon_url( 512 );
	$lmeta = wp_get_attachment_metadata( (int) rankweb_seo_rm_setting( 'knowledgegraph_logo_id' ) );
	$front = (int) get_option( 'page_on_front' );
	$desc  = (string) rankweb_seo_rm_setting( 'organization_description' );
	$desc  = '' !== trim( $desc ) ? $desc : ( $front ? (string) get_post_meta( $front, 'rank_math_description', true ) : '' ); // the home page's meta description
	$desc  = '' !== trim( $desc ) ? $desc : ( $front ? (string) get_post_field( 'post_excerpt', $front ) : '' );
	$desc  = '' !== trim( $desc ) ? $desc : get_bloginfo( 'description' );
	$email = sanitize_email( (string) rankweb_seo_rm_setting( 'email' ) );
	$email = '' !== $email ? $email : sanitize_email( (string) apply_filters( 'rankweb_contact_email', (string) rankweb_site_default( 'email', '' ) ) ); // none unless the site sets one
	$name  = trim( (string) rankweb_seo_rm_setting( 'knowledgegraph_name' ) );
	$about = get_terms( array( 'taxonomy' => rankweb_seo_category_tax(), 'hide_empty' => true, 'fields' => 'names' ) );
	$pages = array();
	foreach ( array( 'publishingPrinciples' => 'editorial-policy', 'correctionsPolicy' => 'corrections' ) as $k => $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page && 'publish' === $page->post_status ) {
			$pages[ $k ] = get_permalink( $page );
		}
	}
	$node = array_filter(
		array_merge(
			array(
				'@type'         => 'Organization',
				'@id'           => home_url( '/#organization' ),
				'name'          => '' !== $name ? $name : get_bloginfo( 'name' ),
				'alternateName' => AW_SITE_ALT_NAMES,
				'url'           => home_url( '/' ),
				'description'   => rankweb_plain_text( $desc ),
				'logo'          => $logo ? array_filter( array( '@type' => 'ImageObject', 'url' => $logo, 'width' => (int) ( $lmeta['width'] ?? 0 ), 'height' => (int) ( $lmeta['height'] ?? 0 ) ) ) : null,
				'email'         => '' !== $email ? $email : null,
				'contactPoint'  => '' !== $email ? array_filter( array( '@type' => 'ContactPoint', 'contactType' => 'customer support', 'email' => $email, 'url' => ( get_page_by_path( 'contact' ) ? home_url( '/contact/' ) : '' ), 'areaServed' => (string) rankweb_site_default( 'country', '' ), 'availableLanguage' => (array) rankweb_site_default( 'languages', array() ) ) ) : null,
				'address'       => '' !== (string) rankweb_site_default( 'country', '' ) ? array( '@type' => 'PostalAddress', 'addressCountry' => (string) rankweb_site_default( 'country', '' ) ) : null, // the country only: no public street address or phone (owner, 3 Nov 2026)
				'foundingDate'  => (string) rankweb_site_default( 'founded', '' ) ?: null,
				'areaServed'    => '' !== (string) rankweb_site_default( 'country', '' ) ? array( '@type' => 'Country', 'name' => (string) rankweb_site_default( 'country_name', '' ), 'identifier' => (string) rankweb_site_default( 'country', '' ) ) : null,
				'knowsAbout'    => is_array( $about ) ? array_values( array_map( 'rankweb_plain_text', $about ) ) : null,
				'sameAs'        => rankweb_publisher_profiles(),
			),
			$pages
		)
	);
	/**
	 * The Organization node before it is printed: a site adds what is its own (address country, founding date, area served).
	 *
	 * @param array $node Organization node.
	 */
	return (array) apply_filters( 'rankweb_organization_node', $node );
}

/**
 * A date as full ISO 8601 with offset; a bare date (Y-m-d) becomes 09:00 India time.
 *
 * @param string $date Date.
 * @return string
 */
function rankweb_schema_date( $date ) {
	$date = trim( (string) $date );
	if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
		return $date . 'T09:00:00+05:30';
	}
	$ts = $date ? strtotime( $date ) : false;
	return $ts ? wp_date( 'c', $ts ) : '';
}

/**
 * A picture address as og:image gives it: an AVIF or WebP upload as its original JPEG or PNG, or its share JPEG
 * (rankweb_seo_share_safe_url(), helpers.php). '' stays ''.
 *
 * @param string $url Picture address.
 * @return string
 */
function rankweb_schema_safe_url( $url ) {
	return '' === (string) $url ? '' : (string) rankweb_seo_share_safe_url( (string) $url )[0];
}

/**
 * A picture (as rankweb_seo_attachment(): url, width, height) with a share-safe address, and that file's own size when the
 * address changed. Null stays null.
 *
 * @param array|null $img Picture.
 * @return array|null
 */
function rankweb_schema_safe_image( $img ) {
	if ( ! is_array( $img ) || empty( $img['url'] ) ) {
		return $img;
	}
	list( $url, $w, $h ) = rankweb_seo_share_safe_url( (string) $img['url'] );
	if ( $url === $img['url'] ) {
		return $img;
	}
	$img['url']    = $url;
	$img['width']  = (int) $w; // the new file's own size (0 when unknown)
	$img['height'] = (int) $h;
	return $img;
}

/**
 * ImageObject for an item: the same image its og:image uses (helpers.php: for ingested items the publisher's own
 * image, linked), with its size when known. Null when the site has no image to give.
 *
 * @param int $id Post ID.
 * @return array|null
 */
function rankweb_schema_image( $id ) {
	$img = ( is_singular() && get_queried_object_id() === (int) $id ) ? rankweb_seo_image() : ( rankweb_seo_item_image( $id ) ? rankweb_seo_item_image( $id ) : rankweb_seo_default_image() );
	$img = rankweb_schema_safe_image( $img );
	if ( $img && false !== strpos( html_entity_decode( $img['url'] ), '&' ) ) { // printed through wp_kses (& as &amp;): the plain address, as og:image
		$img = array( 'url' => strtok( html_entity_decode( $img['url'] ), '?' ), 'width' => 0, 'height' => 0 );
	}
	return $img ? array_filter( array( '@type' => 'ImageObject', 'url' => $img['url'], 'width' => $img['width'], 'height' => $img['height'] ) ) : null;
}

/**
 * The site's categories on an item, as schema.org Things (about).
 *
 * @param int $id Post ID.
 * @return array|null
 */
function rankweb_schema_categories( $id ) {
	$names = wp_get_object_terms( $id, rankweb_seo_category_tax(), array( 'fields' => 'names' ) );
	if ( ! $names || is_wp_error( $names ) ) {
		return null;
	}
	return array_map( fn( $n ) => array( '@type' => 'Thing', 'name' => rankweb_plain_text( $n ) ), array_values( $names ) );
}

/** The item's place (district and state, when stored) as a Place, or null. */
function rankweb_schema_place( $id ) {
	list( $state, $district ) = function_exists( 'directoryweb_item_place_names' ) ? directoryweb_item_place_names( $id ) : array( '', '' );
	if ( ! $state && ! $district ) {
		return null;
	}
	return array(
		'@type'   => 'Place',
		'name'    => implode( ', ', array_filter( array( $district, $state ) ) ),
		'address' => array_filter( array( '@type' => 'PostalAddress', 'addressLocality' => $district, 'addressRegion' => $state, 'addressCountry' => 'IN' ) ),
	);
}

/**
 * The document's PDF as a MediaObject: the file hosted here (aw_file_id), else the source address when it is a PDF.
 *
 * @param int $id Post ID.
 * @return array|null
 */
function rankweb_schema_pdf( $id ) {
	$att = (int) get_post_meta( $id, 'aw_file_id', true );
	$url = $att && 'application/pdf' === get_post_mime_type( $att ) ? (string) wp_get_attachment_url( $att ) : '';
	if ( '' === $url ) {
		$src = (string) get_post_meta( $id, 'aw_source_url', true );
		$url = preg_match( '/\.pdf$/i', (string) wp_parse_url( $src, PHP_URL_PATH ) ) ? $src : '';
	}
	return $url ? array( '@type' => 'MediaObject', 'contentUrl' => $url, 'encodingFormat' => 'application/pdf' ) : null;
}

/** The issuing body of a Library item (court, ministry, board) as a GovernmentOrganization, or null. */
function rankweb_schema_issuer( $id ) {
	$iss = function_exists( 'aw_item_issuer' ) ? aw_item_issuer( $id ) : null;
	return $iss ? array( '@type' => 'GovernmentOrganization', 'name' => rankweb_plain_text( $iss->name ) ) : null;
}

/**
 * The item's own schema node, purpose-made by type and sub-type (see the file header). Only stored values are used.
 *
 * - News: NewsArticle; the source article (isBasedOn), its publisher (sourceOrganization), the other reports of the
 *   same event (citation), categories (about), place (contentLocation).
 * - Library: Acts, Rules and Notifications as Legislation (type, date, jurisdiction, the PDF as encoding, the issuing
 *   body as sourceOrganization); judgments and orders as our Article on the court's ruling (a CreativeWork by the
 *   court); official releases as our Article on the issuer's press release; circulars, advisories and other documents
 *   as our Article on the issuer's DigitalDocument; templates as a DigitalDocument.
 * - Resources: guides as Article (FAQPage comes from Rank Math's FAQ block); research summaries as Article based on
 *   the ScholarlyArticle (DOI, journal).
 *
 * @param int $id Post ID.
 * @return array List of nodes (the main one first).
 */
function rankweb_article_nodes( $id ) {
	$type     = get_post_type( $id );
	$url      = get_permalink( $id );
	$title    = rankweb_plain_text( get_the_title( $id ) );
	$kind     = 'aw_legal' === $type && function_exists( 'aw_legal_kinds' ) ? ( aw_legal_kinds( $id )[0] ?? null ) : null; // the Library type tag (never a label such as a campaign tag)
	$ks       = $kind ? $kind->slug : '';
	$src_url  = (string) get_post_meta( $id, 'aw_source_url', true );
	$src_name = rankweb_plain_text( (string) get_post_meta( $id, 'aw_source_name', true ) );
	$src_date = rankweb_schema_date( (string) get_post_meta( $id, 'aw_source_date', true ) );
	$reviewed = (string) get_post_meta( $id, 'kits_last_reviewed', true ); // crisis guides: the date they were last checked
	$issuer   = 'aw_legal' === $type ? rankweb_schema_issuer( $id ) : null;
	$pdf      = 'aw_legal' === $type ? rankweb_schema_pdf( $id ) : null;
	$us       = array( '@id' => home_url( '/#organization' ) );
	$base     = array(
		'mainEntityOfPage' => $url,
		'url'              => $url,
		'description'      => function_exists( 'aw_text' ) ? rankweb_plain_text( aw_text( $id, 40 ) ) : '',
		'datePublished'    => get_the_date( 'c', $id ),
		'dateModified'     => $reviewed ? rankweb_schema_date( $reviewed ) : get_the_modified_date( 'c', $id ),
		'inLanguage'       => rankweb_language(),
		'image'            => rankweb_schema_image( $id ),
		'about'            => rankweb_schema_categories( $id ),
	);
	$article = array_merge( array( '@type' => 'Article', '@id' => $url . '#article', 'headline' => $title ), $base, array( 'author' => $us, 'publisher' => $us ) );
	$nodes   = array();

	if ( 'aw_news' === $type ) {
		$node = array_merge( $article, array( '@type' => 'NewsArticle' ) );
		if ( $src_date ) {
			$node['datePublished'] = $src_date; // the day the story was reported
		}
		$outlet = $src_name ? array( '@type' => 'NewsMediaOrganization', 'name' => $src_name ) : null; // references are CreativeWork, so search engines see one article
		if ( $outlet ) {
			$node['sourceOrganization'] = $outlet;
		}
		if ( $src_url ) {
			$node['isBasedOn'] = array_filter( array( '@type' => 'CreativeWork', 'genre' => 'News report', 'url' => $src_url, 'publisher' => $outlet, 'datePublished' => $src_date ) );
		}
		$also = array();
		foreach ( (array) get_post_meta( $id, 'aw_also_reported', true ) as $r ) {
			if ( is_array( $r ) && ! empty( $r['url'] ) ) { // later reports of the same event
				$also[] = array_filter( array( '@type' => 'CreativeWork', 'genre' => 'News report', 'url' => (string) $r['url'], 'publisher' => empty( $r['name'] ) ? null : array( '@type' => 'NewsMediaOrganization', 'name' => rankweb_plain_text( $r['name'] ) ) ) );
			}
		}
		if ( $also ) {
			$node['citation'] = $also;
		}
		$node['contentLocation'] = rankweb_schema_place( $id );
		$node['author']          = array( // the editorial team, with its policy page (owner, 12 Nov 2026: Google News and Discover)
			'@type'              => 'Organization',
			'name'               => sprintf( /* translators: %s: site name. */ __( '%s editorial team', 'rankweb' ), rankweb_site_name() ),
			'url'                => home_url( '/editorial-policy/' ),
			'parentOrganization' => $us,
		);
		$nodes[]                 = $node;
	} elseif ( in_array( $ks, array( 'act', 'rule', 'notification' ), true ) ) {
		$node = array_merge(
			array(
				'@type'                   => 'Legislation',
				'@id'                     => $url . '#legislation',
				'name'                    => $title,
				'legislationType'         => rankweb_plain_text( $kind->name ),
				'legislationJurisdiction' => 'IN',
			),
			$base
		);
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) get_post_meta( $id, 'aw_source_date', true ) ) ) {
			$node['legislationDate'] = (string) get_post_meta( $id, 'aw_source_date', true ); // the date of the text, as stored
		}
		$number = trim( (string) get_post_meta( $id, 'aw_legal_number', true ) );
		$force  = (string) get_post_meta( $id, 'aw_legal_force', true );
		if ( '' !== $number ) {
			$node['legislationIdentifier'] = rankweb_plain_text( $number );
		}
		if ( in_array( $force, array( 'InForce', 'NotInForce', 'PartiallyInForce' ), true ) ) {
			$node['legislationLegalForce'] = 'https://schema.org/' . $force;
		}
		$node['encoding']           = $pdf;
		$node['sourceOrganization'] = $issuer; // the body whose copy this is (it may not be the law-maker)
		$node['isBasedOn']          = $src_url ? array_filter( array( '@type' => 'CreativeWork', 'url' => $src_url, 'publisher' => $issuer ) ) : null;
		$nodes[]                    = $node;
	} elseif ( 'aw_legal' === $type && 'template' === $ks ) {
		$nodes[] = array_merge(
			array( '@type' => 'DigitalDocument', '@id' => $url . '#document', 'name' => $title, 'genre' => rankweb_plain_text( $kind->name ), 'encodingFormat' => 'text/html' ),
			$base,
			array( 'author' => $us, 'publisher' => $us )
		);
	} elseif ( 'aw_legal' === $type ) {
		$court = $issuer && function_exists( 'aw_item_issuer' ) && defined( 'AW_COURT_ISSUERS' ) && in_array( aw_item_issuer( $id )->slug, AW_COURT_ISSUERS, true );
		$doc   = array_filter(
			array(
				'@type'         => 'CreativeWork',
				'name'          => $title,
				'url'           => $src_url ? $src_url : null,
				'author'        => $issuer,
				'datePublished' => $src_date,
				'encoding'      => $pdf,
			)
		);
		if ( $court || in_array( $ks, array( 'judgment', 'order' ), true ) ) {
			$doc['genre']     = 'order' === $ks ? 'Court order' : 'Court judgment';
			$article['genre'] = $doc['genre'];
			if ( $issuer ) {
				$article['about'] = array_merge( array( $issuer ), (array) $article['about'] );
			}
			$order = rankweb_court_document_url( $id );
			if ( $order ) {
				$article['citation'] = $order; // the court's own copy
			}
		} elseif ( 'official-release' === $ks ) {
			$doc['genre']     = 'Press release';
			$article['genre'] = 'Press release';
		} else {
			$doc['@type']     = 'DigitalDocument'; // a circular, advisory or other government document
			$doc['genre']     = $kind ? rankweb_plain_text( $kind->name ) : null;
			$article['genre'] = $doc['genre'];
		}
		$article['isBasedOn'] = array_filter( $doc );
		$nodes[]              = $article;
	} else { // Resources
		$research = has_term( 'research', 'post_tag', $id ); // the Resource type tag
		if ( $src_url ) {
			$doi                  = preg_match( '#^https?://(?:dx\.)?doi\.org/(10\..+)$#i', $src_url, $mm ) ? rawurldecode( $mm[1] ) : '';
			$article['isBasedOn'] = array_filter(
				array(
					'@type'      => $research || $doi ? 'ScholarlyArticle' : 'CreativeWork',
					'name'       => $research && function_exists( 'sourceweb_research_study_title' ) && '' !== sourceweb_research_study_title( $id ) ? sourceweb_research_study_title( $id ) : $title, // the paper's own title (owner, 20 Oct 2026); else the item's
					'headline'   => $research && function_exists( 'sourceweb_research_study_title' ) && '' !== sourceweb_research_study_title( $id ) ? sourceweb_research_study_title( $id ) : $title,
					'url'        => $src_url,
					'sameAs'     => $doi ? 'https://doi.org/' . $doi : null,
					'identifier' => $doi ? array( '@type' => 'PropertyValue', 'propertyID' => 'DOI', 'value' => $doi ) : null,
					'author'     => $research ? ( array_map( fn( $n ) => array( '@type' => 'Person', 'name' => $n ), array_values( (array) get_post_meta( $id, 'aw_authors', true ) ) ) ?: null ) : null, // research-citation.php
					'isPartOf'   => $doi && ( get_post_meta( $id, 'aw_journal', true ) ?: $src_name ) ? array( '@type' => 'Periodical', 'name' => (string) ( get_post_meta( $id, 'aw_journal', true ) ?: $src_name ) ) : null,
					'publisher'  => ! $doi && $src_name ? array( '@type' => 'Organization', 'name' => $src_name ) : null,
					'datePublished' => $src_date,
				)
			);
		}
		$nodes[] = $article;
	}
	return array_map( fn( $n ) => array_filter( $n, fn( $v ) => null !== $v && '' !== $v && array() !== $v ), $nodes );
}

/** The court's own copy of a ruling, when stored: the hosted file's official source or a court website / PDF. */
function rankweb_court_document_url( $id ) {
	foreach ( array( (string) get_post_meta( $id, 'aw_source_url', true ), (string) get_post_meta( $id, 'aw_file_url', true ) ) as $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		if ( $host && ( preg_match( '/(^|\.)(gov\.in|nic\.in)$/', $host ) || false !== strpos( $host, 'supreme-court-judgments' ) || preg_match( '/\.pdf$/i', (string) wp_parse_url( $url, PHP_URL_PATH ) ) ) ) {
			return $url;
		}
	}
	return '';
}

/**
 * A campaign: an Event when its day and its place are stored (aw_event_date, Y-m-d; aw_event_place), organised by
 * its organiser or Animal Writes; otherwise (no day, or no place) a CreativeWork by the organiser. The stored day is the whole event (one day:
 * endDate the same). No offers (only when the campaign states free participation; none does), no performer.
 * A finished campaign (Post) is a CreativeWork like the other campaigns, with its day as temporalCoverage: no Event
 * with an InStock offer for a day that has passed (owner, 10 Nov 2026).
 *
 * @param int $id Post ID.
 * @return array
 */
function rankweb_campaign_schema( $id ) {
	$org     = function_exists( 'aw_campaign_organiser' ) ? aw_campaign_organiser( $id ) : (int) get_post_meta( $id, 'aw_organisation', true );
	$org     = $org ? $org : (int) get_post_meta( $id, 'aw_organiser', true ); // the older key, read when aw_organisation is empty
	$image   = rankweb_schema_safe_url( (string) get_the_post_thumbnail_url( $id, 'large' ) );
	$by      = $org && 'publish' === get_post_status( $org ) ? array( '@type' => 'NGO', 'name' => rankweb_plain_text( get_the_title( $org ) ), 'url' => get_permalink( $org ) ) : array( '@id' => home_url( '/#organization' ) );
	$day     = (string) get_post_meta( $id, 'aw_event_date', true );
	$place   = rankweb_plain_text( (string) get_post_meta( $id, 'aw_event_place', true ) );
	$common  = array(
		'url'         => get_permalink( $id ),
		'name'        => rankweb_plain_text( get_the_title( $id ) ),
		'description' => function_exists( 'aw_text' ) ? rankweb_plain_text( aw_text( $id, 40 ) ) : '',
		'inLanguage'  => rankweb_language(),
		'image'       => $image ? array( $image ) : null,
		'about'       => rankweb_schema_categories( $id ),
	);
	// A campaign about a law (aw_campaign_doc, campaign-tools.php): it is about that Library item's Legislation node.
	$doc = (int) get_post_meta( $id, 'aw_campaign_doc', true );
	if ( $doc && 'publish' === get_post_status( $doc ) ) {
		$common['about'] = array_merge( array( array( '@id' => get_permalink( $doc ) . '#legislation' ) ), (array) $common['about'] );
	}
	$done = function_exists( 'aw_camp_state' ) && 'post' === aw_camp_state( $id );
	if ( ! $done && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $day ) && '' !== $place ) { // an Event needs a place: without one, a CreativeWork
		return array_filter(
			array_merge(
				array( '@type' => 'Event', '@id' => get_permalink( $id ) . '#event', 'startDate' => $day, 'endDate' => $day, 'eventAttendanceMode' => 'https://schema.org/OfflineEventAttendanceMode', 'eventStatus' => 'https://schema.org/EventScheduled' ),
				$common,
				array(
					'location'  => array( '@type' => 'Place', 'name' => $place, 'address' => array( '@type' => 'PostalAddress', 'addressCountry' => 'IN' ) ),
					'organizer' => $by,
					'performer' => $by, // the organiser runs the day (Search Console asks for a performer)
					'offers'    => array( '@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'INR', 'availability' => 'https://schema.org/InStock', 'url' => get_permalink( $id ) ), // free to take part
				)
			)
		);
	}
	return array_filter(
		array_merge(
			array( '@type' => 'CreativeWork', '@id' => get_permalink( $id ) . '#campaign', 'datePublished' => get_the_date( 'c', $id ), 'dateModified' => get_the_modified_date( 'c', $id ) ),
			$common,
			array(
				'creator'          => $by,
				'publisher'        => array( '@id' => home_url( '/#organization' ) ),
				'temporalCoverage' => $done && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $day ) ? $day : null,
			)
		)
	);
}

/**
 * A campaign page's own lists, read from its text so the markup and the page say the same thing: the rule-change cards
 * (aw-camp-card, ItemList) and the pain-scale tiers (aw-camp-tier, DefinedTermSet). Nothing when the page has neither.
 *
 * @param int $id Campaign ID.
 * @return array
 */
function rankweb_campaign_list_nodes( $id ) {
	$html  = (string) get_post_field( 'post_content', $id );
	$url   = get_permalink( $id );
	$plain = fn( $h ) => rankweb_plain_text( trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( preg_replace( '/\[[^\]]*\]/', '', $h ) ) ) ) );
	$nodes = array();
	$items = array();
	if ( preg_match_all( '#<div (?:id="([^"]+)" )?class="wp-block-group aw-camp-card">(.*?)</div>\s*<!-- /wp:group -->#s', $html, $cards, PREG_SET_ORDER ) ) {
		foreach ( $cards as $card ) {
			$c = $card[2];
			if ( ! preg_match( '#<h[34][^>]*>(.*?)</h[34]>#s', $c, $t ) ) {
				continue;
			}
			preg_match( '#<p>(.*?)</p>#s', $c, $d );
			$items[] = array_filter( array( '@type' => 'ListItem', 'position' => count( $items ) + 1, 'name' => $plain( $t[1] ), 'description' => isset( $d[1] ) ? $plain( $d[1] ) : null, 'url' => $url . '#' . ( $card[1] ? $card[1] : 'why-it-matters' ) ) );
		}
	}
	if ( $items ) {
		$head    = preg_match( '#<h2[^>]*>([^<]*)</h2>\s*<!-- /wp:heading -->\s*<!-- wp:group \{"className":"aw-camp-grid"#', $html, $h ) ? $plain( $h[1] ) : 'What the draft does';
		$nodes[] = array( '@type' => 'ItemList', '@id' => $url . '#rule-changes', 'name' => $head, 'numberOfItems' => count( $items ), 'itemListElement' => $items, 'isPartOf' => array( '@id' => $url . '#campaign' ) );
	}
	$terms = array();
	if ( preg_match_all( '#<li class="aw-camp-tier[^"]*">.*?<h[34]>(.*?)</h[34]>(.*?)</li>#s', $html, $tiers, PREG_SET_ORDER ) ) {
		foreach ( $tiers as $t ) {
			$terms[] = array( '@type' => 'DefinedTerm', 'name' => $plain( $t[1] ), 'description' => $plain( str_replace( '</p><p>', '.</p> <p>', $t[2] ) ), 'inDefinedTermSet' => array( '@id' => $url . '#pain-scale' ) );
		}
	}
	if ( $terms ) {
		$head    = preg_match( '#<h[23][^>]*>([^<]*pain scale[^<]*)</h[23]>#i', $html, $h ) ? $plain( $h[1] ) : 'Pain scale';
		$nodes[] = array( '@type' => 'DefinedTermSet', '@id' => $url . '#pain-scale', 'name' => $head, 'url' => $url . '#pain-scale', 'hasDefinedTerm' => $terms );
	}
	return $nodes;
}

/**
 * A campaign in its Post state (campaign-record.php): its page is a retrospective, an Article about the campaign's own
 * node (Event or CreativeWork) and about the Library records the page lists (the campaign's campaign-* tag on
 * aw_legal items), each by the @id of its own node. Nothing before Post.
 *
 * @param int $id Post ID.
 * @return array
 */
function rankweb_campaign_record_schema( $id ) {
	if ( ! function_exists( 'aw_camp_state' ) || 'post' !== aw_camp_state( $id ) ) {
		return array();
	}
	$url   = get_permalink( $id );
	$own   = rankweb_campaign_schema( $id );
	$about = array( array( '@id' => (string) ( $own['@id'] ?? $url . '#campaign' ) ) );
	$tags  = function_exists( 'aw_campaign_links' ) ? wp_list_pluck( aw_campaign_links( $id ), 'term_id' ) : array(); // the campaign's own link (campaign-links.php)
	if ( $tags && function_exists( 'rankweb_article_nodes' ) ) {
		$docs = get_posts( array( 'post_type' => 'aw_legal', 'post_status' => 'publish', 'numberposts' => 20, 'tax_query' => array( array( 'taxonomy' => ( defined( 'KITS_CAMPAIGN_LINK' ) ? KITS_CAMPAIGN_LINK : '' ), 'terms' => array( (int) $tags[0] ) ) ), 'orderby' => 'date', 'order' => 'DESC', 'fields' => 'ids' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $docs as $d ) {
			$n = rankweb_article_nodes( $d );
			if ( ! empty( $n[0]['@id'] ) ) {
				$about[] = array( '@id' => $n[0]['@id'] );
			}
		}
	}
	$image = rankweb_schema_safe_url( (string) get_the_post_thumbnail_url( $id, 'large' ) );
	return array_filter(
		array(
			'@type'            => 'Article',
			'@id'              => $url . '#article',
			'headline'         => rankweb_plain_text( get_the_title( $id ) ),
			'url'              => $url,
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
			'description'      => function_exists( 'aw_text' ) ? rankweb_plain_text( aw_text( $id, 40 ) ) : '',
			'inLanguage'       => rankweb_language(),
			'image'            => $image ? array( $image ) : null,
			'datePublished'    => get_the_date( 'c', $id ),
			'dateModified'     => get_the_modified_date( 'c', $id ),
			'author'           => array( '@id' => home_url( '/#organization' ) ),
			'publisher'        => array( '@id' => home_url( '/#organization' ) ),
			'about'            => $about,
		)
	);
}

/**
 * Every inLanguage in the graph as en-IN: Rank Math writes the WordPress locale (en-US) on its WebPage nodes, while the
 * site, its pages and its items are Indian English. Plain-text values lose their HTML entities (&#039;, &#8217; from
 * WordPress titles), so the graph carries the characters themselves.
 *
 * @param mixed $node Graph or node.
 * @return mixed
 */
function rankweb_schema_language( $node ) {
	if ( ! is_array( $node ) ) {
		return $node;
	}
	foreach ( $node as $k => $v ) {
		if ( 'inLanguage' === $k && is_string( $v ) && 0 === stripos( $v, 'en' ) && 0 === stripos( rankweb_language(), 'en' ) ) {
			$node[ $k ] = rankweb_language();
		} elseif ( is_string( $v ) && false === strpos( $v, '<' ) && false !== strpos( $v, '&' ) ) {
			$node[ $k ] = html_entity_decode( $v, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		} elseif ( is_array( $v ) ) {
			$node[ $k ] = rankweb_schema_language( $v );
		}
	}
	return $node;
}

/** Other names of the site and organisation (owner, 20 Oct 2026); Google reads the WebSite's for the site name in results. */
// AW_SITE_ALT_NAMES: RankWeb → Settings (settings.php).

/** The site itself (shown on every page). */
function rankweb_website_schema() {
	return array(
		'@type'         => 'WebSite',
		'@id'           => home_url( '/#website' ),
		'name'          => get_bloginfo( 'name' ),
		'alternateName' => AW_SITE_ALT_NAMES,
		'url'           => home_url( '/' ),
		'inLanguage'    => rankweb_language(),
		'publisher'     => array( '@id' => home_url( '/#organization' ) ),
	);
}

/**
 * JobPosting for an open job, internship, fellowship or volunteer role: remote ones as TELECOMMUTE (with India as the
 * applicant country), others at each of their places (else India). Only from what the item holds, nothing guessed:
 * - validThrough only from a stored deadline (aw_deadline; a review date is not a deadline). Past it, or past its
 *   review date, the opportunity is closed and has no JobPosting at all.
 * - employmentType from the type the source states (aw_employment_type, e.g. FULL_TIME for "Type: Fulltime") and the
 *   Opportunity type: internship INTERN, volunteer VOLUNTEER, fellowship OTHER. A job that states no hours has none.
 * - jobLocation: one Place per stored district or state. Street and PIN code only when the role is at the hiring
 *   organisation's own place: the opportunity has one place, the same district as the organisation's Directory listing,
 *   and the listing holds them (its area beyond the district and state, its PIN code). The opportunity's own PIN code
 *   comes first. Never the organisation's office for a role elsewhere.
 * - baseSalary: never; no opportunity stores pay, and none is guessed.
 */
function rankweb_job_schema( $id ) {
	$places = function_exists( 'directoryweb_item_places' ) ? directoryweb_item_places( $id ) : array();
	$area   = trim( (string) get_post_meta( $id, 'aw_area', true ) . ' ' . (string) get_post_meta( $id, 'aw_place_city', true ) );
	$names  = implode( ' ', array_map( fn( $p ) => $p->name, $places ) );
	$org_id = (int) get_post_meta( $id, 'aw_organisation', true );
	$org_id = $org_id && 'publish' === get_post_status( $org_id ) ? $org_id : 0;
	$remote = (bool) preg_match( '/\b(remote|online|anywhere|work from home|wfh|virtual)\b/i', $area . ' ' . $names );
	$org      = (string) get_post_meta( $id, 'aw_org_name', true );
	$org      = $org ? $org : ( $org_id ? get_post_field( 'post_title', $org_id ) : '' );
	$org_site = (string) get_post_meta( $id, 'aw_website', true );
	if ( ! $org_site && $org_id ) {
		$org_site = (string) get_post_meta( $org_id, 'aw_website', true );
	}
	$deadline = (string) get_post_meta( $id, 'aw_deadline', true );
	if ( ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deadline ) && $deadline < wp_date( 'Y-m-d' ) ) || ( function_exists( 'kits_retention_state' ) && kits_retention_state( $id ) ) ) {
		return array(); // closed (past its deadline or review date): no JobPosting
	}
	$kinds = wp_get_object_terms( $id, 'post_tag', array( 'fields' => 'slugs' ) );
	$kinds = is_wp_error( $kinds ) ? array() : $kinds;
	if ( $kinds && ! array_intersect( array( 'job', 'internship', 'fellowship', 'volunteer' ), $kinds ) ) {
		return array(); // an event, fostering or a grant is not a job
	}
	if ( '' === $org ) {
		return array(); // Google requires hiringOrganization: without the organisation's name there is no JobPosting
	}
	$desc = trim( preg_replace( '/<!--.*?-->/s', '', (string) get_post_field( 'post_content', $id ) ) ); // no block comments
	$desc = $desc ? $desc : ( function_exists( 'aw_text' ) ? aw_text( $id, 60 ) : '' );
	$desc = $desc ? $desc : (string) get_post_field( 'post_excerpt', $id );
	$desc = $desc ? $desc : get_the_title( $id );
	$emp  = array_filter( array( (string) get_post_meta( $id, 'aw_employment_type', true ) ) ); // as the source states it
	foreach ( array( 'internship' => 'INTERN', 'volunteer' => 'VOLUNTEER', 'fellowship' => 'OTHER' ) as $tag => $value ) { // Google has no fellowship value
		if ( in_array( $tag, $kinds, true ) ) {
			$emp[] = $value;
		}
	}
	$emp  = array_values( array_unique( $emp ) );
	$logo = $org_id ? (string) get_the_post_thumbnail_url( $org_id, 'medium' ) : ''; // the organisation's own logo, when its listing has one
	$data = array(
		'@type'              => 'JobPosting',
		'@id'                => get_permalink( $id ) . '#job',
		'title'              => rankweb_plain_text( get_the_title( $id ) ),
		'description'        => trim( preg_replace( '/\n{3,}/', "\n\n", wp_kses_post( $desc ) ) ),
		'datePosted'         => get_the_date( 'c', $id ),
		'url'                => get_permalink( $id ),
		'employmentType'     => $emp ? ( 1 === count( $emp ) ? $emp[0] : $emp ) : null,
		'hiringOrganization' => array_filter( array( '@type' => 'Organization', 'name' => rankweb_plain_text( $org ), 'sameAs' => $org_site, 'url' => $org_id ? get_permalink( $org_id ) : null, 'logo' => $logo ) ),
		'validThrough'       => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deadline ) ? $deadline . 'T23:59:59+05:30' : null,
	);
	if ( $remote ) {
		$data['jobLocationType']               = 'TELECOMMUTE';
		$data['applicantLocationRequirements'] = array( '@type' => 'Country', 'name' => (string) apply_filters( 'rankweb_remote_job_country', '' ) );
		return array_filter( $data );
	}
	$street = '';
	$pin    = (string) get_post_meta( $id, 'aw_pincode', true );
	if ( 1 === count( $places ) && 'district' === $places[0]->kind && $org_id && function_exists( 'directoryweb_item_codes' ) && in_array( (int) $places[0]->code, directoryweb_item_codes( $org_id )[1], true ) ) {
		$state  = directoryweb_place_state( $places[0]->state );
		$street = trim( preg_replace( '/(\s*,\s*)+/', ', ', str_ireplace( array_filter( array( $places[0]->name, $state ? $state->name : '', (string) apply_filters( 'rankweb_country_name', '' ) ) ), '', (string) get_post_meta( $org_id, 'aw_area', true ) ) ), " ,\t\n" );
		$pin    = $pin ? $pin : (string) get_post_meta( $org_id, 'aw_pincode', true ); // the role is at the organisation's own place
	}
	$locs = array();
	foreach ( $places ? $places : array( null ) as $p ) {
		$state  = $p ? ( 'district' === $p->kind ? directoryweb_place_state( $p->state ) : $p ) : null;
		$locs[] = array(
			'@type'   => 'Place',
			'address' => array_filter(
				array(
					'@type'           => 'PostalAddress',
					'streetAddress'   => $street,
					'addressLocality' => $p && 'district' === $p->kind ? $p->name : ( $p ? null : trim( (string) get_post_meta( $id, 'aw_place_city', true ) ) ),
					'addressRegion'   => $state ? $state->name : null,
					'postalCode'      => 1 === count( $places ) ? $pin : '',
					'addressCountry'  => 'IN', // without a stored place, only the country
				)
			),
		);
	}
	$data['jobLocation'] = 1 === count( $locs ) ? $locs[0] : $locs;
	return array_filter( $data );
}

/**
 * The kind of an Opportunity, from its Opportunity type tags (an event first, then a role, then the rest):
 * event | role | fellowship | grant | course | call | '' (anything else, e.g. fostering alone: the page itself).
 * scholarship, course/training/workshop and award/competition/call-for-submissions have no tags yet (see the report
 * of 17 Oct 2026); their slugs are read here so the right type follows once the owner adds them.
 */
function rankweb_opportunity_kind( $id ) {
	$kinds = wp_get_object_terms( $id, 'post_tag', array( 'fields' => 'slugs' ) );
	$kinds = is_wp_error( $kinds ) ? array() : $kinds;
	$has   = fn( $list ) => (bool) array_intersect( $list, $kinds );
	if ( $has( array( 'event' ) ) ) {
		return 'event';
	}
	if ( $has( array( 'job', 'internship', 'volunteer' ) ) ) {
		return 'role';
	}
	if ( $has( array( 'fellowship' ) ) ) {
		return 'fellowship';
	}
	if ( $has( array( 'grant', 'scholarship' ) ) ) {
		return 'grant';
	}
	if ( $has( array( 'course', 'training', 'workshop' ) ) ) {
		return 'course';
	}
	if ( $has( array( 'award', 'competition', 'call-for-submissions' ) ) ) {
		return 'call';
	}
	return '';
}

/**
 * The next day an event repeats on, from aw_event_schedule as the source states it ("second Saturday monthly
 * 14:00-16:00", "last Sunday monthly 10:00-16:00"): [Y-m-d, start H:i, end H:i, week of month (1-4, -1 last), day].
 * Null when the text is not in that form.
 */
function rankweb_opportunity_repeat( $id ) {
	$text  = strtolower( (string) get_post_meta( $id, 'aw_event_schedule', true ) );
	$weeks = array( 'first' => 1, 'second' => 2, 'third' => 3, 'fourth' => 4, 'last' => -1 );
	if ( ! preg_match( '/\b(first|second|third|fourth|last)\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b.*?\bmonthly\b.*?(\d{1,2}:\d{2})\s*[-–]\s*(\d{1,2}:\d{2})/', $text, $m ) ) {
		return null;
	}
	$tz    = wp_timezone();
	$today = new DateTimeImmutable( 'today', $tz );
	for ( $i = 0; $i < 3; $i++ ) {
		$month = $today->modify( 'first day of this month' )->modify( "+$i month" );
		$day   = $month->modify( $m[1] . ' ' . $m[2] . ' of this month' );
		if ( $day >= $today ) {
			return array( $day->format( 'Y-m-d' ), $m[3], $m[4], $weeks[ $m[1] ], ucfirst( $m[2] ) );
		}
	}
	return null;
}

/**
 * The address of an item at the organisation's own place: district and state of its one place, with the street and PIN
 * code of the organisation's Directory listing when the listing is in that district (never an office elsewhere).
 */
function rankweb_opportunity_org_address( $id, $org_id ) {
	$places = function_exists( 'directoryweb_item_places' ) ? directoryweb_item_places( $id ) : array();
	$p      = 1 === count( $places ) ? $places[0] : null;
	$state  = $p ? ( 'district' === $p->kind ? directoryweb_place_state( $p->state ) : $p ) : null;
	$street = '';
	$pin    = (string) get_post_meta( $id, 'aw_pincode', true );
	if ( $p && 'district' === $p->kind && $org_id && in_array( (int) $p->code, directoryweb_item_codes( $org_id )[1], true ) ) {
		$street = trim( preg_replace( '/(\s*,\s*)+/', ', ', str_ireplace( array_filter( array( $p->name, $state ? $state->name : '', (string) apply_filters( 'rankweb_country_name', '' ) ) ), '', (string) get_post_meta( $org_id, 'aw_area', true ) ) ), " ,\t\n" );
		$pin    = $pin ? $pin : (string) get_post_meta( $org_id, 'aw_pincode', true );
	}
	return array_filter( array( '@type' => 'PostalAddress', 'streetAddress' => $street, 'addressLocality' => $p && 'district' === $p->kind ? $p->name : null, 'addressRegion' => $state ? $state->name : null, 'postalCode' => $pin, 'addressCountry' => 'IN' ) );
}

/**
 * The schema.org node of an Opportunity, by what it is (owner, 17 Oct 2026: the correct type per item):
 * - a role (job, internship, volunteer role): JobPosting (rankweb_job_schema);
 * - an event with a stated day, or a stated monthly repeat: Event at the organisation's place, organised by it
 *   (a repeat also as an eventSchedule; startDate is its next day). Without a day: no node; with a day but no place
 *   stored (no district or state): CreativeWork;
 * - a fellowship: EducationalOccupationalProgram offered by the organisation (applicationDeadline from aw_deadline);
 * - a grant or scholarship: MonetaryGrant funded by the organisation (no amount: none is stored);
 * - a course, training or workshop: Course by the organisation (with a CourseInstance when it has a day);
 * - an award, competition or call: Event when it has a day and a place, else CreativeWork;
 * - anything else (fostering alone): no node; the page is Rank Math's WebPage.
 * A closed opportunity (past its deadline or review date) has none.
 */
function rankweb_opportunity_schema( $id ) {
	if ( function_exists( 'kits_retention_state' ) && kits_retention_state( $id ) ) {
		return array();
	}
	$kind = rankweb_opportunity_kind( $id );
	if ( 'role' === $kind ) {
		return rankweb_job_schema( $id );
	}
	if ( '' === $kind ) {
		return array();
	}
	$org_id = (int) get_post_meta( $id, 'aw_organisation', true );
	$org_id = $org_id && 'publish' === get_post_status( $org_id ) ? $org_id : 0;
	$name   = (string) get_post_meta( $id, 'aw_org_name', true );
	$name   = $name ? $name : ( $org_id ? get_post_field( 'post_title', $org_id ) : '' );
	$org    = $name ? array_filter( array( '@type' => 'Organization', 'name' => rankweb_plain_text( $name ), 'url' => $org_id ? get_permalink( $org_id ) : (string) get_post_meta( $id, 'aw_website', true ) ) ) : null;
	$desc   = function_exists( 'aw_text' ) ? rankweb_plain_text( aw_text( $id, 60 ) ) : '';
	$common = array(
		'@id'         => get_permalink( $id ) . '#' . $kind,
		'name'        => rankweb_plain_text( get_the_title( $id ) ),
		'description' => '' !== $desc ? $desc : rankweb_plain_text( (string) get_post_field( 'post_excerpt', $id ) ),
		'url'         => get_permalink( $id ),
		'inLanguage'  => rankweb_language(),
	);
	$day      = (string) get_post_meta( $id, 'aw_event_date', true );
	$day      = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $day ) ? $day : '';
	$repeat   = $day ? null : rankweb_opportunity_repeat( $id );
	$deadline = (string) get_post_meta( $id, 'aw_deadline', true );
	$deadline = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deadline ) ? $deadline : '';
	$creative = fn() => array_filter( array_merge( array( '@type' => 'CreativeWork' ), $common, array( 'creator' => $org, 'datePublished' => get_the_date( 'c', $id ) ) ) );
	$event    = function () use ( $id, $common, $org, $org_id, $day, $repeat, $creative ) {
		if ( ! $day && ! $repeat ) {
			return array();
		}
		$addr = rankweb_opportunity_org_address( $id, $org_id );
		if ( ! array_diff_key( $addr, array( '@type' => 1, 'addressCountry' => 1 ) ) ) {
			return $creative(); // no place stated (country only): an Event needs one, so a CreativeWork
		}
		$t     = wp_timezone();
		$start = $repeat ? new DateTimeImmutable( $repeat[0] . ' ' . $repeat[1], $t ) : null;
		$end   = $repeat ? new DateTimeImmutable( $repeat[0] . ' ' . $repeat[2], $t ) : null;
		$image = rankweb_schema_image( $id );
		return array_filter(
			array_merge(
				array( '@type' => 'Event' ),
				$common,
				array(
					'@id'                 => get_permalink( $id ) . '#event',
					'startDate'           => $start ? $start->format( 'c' ) : $day,
					'endDate'             => $end ? $end->format( 'c' ) : $day, // a stated day is one day
					'eventSchedule'       => $repeat ? array( '@type' => 'Schedule', 'repeatFrequency' => 'P1M', 'byDay' => 'https://schema.org/' . $repeat[4], 'byMonthWeek' => $repeat[3], 'startTime' => $repeat[1] . ':00', 'endTime' => $repeat[2] . ':00', 'scheduleTimezone' => 'Asia/Kolkata' ) : null,
					'eventAttendanceMode' => 'https://schema.org/OfflineEventAttendanceMode',
					'eventStatus'         => 'https://schema.org/EventScheduled',
					'location'            => array_filter( array( '@type' => 'Place', 'name' => $org ? $org['name'] : null, 'address' => $addr ) ),
					'organizer'           => $org,
					'image'               => $image ? array( $image ) : null,
				)
			)
		);
	};
	if ( 'event' === $kind ) {
		return $event();
	}
	if ( 'fellowship' === $kind ) {
		return array_filter( array_merge( array( '@type' => 'EducationalOccupationalProgram' ), $common, array( 'provider' => $org, 'applicationDeadline' => $deadline ) ) );
	}
	if ( 'grant' === $kind ) {
		return array_filter( array_merge( array( '@type' => 'MonetaryGrant' ), $common, array( 'funder' => $org ) ) );
	}
	if ( 'course' === $kind ) {
		$instance = $day ? array( '@type' => 'CourseInstance', 'courseMode' => 'onsite', 'startDate' => $day, 'endDate' => $day, 'location' => array( '@type' => 'Place', 'address' => rankweb_opportunity_org_address( $id, $org_id ) ) ) : null;
		return array_filter( array_merge( array( '@type' => 'Course' ), $common, array( 'provider' => $org, 'hasCourseInstance' => $instance ) ) );
	}
	$ev = $event(); // an award, competition or call
	return $ev ? $ev : $creative();
}

/** The Categories page: CollectionPage + ItemList of every category. */
function rankweb_categories_schema() {
	$url   = get_permalink();
	$items = array();
	foreach ( get_terms( array( 'taxonomy' => rankweb_seo_category_tax(), 'hide_empty' => true, 'orderby' => 'name' ) ) as $i => $t ) {
		$items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'url' => rankweb_seo_term_url( $t ), 'name' => rankweb_plain_text( $t->name ) );
	}
	return array(
		array(
			'@type'       => 'CollectionPage',
			'@id'         => $url . '#page',
			'url'         => $url,
			'name'        => rankweb_plain_text( get_the_title() ),
			'description' => rankweb_seo_description(),
			'inLanguage'  => rankweb_language(),
			'isPartOf'    => array( '@id' => home_url( '/#website' ) ),
			'publisher'   => array( '@id' => home_url( '/#organization' ) ),
			'mainEntity'  => array( '@id' => $url . '#list' ),
		),
		array( '@type' => 'ItemList', '@id' => $url . '#list', 'numberOfItems' => count( $items ), 'itemListElement' => $items ),
	);
}

/**
 * Build a schema.org node from a kits_schema_map preset entry.
 *
 * @param int   $post_id Post ID.
 * @param array $conf    Preset schema configuration.
 * @return array Schema node, or empty array if required properties are missing.
 */
function rankweb_preset_schema_node( $post_id, array $conf ): array {
	$val_cb   = ! empty( $conf['value_callback'] ) && is_callable( $conf['value_callback'] ) ? $conf['value_callback'] : null;
	$fields   = ! empty( $conf['fields'] ) && is_array( $conf['fields'] ) ? $conf['fields'] : array();
	$requires = ! empty( $conf['requires'] ) && is_array( $conf['requires'] ) ? $conf['requires'] : array();

	$node = array(
		'@type'      => $conf['type'],
		'@id'        => get_permalink( $post_id ) . '#' . strtolower( sanitize_key( $conf['type'] ) ),
		'url'        => get_permalink( $post_id ),
		'name'       => rankweb_plain_text( get_the_title( $post_id ) ),
		'inLanguage' => rankweb_language(),
		'isPartOf'   => array( '@id' => home_url( '/#website' ) ),
	);

	foreach ( $fields as $prop => $key ) {
		$val = $val_cb ? call_user_func( $val_cb, $key, $post_id ) : ( function_exists( 'kits_post_field_value' ) ? kits_post_field_value( $key, $post_id ) : get_post_meta( $post_id, $key, true ) );
		if ( '' !== $val && null !== $val ) {
			$node[ $prop ] = $val;
		}
	}

	foreach ( $requires as $req ) {
		if ( empty( $node[ $req ] ) ) {
			return array();
		}
	}

	return $node;
}

/**
 * The schema.org nodes of the current page's own content (not the publisher, the site or the breadcrumb trail):
 * the article, legislation, job, campaign, listing organisation, contact page, hub list or category collection.
 *
 * @return array List of nodes.
 */
function rankweb_schema_nodes() {
	$nodes = array();
	if ( is_404() ) {
		return $nodes;
	}
	if ( is_singular( array( 'aw_news', 'aw_legal', 'post' ) ) ) {
		$nodes = function_exists( 'rankweb_apply_schema_type' ) ? rankweb_apply_schema_type( rankweb_article_nodes( get_queried_object_id() ), get_queried_object_id() ) : rankweb_article_nodes( get_queried_object_id() );
	} elseif ( is_singular( 'aw_listing' ) ) {
		$nodes[] = rankweb_listing_schema( get_queried_object_id() );
	} elseif ( is_singular( 'aw_opportunity' ) ) {
		$nodes[] = rankweb_opportunity_schema( get_queried_object_id() ); // JobPosting, Event, programme, grant or course
	} elseif ( is_singular( 'aw_campaign' ) ) {
		$nodes[] = rankweb_campaign_schema( get_queried_object_id() );
		$nodes   = array_merge( $nodes, rankweb_campaign_list_nodes( get_queried_object_id() ) );
		$story   = rankweb_campaign_record_schema( get_queried_object_id() );
		if ( $story ) {
			$nodes[] = $story; // a closed campaign's page is also the record of what happened
		}
	} elseif ( is_singular() ) {
		$post_type  = get_post_type();
		$schema_map = apply_filters( 'kits_schema_map', array() );
		if ( ! empty( $schema_map[ $post_type ]['type'] ) ) {
			$preset_node = rankweb_preset_schema_node( get_queried_object_id(), $schema_map[ $post_type ] );
			if ( $preset_node ) {
				$nodes[] = $preset_node;
			}
		} elseif ( function_exists( 'rankweb_generic_schema_nodes' ) && in_array( $post_type, (array) apply_filters( 'rankweb_generic_schema_post_types', array( 'post', 'page' ) ), true ) ) {
			$nodes = rankweb_generic_schema_nodes( get_queried_object_id() ); // an ordinary post or page: not tied to any `aw_*` type
		}
	} elseif ( is_page( 'contact' ) ) {
		$nodes[] = array(
			'@type'      => 'ContactPage',
			'@id'        => get_permalink() . '#page',
			'url'        => get_permalink(),
			'name'       => rankweb_plain_text( get_the_title() ),
			'inLanguage' => rankweb_language(),
			'isPartOf'   => array( '@id' => home_url( '/#website' ) ),
			'mainEntity' => array( '@id' => home_url( '/#organization' ) ), // the publisher node carries the email and contact point
		);
	} elseif ( is_page( 'claim' ) ) {
		$listing = function_exists( 'directoryweb_form_page_listing' ) ? directoryweb_form_page_listing() : null;
		if ( $listing ) {
			$nodes[] = array(
				'@type'      => 'ItemPage',
				'@id'        => get_permalink() . '?listing=' . $listing->ID . '#webpage',
				'url'        => add_query_arg( 'listing', $listing->ID, get_permalink() ),
				'name'       => 'Claim Listing: ' . rankweb_plain_text( get_the_title( $listing ) ),
				'inLanguage' => rankweb_language(),
				'isPartOf'   => array( '@id' => home_url( '/#website' ) ),
				'mainEntity' => function_exists( 'rankweb_listing_schema' ) ? rankweb_listing_schema( $listing->ID ) : array( '@type' => 'NGO', 'name' => rankweb_plain_text( get_the_title( $listing ) ) ),
			);
		} else {
			$nodes[] = array(
				'@type'           => 'SearchResultsPage',
				'@id'             => get_permalink() . '#webpage',
				'url'             => get_permalink(),
				'name'            => 'Claim Your Organisation Listing',
				'description'     => 'Search and claim your organisation listing.',
				'inLanguage'      => rankweb_language(),
				'isPartOf'        => array( '@id' => home_url( '/#website' ) ),
				'potentialAction' => array(
					'@type'       => 'SearchAction',
					'target'      => home_url( '/claim/?org={search_term_string}' ),
					'query-input' => 'required name=search_term_string',
				),
			);
		}
	} elseif ( is_page( 'about' ) ) {
		$nodes[] = array( '@type' => 'AboutPage', '@id' => get_permalink() . '#webpage', 'url' => get_permalink(), 'name' => rankweb_plain_text( get_the_title() ), 'inLanguage' => rankweb_language(), 'isPartOf' => array( '@id' => home_url( '/#website' ) ), 'mainEntity' => array( '@id' => home_url( '/#organization' ) ) );
	} elseif ( is_page( 'categories' ) ) {
		$nodes = array_merge( $nodes, rankweb_categories_schema() );
	} elseif ( is_page( array( 'press-coverage', 'media' ) ) && function_exists( 'rankweb_press_schema' ) && function_exists( 'aw_press_list' ) ) { // the press list (Animal Writes Core)
		$nodes[] = rankweb_press_schema();
	} elseif ( function_exists( 'rankweb_hub_schema_nodes' ) && rankweb_hub_schema_nodes() ) {
		$nodes = array_merge( $nodes, rankweb_hub_schema_nodes() ); // hubs and directory places: CollectionPage + ItemList (hubs.php)
	} elseif ( is_page() && 'page-hub' === get_page_template_slug( get_queried_object_id() ) ) {
		$nodes = array_merge( $nodes, rankweb_page_lists_schema_nodes( get_queried_object_id() ) ); // a section page of several lists (Adoption)
	} elseif ( rankweb_seo_is_category_page() || is_tag() ) { // a category or tag page: the same CollectionPage + ItemList
		$nodes = array_merge( $nodes, rankweb_category_schema_nodes() );
	}
	if ( $nodes && is_singular( array( 'aw_news', 'aw_legal', 'post', 'aw_campaign' ) ) && function_exists( 'directoryweb_featured_mentions_schema' ) ) {
		$mentions = directoryweb_featured_mentions_schema( get_queried_object_id() ); // the organisations it features (featured.php)
		if ( $mentions ) {
			$nodes[0]['mentions'] = array_merge( (array) ( $nodes[0]['mentions'] ?? array() ), $mentions );
		}
	}
	return array_values( array_filter( $nodes ) );
}

/**
 * A category page: CollectionPage + ItemList of the items on the current page (indexed items only).
 *
 * @return array
 */
function rankweb_category_schema_nodes() {
	global $wp_query;
	$term  = get_queried_object();
	$url   = rankweb_seo_term_url( $term );
	$per   = max( 1, (int) get_query_var( 'posts_per_page' ) );
	$start = ( max( 1, (int) get_query_var( 'paged' ) ) - 1 ) * $per;
	$items = array();
	foreach ( (array) $wp_query->posts as $i => $p ) {
		if ( ! $p instanceof WP_Post || rankweb_is_noindex_item( $p->ID ) || in_array( (int) $p->ID, rankweb_seo_preview_ids(), true ) ) {
			continue;
		}
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $start + $i + 1,
			'url'      => get_permalink( $p ),
			'name'     => rankweb_plain_text( get_the_title( $p ) ), // a plain summary list (as the hubs): a typed stub with only a name and url reads as an incomplete Article
		);
	}
	$desc  = rankweb_plain_text( rankweb_seo_description() );
	$nodes = array(
		array_filter(
			array(
				'@type'       => 'CollectionPage',
				'@id'         => $url . '#page',
				'url'         => $url,
				'name'        => rankweb_plain_text( $term->name ),
				'description' => '' !== $desc ? $desc : wp_strip_all_tags( term_description( $term ) ),
				'inLanguage'  => rankweb_language(),
				'isPartOf'    => array( '@id' => home_url( '/#website' ) ),
				'publisher'   => array( '@id' => home_url( '/#organization' ) ),
				'mainEntity'  => $items ? array( '@id' => $url . '#list' ) : null,
			)
		),
	);
	if ( $items ) {
		$nodes[] = array( '@type' => 'ItemList', '@id' => $url . '#list', 'numberOfItems' => (int) $wp_query->found_posts, 'itemListElement' => $items );
	}
	return $nodes;
}

/**
 * A section page whose lists are Query Loops in its own content (not one hub's list, e.g. Adoption: Directory listings,
 * Opportunities, Resources and News of one category): CollectionPage + ItemList of the items those loops show, in page
 * order. Synced patterns in the content are followed; noindex and preview-only items are left out.
 *
 * @param int $page_id Page ID.
 * @return array
 */
function rankweb_page_lists_schema_nodes( $page_id ) {
	$url    = get_permalink( $page_id );
	$loops  = array();
	$walk   = function ( $blocks, $depth = 0 ) use ( &$walk, &$loops ) {
		foreach ( $blocks as $b ) {
			if ( 'core/query' === $b['blockName'] ) {
				$loops[] = (array) ( $b['attrs']['query'] ?? array() );
			} elseif ( 'core/block' === $b['blockName'] && ! empty( $b['attrs']['ref'] ) && $depth < 3 ) {
				$walk( parse_blocks( (string) get_post_field( 'post_content', (int) $b['attrs']['ref'] ) ), $depth + 1 );
			}
			if ( ! empty( $b['innerBlocks'] ) ) {
				$walk( $b['innerBlocks'], $depth );
			}
		}
	};
	$walk( parse_blocks( (string) get_post_field( 'post_content', $page_id ) ) );
	$items = array();
	$seen  = array();
	$skip  = rankweb_seo_preview_ids();
	foreach ( $loops as $query ) {
		$loop = (object) array( 'context' => array( 'query' => $query ) );
		$vars = apply_filters( 'query_loop_block_query_vars', build_query_vars_from_query_block( $loop, 1 ), $loop, 1 ); // the same rules the list follows (open Opportunities only)
		foreach ( get_posts( $vars + array( 'post_status' => 'publish', 'suppress_filters' => false ) ) as $p ) {
			if ( isset( $seen[ $p->ID ] ) || rankweb_is_noindex_item( $p->ID ) || in_array( (int) $p->ID, $skip, true ) ) {
				continue;
			}
			$seen[ $p->ID ] = true;
			$items[]        = array(
				'@type'    => 'ListItem',
				'position' => count( $items ) + 1,
				'url'      => get_permalink( $p ),
				'name'     => rankweb_plain_text( get_the_title( $p ) ), // plain summary list, as the hubs
			);
		}
	}
	$nodes = array(
		array_filter(
			array(
				'@type'       => 'CollectionPage',
				'@id'         => $url . '#page',
				'url'         => $url,
				'name'        => rankweb_plain_text( get_the_title( $page_id ) ),
				'description' => rankweb_seo_description(),
				'inLanguage'  => rankweb_language(),
				'isPartOf'    => array( '@id' => home_url( '/#website' ) ),
				'publisher'   => array( '@id' => home_url( '/#organization' ) ),
				'mainEntity'  => $items ? array( '@id' => $url . '#list' ) : null,
			)
		),
	);
	if ( $items ) {
		$nodes[] = array( '@type' => 'ItemList', '@id' => $url . '#list', 'numberOfItems' => count( $items ), 'itemListElement' => $items );
	}
	return $nodes;
}

/**
 * CollectionPage + ItemList of a hub's current page (put in the page's one graph below). Empty off a hub.
 *
 * @return array
 */
function rankweb_hub_schema_nodes() {
	static $nodes = null;
	if ( null !== $nodes ) {
		return $nodes;
	}
	if ( ! function_exists( 'aw_hub_type' ) || ! function_exists( 'aw_hub_posts' ) || ! defined( 'AW_HUBS' ) ) { // the hubs (Animal Writes Core) are not loaded
		return $nodes = array();
	}
	$type = aw_hub_type();
	if ( ! $type || is_404() || 'aw_press' === $type ) {
		return $nodes = array(); // Media & PR has its own (rankweb_press_schema)
	}
	$url   = strtok( aw_hub_base_url(), '?' );
	$view  = function_exists( 'rankweb_seo_filtered_named' ) && rankweb_seo_filtered_named() ? rankweb_seo_filtered_view() : null;
	if ( $view ) { // a hub filtered by one category or tag is its own collection (filtered-views.php)
		$url = add_query_arg( $view['key'], rawurlencode( $view['slug'] ), strtok( aw_hub_base_url(), '?' ) );
	}
	// Kept until the next post change (rankweb_seo_cached): the plain list and its named filtered views, per page. Any
	// other filtered request is built each time, so query strings cannot fill the cache.
	$plain = ! function_exists( 'rankweb_seo_filter_params' ) || ! rankweb_seo_filter_params();
	if ( $plain || $view ) {
		$path  = (string) wp_parse_url( add_query_arg( array() ), PHP_URL_PATH ); // the request's own path (Directory places and types)
		$sort  = sanitize_key( wp_unslash( $_GET['sort'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification -- an order, read only
		$nodes = rankweb_seo_cached( 'hub_schema|' . $type . '|' . $url . '|' . $path . '|' . $sort . '|' . aw_hub_page() . '|' . get_queried_object_id(), fn() => rankweb_hub_schema_build( $type, $url, $view ) );
		return $nodes;
	}
	$nodes = rankweb_hub_schema_build( $type, $url, $view );
	return $nodes;
}

/**
 * The CollectionPage + ItemList of a hub list (rankweb_hub_schema_nodes()).
 *
 * @param string     $type Post type of the hub.
 * @param string     $url  The list's own address.
 * @param array|null $view Its named filtered view, if any.
 * @return array
 */
function rankweb_hub_schema_build( $type, $url, $view ) {
	$items = array();
	$start = ( aw_hub_page() - 1 ) * AW_HUBS[ $type ][2];
	$posts = aw_hub_posts( $type );
	$extra = 0;
	if ( 'aw_campaign' === $type && 1 === aw_hub_page() ) {
		$lead = get_page_by_path( 'india-writes-for-its-community-dogs', OBJECT, 'aw_campaign' ); // shown above the list as its own story (hubs.php)
		if ( $lead && 'publish' === $lead->post_status ) {
			array_unshift( $posts, $lead );
			$extra = 1;
		}
	}
	foreach ( $posts as $i => $p ) {
		if ( rankweb_is_noindex_item( $p->ID ) || in_array( (int) $p->ID, rankweb_seo_preview_ids(), true ) ) {
			continue; // not indexed (or preview only), so not listed
		}
		$item_data = array(
			'@type'    => 'ListItem',
			'position' => $start + $i + 1,
			'url'      => get_permalink( $p ),
			'name'     => rankweb_plain_text( get_the_title( $p ) ),
		);
		if ( 'aw_listing' === $type ) {
			$place = function_exists( 'directoryweb_listing_place' ) ? array_filter( array_reverse( (array) directoryweb_listing_place( $p->ID ) ) ) : array();
			$phone = function_exists( 'directoryweb_listing_first_phone' ) ? directoryweb_listing_first_phone( $p->ID ) : '';
			$ngo   = array(
				'@type' => 'NGO',
				'@id'   => get_permalink( $p ) . '#organization',
				'name'  => rankweb_plain_text( get_the_title( $p ) ),
				'url'   => get_permalink( $p ),
			);
			if ( $place ) {
				$ngo['address'] = array(
					'@type'           => 'PostalAddress',
					'addressCountry'  => 'IN',
					'addressRegion'   => $place[1] ?? ( $place[0] ?? '' ),
					'addressLocality' => $place[0] ?? '',
				);
			}
			if ( $phone ) {
				$ngo['telephone'] = $phone;
			}
			if ( has_post_thumbnail( $p->ID ) ) {
				$thumb = get_the_post_thumbnail_url( $p->ID, 'thumbnail' );
				if ( $thumb ) {
					$ngo['image'] = $thumb;
				}
			}
			$item_data['item'] = $ngo;
		}
		$items[] = $item_data;
	}
	$name  = 'aw_listing' === $type && function_exists( 'directoryweb_directory_h1' ) ? directoryweb_directory_h1() : get_the_title( get_queried_object_id() );
	$name  = $view && 'aw_listing' !== $type ? $view['name'] . ' – ' . get_the_title( get_queried_object_id() ) : $name; // "Wildlife – News"
	if ( ! $items ) { // an empty list: the collection page alone
		return array( array( '@type' => 'CollectionPage', '@id' => $url . '#page', 'url' => $url, 'name' => rankweb_plain_text( $name ), 'description' => rankweb_seo_description(), 'inLanguage' => rankweb_language(), 'isPartOf' => array( '@id' => home_url( '/#website' ) ), 'publisher' => array( '@id' => home_url( '/#organization' ) ) ) );
	}
	return array(
		array(
			'@type'       => 'CollectionPage',
			'@id'         => $url . '#page',
			'url'         => $url,
			'name'        => rankweb_plain_text( $name ),
			'description' => rankweb_seo_description(),
			'inLanguage'  => rankweb_language(),
			'isPartOf'    => array( '@id' => home_url( '/#website' ) ),
			'publisher'   => array( '@id' => home_url( '/#organization' ) ),
			'mainEntity'  => array( '@id' => $url . '#list' ),
		),
		array(
			'@type'           => 'ItemList',
			'@id'             => $url . '#list',
			'numberOfItems'   => (int) aw_hub_total( $type ) + $extra,
			'itemListElement' => $items,
		),
	);
}

/** ImageObject of a press item: its stored thumbnail, else the stored publisher logo (null when neither exists). */
function rankweb_press_image_schema( $id ) {
	foreach ( array( (int) get_post_thumbnail_id( $id ), (int) get_post_meta( $id, 'aw_press_logo', true ) ) as $att ) {
		$img = $att ? rankweb_schema_safe_image( rankweb_seo_attachment( $att ) ) : null;
		if ( $img ) {
			return array_filter( array( '@type' => 'ImageObject', 'url' => $img['url'], 'width' => $img['width'], 'height' => $img['height'] ) );
		}
	}
	return null;
}

/** Media & PR page schema: CollectionPage + ItemList. */
function rankweb_press_schema() {
	$list = array();
	foreach ( aw_press_list() as $i => $p ) {
		$list[] = array(
			'@type'    => 'ListItem',
			'position' => $i + 1,
			'item'     => array_filter(
				array(
					'@type'         => 'Article', // coverage of Animal Writes, at the outlet's address
					'headline'      => rankweb_plain_text( get_the_title( $p ) ),
					'about'         => array( '@id' => home_url( '/#organization' ) ),
					'name'          => rankweb_plain_text( get_the_title( $p ) ),
					'url'           => (string) get_post_meta( $p->ID, 'aw_press_url', true ),
					'datePublished' => rankweb_schema_date( (string) get_post_meta( $p->ID, 'aw_press_date', true ) ),
					'publisher'     => get_post_meta( $p->ID, 'aw_press_publisher', true ) ? array( '@type' => 'Organization', 'name' => (string) get_post_meta( $p->ID, 'aw_press_publisher', true ) ) : null,
					'image'         => rankweb_press_image_schema( $p->ID ),
				)
			),
		);
	}
	return array_filter( array(
		'@type'       => 'CollectionPage',
		'@id'         => get_permalink() . '#page',
		'url'         => get_permalink(),
		'name'        => rankweb_plain_text( get_the_title() ),
		'description' => rankweb_plain_text( rankweb_seo_description() ),
		'inLanguage'  => rankweb_language(),
		'isPartOf'    => array( '@id' => home_url( '/#website' ) ),
		'mainEntity'  => array( '@type' => 'ItemList', 'itemListElement' => $list ),
	) );
}

// With Rank Math: its one graph carries ours. Our publisher and site replace its defaults (same @id); our item nodes
// replace its automatic article; our breadcrumb trail is the one people see; a page that is itself a collection or a
// contact page replaces Rank Math's plain WebPage. Schemas an editor adds in Rank Math are kept.
add_filter(
	'rank_math/json_ld',
	function ( $data ) {
		if ( is_404() ) {
			return array(); // a missing page has no structured data (as before)
		}
		$data              = (array) $data;
		$data['publisher'] = rankweb_publisher_schema();
		$data['WebSite']   = rankweb_website_schema();
		unset( $data['ProfilePage'] ); // authors are not shown on this site
		$nodes = rankweb_schema_nodes();
		if ( $nodes || is_singular( array( 'aw_news', 'aw_legal', 'post', 'aw_listing', 'aw_opportunity', 'aw_campaign' ) ) ) {
			unset( $data['richSnippet'] ); // Rank Math's type default (Titles & Meta) is filled here; a closed opportunity has none
		}
		foreach ( $nodes as $node ) {
			if ( in_array( $node['@type'] ?? '', array( 'CollectionPage', 'ContactPage' ), true ) ) {
				unset( $data['WebPage'], $data['primaryImage'] );
			}
		}
		foreach ( $nodes as $node ) {
			if ( 'NewsArticle' === ( $node['@type'] ?? '' ) && isset( $data['WebPage'] ) && is_array( $data['WebPage'] ) ) {
				// One date for the story (1 Nov 2026): the page shows the day it was reported, as the NewsArticle does, not
				// the hour the item was published here.
				foreach ( array( 'datePublished', 'dateModified' ) as $k ) {
					if ( ! empty( $node[ $k ] ) ) {
						$data['WebPage'][ $k ] = $node[ $k ];
					}
				}
			}
		}
		foreach ( $nodes as $i => $node ) {
			if ( 'AboutPage' === ( $node['@type'] ?? '' ) && isset( $data['WebPage'] ) && is_array( $data['WebPage'] ) ) {
				$data['WebPage'] = array_merge( $data['WebPage'], array( '@type' => 'AboutPage', 'mainEntity' => $node['mainEntity'] ) ); // Rank Math's page, as an About page
				continue;
			}
			$data[ 'aw_node_' . $i ] = $node;
		}
		$faq = function_exists( 'rankweb_faq_schema' ) ? rankweb_faq_schema() : null; // parsed from the page's own FAQ accordion (animal-writes-core faq.php)
		if ( $faq ) {
			// Every page type has the FAQ now (31 Oct 2026): link it to a node this graph has, else to the page's own node.
			$ids  = array();
			$page = '';
			foreach ( $data as $node ) {
				if ( is_array( $node ) && ! empty( $node['@id'] ) ) {
					$ids[ $node['@id'] ] = true;
					if ( '' === $page && array_intersect( (array) ( $node['@type'] ?? array() ), array( 'WebPage', 'CollectionPage', 'ContactPage', 'AboutPage', 'ItemPage', 'SearchResultsPage' ) ) ) {
						$page = $node['@id'];
					}
				}
			}
			if ( '' !== $page ) {
				$faq['isPartOf']['@id'] = isset( $ids[ $faq['isPartOf']['@id'] ] ) ? $faq['isPartOf']['@id'] : $page;
				$faq['about']['@id']    = isset( $ids[ $faq['about']['@id'] ] ) ? $faq['about']['@id'] : $faq['isPartOf']['@id'];
			}
			$data['aw_faq'] = $faq;
		}
		if ( ! empty( $data['BreadcrumbList']['@id'] ) ) { // Rank Math's own trail (breadcrumbs.php gives it the places and sections)
			foreach ( $data as $k => $node ) {
				if ( is_array( $node ) && in_array( $node['@type'] ?? '', array( 'WebPage', 'CollectionPage', 'ContactPage', 'AboutPage' ), true ) ) {
					$data[ $k ]['breadcrumb'] = array( '@id' => $data['BreadcrumbList']['@id'] );
				}
			}
		}
		if ( isset( $data['WebPage'] ) && is_array( $data['WebPage'] ) && empty( $data['WebPage']['description'] ) ) {
			$desc = rankweb_plain_text( rankweb_seo_description() ); // the page's own search description, so a quote of the page has its summary
			if ( '' !== $desc ) {
				$data['WebPage']['description'] = $desc;
			}
		}
		return rankweb_schema_language( rankweb_schema_x_profiles( $data ) );
	},
	999
);

/**
 * The page's share picture as og:image prints it: an image typed in Rank Math's Social tab, a category's photo, else
 * the share image (helpers.php: a listing's own logo else the Directory band picture; News, Library and research the
 * publisher's image; a hub or Page its band picture; else the site share image). Null on a missing page.
 *
 * @return array|null [url, width, height]
 */
function rankweb_schema_page_image() {
	if ( is_404() ) {
		return null;
	}
	$typed = (int) rankweb_seo_typed( 'facebook_image_id' );
	$img   = $typed ? rankweb_seo_attachment( $typed, 'full' ) : null;
	if ( ! $img && '' !== rankweb_seo_typed( 'facebook_image' ) ) {
		return rankweb_schema_safe_image( array( 'url' => rankweb_seo_typed( 'facebook_image' ), 'width' => 0, 'height' => 0 ) );
	}
	return $img ? rankweb_schema_safe_image( $img ) : rankweb_seo_image();
}

/** Replace every reference {"@id": $from} in a graph with {"@id": $to}. */
function rankweb_schema_swap_ref( $node, $from, $to ) {
	if ( ! is_array( $node ) ) {
		return $node;
	}
	if ( array( '@id' => $from ) === $node ) {
		return array( '@id' => $to );
	}
	foreach ( $node as $k => $v ) {
		$node[ $k ] = rankweb_schema_swap_ref( $v, $from, $to );
	}
	return $node;
}

// Every page's own node names its picture (primaryImageOfPage), the one its og:image shares, so Search Console shows
// it beside the page (17 Oct 2026: only the home page had one). Collection, contact and category pages, which replace
// Rank Math's WebPage, get it too; a Directory profile, which had no page node, gets a WebPage about its organisation.
add_filter(
	'rank_math/json_ld',
	function ( $data ) {
		if ( ! is_array( $data ) || ! $data || is_404() ) {
			return $data;
		}
		$img = rankweb_schema_page_image();
		if ( ! $img || empty( $img['url'] ) ) {
			return $data;
		}
		$url   = html_entity_decode( (string) $img['url'], ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		if ( false !== strpos( $url, '&' ) ) { // Rank Math prints the graph through wp_kses, which turns & into &amp;: the
			$url = strtok( $url, '?' );          // picture's plain address, as og:image prints it (its crop size unknown)
			$img = array( 'url' => $url, 'width' => 0, 'height' => 0 );
		}
		$old   = isset( $data['primaryImage']['@id'] ) ? (string) $data['primaryImage']['@id'] : '';
		$image = array_filter( array( '@type' => 'ImageObject', '@id' => $url, 'url' => $url, 'contentUrl' => $url, 'width' => (int) $img['width'], 'height' => (int) $img['height'] ) );
		if ( '' !== $old && $old !== $url ) {
			$data = rankweb_schema_swap_ref( $data, $old, $url ); // Rank Math's first content picture gives way to the shared one
		}
		$data = array( 'primaryImage' => $image ) + array_diff_key( $data, array( 'primaryImage' => 1 ) );
		$page_types = array( 'WebPage', 'CollectionPage', 'ContactPage', 'AboutPage', 'ItemPage', 'FAQPage', 'SearchResultsPage' );
		$found      = false;
		foreach ( $data as $k => $node ) {
			if ( 'aw_faq' === $k ) {
				continue; // our FAQ is part of the page, not the page itself (a Directory profile still gets its WebPage below)
			}
			if ( is_array( $node ) && array_intersect( (array) ( $node['@type'] ?? array() ), $page_types ) ) {
				$data[ $k ]['primaryImageOfPage'] = array( '@id' => $url );
				$found                            = true;
			}
		}
		if ( ! $found && is_singular() ) { // a Directory profile: the page about the organisation
			$id    = get_queried_object_id();
			$link  = get_permalink( $id );
			$about = null;
			foreach ( $data as $node ) {
				if ( is_array( $node ) && ! empty( $node['@id'] ) && 0 === strpos( (string) $node['@id'], $link ) ) {
					$about = array( '@id' => $node['@id'] );
					break;
				}
			}
			$data['WebPage'] = array_filter(
				array(
					'@type'              => 'WebPage',
					'@id'                => $link . '#webpage',
					'url'                => $link,
					'name'               => rankweb_plain_text( wp_get_document_title() ),
					'description'        => rankweb_plain_text( rankweb_seo_description() ),
					'inLanguage'         => rankweb_language(),
					'isPartOf'           => array( '@id' => home_url( '/#website' ) ),
					'primaryImageOfPage' => array( '@id' => $url ),
					'breadcrumb'         => ! empty( $data['BreadcrumbList']['@id'] ) ? array( '@id' => $data['BreadcrumbList']['@id'] ) : null,
					'mainEntity'         => $about,
					'datePublished'      => get_the_date( 'c', $id ),
					'dateModified'       => get_the_modified_date( 'c', $id ),
				)
			);
		}
		return $data;
	},
	1001
);

/**
 * Plain text in the printed graph. Rank Math prints the graph through wp_kses_post_deep(), which writes every "&" in a
 * value as "&amp;"; JSON-LD is not HTML, so a title such as "Photo & Video Content" reached search engines as
 * "Photo &amp; Video Content" (and query strings in URLs as "&amp;"). The script Rank Math prints is read back and
 * every text value decoded to plain characters; values that are HTML (a JobPosting description) keep their markup.
 * The same pass writes every value to a string, so a list's "position" and "numberOfItems" are numbers again.
 *
 * @param mixed $node Graph or value.
 * @return mixed
 */
function rankweb_schema_plain_values( $node ) {
	if ( is_array( $node ) ) {
		foreach ( $node as $k => $v ) {
			$node[ $k ] = in_array( $k, array( 'position', 'numberOfItems' ), true ) && is_string( $v ) && ctype_digit( $v ) ? (int) $v : rankweb_schema_plain_values( $v );
		}
		return $node;
	}
	if ( is_string( $node ) && false !== strpos( $node, '&' ) && false === strpos( $node, '<' ) ) {
		return html_entity_decode( $node, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}
	return $node;
}
add_action( 'rank_math/head', fn() => ob_start(), 89 ); // Rank Math prints the graph at 90
add_action(
	'rank_math/head',
	function () {
		$html = (string) ob_get_clean();
		echo preg_replace_callback( // phpcs:ignore WordPress.Security.EscapeOutput -- Rank Math's own output; text values decoded, < and > written as < and >
			'#(<script type="application/ld\+json"[^>]*>)(.*?)(</script>)#s',
			function ( $m ) {
				$data = json_decode( $m[2], true );
				return is_array( $data ) ? $m[1] . wp_json_encode( rankweb_schema_plain_values( $data ), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . $m[3] : $m[0];
			},
			$html
		);
	},
	91
);

if ( ! function_exists( 'rankweb_schema_render_standalone_json_ld' ) ) {
	/**
	 * Outputs Schema.org JSON-LD structured data in standalone mode when Rank Math is absent.
	 */
	function rankweb_schema_render_standalone_json_ld(): void {
		if ( is_404() || is_admin() || ( function_exists( 'rankweb_prints_head' ) && ! rankweb_prints_head() ) ) {
			return;
		}
		$graph = array();
		if ( function_exists( 'rankweb_publisher_schema' ) ) {
			$pub = rankweb_publisher_schema();
			if ( ! empty( $pub ) ) {
				$graph[] = $pub;
			}
		}
		if ( function_exists( 'rankweb_website_schema' ) ) {
			$site = rankweb_website_schema();
			if ( ! empty( $site ) ) {
				$graph[] = $site;
			}
		}
		if ( function_exists( 'rankweb_schema_nodes' ) ) {
			$nodes = rankweb_schema_nodes();
			foreach ( $nodes as $node ) {
				if ( ! empty( $node ) ) {
					$graph[] = $node;
				}
			}
		}
		if ( function_exists( 'rankweb_faq_schema' ) ) {
			$faq = rankweb_faq_schema();
			if ( ! empty( $faq ) ) {
				$graph[] = $faq;
			}
		}
		if ( function_exists( 'rankweb_gallery_page_node' ) ) {
			$gallery = rankweb_gallery_page_node();
			if ( $gallery ) {
				$graph[] = $gallery;
			}
		}
		if ( ! empty( $graph ) ) {
			$payload = array(
				'@context' => 'https://schema.org',
				'@graph'   => rankweb_schema_plain_values( $graph ),
			);
			echo "\n" . '<script type="application/ld+json">' . wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . '</script>' . "\n";
		}
	}
}

if ( function_exists( 'rankweb_seo_extras_rank_math' ) && ! rankweb_seo_extras_rank_math() ) {
	add_action( 'wp_head', 'rankweb_schema_render_standalone_json_ld', 20 );
}
