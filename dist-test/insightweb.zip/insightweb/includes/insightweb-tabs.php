<?php
/**
 * Search Insights' other tabs on the shell screen: Keywords, Pages, Check list, Rising, Clarity, Links,
 * Server, Sourcing keywords and any tab added later through the aw_si_tabs filter.
 *
 * On the tab's own address, after its load hook (which still handles every bulk and row action, then redirects back),
 * the tab draws its usual output into a buffer, and Kits Core's page parts (kits_shell_html_parts(),
 * kits-core/includes/admin-shell-parts.php) hand it to the shell: text, notices, its list table and its forms.
 * The shell's PageParts sends every change as the tab's own link or form request.
 *
 * @package insightweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The tabs this file draws: every Search Insights tab but Overview (the Dashboard) and Settings. */
function insightweb_tab_keys(): array {
	return array_merge( array( 'keywords' ), array_keys( insightweb_si_extra_tabs() ) );
}

/**
 * The order of the tabs after Keywords (Dashboard comes first and Settings last): reading screens first (Rising, Pages,
 * Sourcing keywords), then the site screens (Links, Clarity, Server, Check list). Tabs other plugins add through the
 * aw_si_tabs filter keep their order and come last; a tab that is not there (Sourcing without SourceWeb) is skipped.
 *
 * @param array $tabs Key => label, in the order the filter returned them.
 * @return array
 */
function insightweb_tab_order( array $tabs ): array {
	$out = array();
	foreach ( array( 'rising', 'pages', 'sourcing', 'links', 'clarity', 'server', 'checklist' ) as $key ) {
		if ( isset( $tabs[ $key ] ) ) {
			$out[ $key ] = $tabs[ $key ];
		}
	}
	return $out + $tabs;
}

/** Each tab's label: key => label. */
function insightweb_tab_labels(): array {
	return array( 'keywords' => __( 'Keywords', 'insightweb' ) ) + insightweb_si_extra_tabs();
}

/**
 * The tab's own output as parts. The status notices (source states and "Last updated") are NOT printed here any more:
 * they stacked above every tab (owner, 17 Nov 2026). They now show once, on the Overview — see insightweb_overview_parts().
 *
 * @param string $tab A key of insightweb_tab_keys().
 * @return array[]
 */
function insightweb_tab_parts( string $tab ): array {
	if ( ! in_array( $tab, insightweb_tab_keys(), true ) ) {
		return array();
	}
	ob_start();
	if ( 'keywords' === $tab ) {
		insightweb_si_keywords_tab();
	} else {
		do_action( 'aw_si_tab_' . $tab );
	}
	$html = (string) ob_get_clean();
	return function_exists( 'kits_shell_html_parts' ) ? kits_shell_html_parts( $html ) : array();
}

/**
 * The status notices (each source's state, then "Last updated") as parts for the Overview, so they show once at the top
 * of the Dashboard instead of stacking above every tab (owner, 17 Nov 2026).
 *
 * @return array[]
 */
function insightweb_overview_parts(): array {
	if ( ! function_exists( 'kits_shell_html_parts' ) ) {
		return array();
	}
	ob_start();
	insightweb_si_screen_notices();
	return kits_shell_html_parts( (string) ob_get_clean() );
}

/**
 * The Settings tab's rows (Settings saves the numbers itself, through REST) as parts: the result notices, then
 * Schedule, Keys, Keyword map seed, Run now, the snapshot and import rows and Delete data, each with its own form.
 *
 * @return array[]
 */
function insightweb_settings_more_parts(): array {
	if ( ! function_exists( 'kits_shell_html_parts' ) ) {
		return array();
	}
	ob_start();
	insightweb_si_action_notices();
	insightweb_si_settings_tab();
	return kits_shell_html_parts( (string) ob_get_clean() );
}
