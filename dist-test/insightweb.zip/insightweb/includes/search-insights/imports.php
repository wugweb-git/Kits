<?php
/**
 * Imports and paste forms on the Settings tab (plan §5.4): Keyword Planner volumes, Trends averages when the worker
 * can't reach Trends, and data.gov.in / IDSP figures for guides. No Ahrefs import (owner, 25 Oct 2026: no Ahrefs plan
 * and no CSV exports, ever; the Ahrefs keyword and backlink imports were removed). CSV files
 * go through core upload handling (wp_handle_upload) and are deleted once read; pastes work the same way. Only the
 * owner's files are read; nothing is fetched from those services.
 *
 * Rows in obs, period month, d = first of the import month:
 * - kp: volume (value = lower bound of the range, txt = the range as shown), per keyword;
 * - trends (period 12m, d = import day): index per keyword, the same rows the worker writes, so priority uses it;
 * - gov: one figure per state and measure (txt = "state | measure | source | as of"), page_key = md5 of state|measure.
 *
 * @package insightweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The import kinds and their labels. */
function insightweb_si_import_kinds(): array {
	$kinds = array(
		'kp'     => __( 'Keyword Planner (CSV export: Keyword, Avg. monthly searches)', 'insightweb' ),
		'trends' => __( 'Google Trends averages (paste: keyword, value; "animal welfare" = 100)', 'insightweb' ),
		'gov'    => __( 'data.gov.in / IDSP figures (paste: state, measure, value, as of, source URL)', 'insightweb' ),
	);
	return (array) apply_filters( 'aw_si_import_kinds', $kinds ); // tool-imports.php adds Ubersuggest, vidIQ, OpenSEO.
}

/**
 * Rows of a CSV or TSV text: header (lower case) and rows as header => value. Reads UTF-16 exports (Keyword Planner),
 * skips title lines before the header, and finds the delimiter.
 *
 * @param string $raw       File or pasted text.
 * @param string $must_have A word the header row contains (e.g. keyword).
 * @return array{0: string[], 1: array<int, array<string, string>>}
 */
function insightweb_si_parse_table( string $raw, string $must_have = '' ): array {
	if ( 0 === strpos( $raw, "\xFF\xFE" ) || 0 === strpos( $raw, "\xFE\xFF" ) || 20 < substr_count( substr( $raw, 0, 200 ), "\0" ) ) {
		$from = str_starts_with( $raw, "\xFE\xFF" ) ? 'UTF-16BE' : 'UTF-16LE';
		$raw  = (string) mb_convert_encoding( $raw, 'UTF-8', $from );
	}
	$raw   = preg_replace( '/^\xEF\xBB\xBF/', '', $raw );
	$lines = preg_split( '/\r\n|\r|\n/', trim( (string) $raw ) );
	$head  = null;
	$delim = ',';
	$rows  = array();
	foreach ( (array) $lines as $line ) {
		if ( '' === trim( $line ) ) {
			continue;
		}
		if ( null === $head ) {
			$delim = substr_count( $line, "\t" ) > substr_count( $line, ',' ) ? "\t" : ',';
			$cells = array_map( fn( $c ) => strtolower( trim( (string) $c ) ), str_getcsv( $line, $delim, '"', '\\' ) );
			// The header has two columns or more, one of them naming $must_have (title lines such as Keyword Planner's
			// "Keyword Stats …" have one).
			if ( count( $cells ) >= 2 && ( '' === $must_have || preg_grep( '/' . preg_quote( $must_have, '/' ) . '/', $cells ) ) ) {
				$head = $cells;
			}
			continue;
		}
		$cells = str_getcsv( $line, $delim, '"', '\\' );
		$row   = array();
		foreach ( $head as $i => $h ) {
			$row[ $h ] = trim( (string) ( $cells[ $i ] ?? '' ) );
		}
		$rows[] = $row;
	}
	return array( (array) $head, $rows );
}

/**
 * The first column whose name contains one of the words.
 *
 * @param string[] $head  Header.
 * @param string[] $words Words to look for, in order.
 */
function insightweb_si_import_col( array $head, array $words ): string {
	foreach ( $words as $w ) {
		foreach ( $head as $h ) {
			if ( false !== strpos( $h, $w ) ) {
				return $h;
			}
		}
	}
	return '';
}

/**
 * A search volume as a number: "1,300" → 1300, "1K – 10K" → 1000 (the lower bound), "2.4K" → 2400.
 *
 * @param string $v Cell text.
 */
function insightweb_si_import_number( string $v ): ?float {
	if ( ! preg_match( '/([0-9][0-9,.]*)\s*([kKmM]?)/', $v, $m ) ) {
		return null;
	}
	$n = (float) str_replace( ',', '', $m[1] );
	return $n * ( 'k' === strtolower( $m[2] ) ? 1000 : ( 'm' === strtolower( $m[2] ) ? 1000000 : 1 ) );
}

/**
 * Store one import.
 *
 * @param string $kind kp, trends or gov.
 * @param string $raw  File or pasted text.
 * @return array{rows: int, skipped: int, error: string}
 */
function insightweb_si_import( string $kind, string $raw ): array {
	global $wpdb;
	$o     = insightweb_si_table( 'obs' );
	$other = apply_filters( 'aw_si_import_run', null, $kind, $raw ); // An import kind added by another file.
	if ( is_array( $other ) ) {
		return $other;
	}
	$month = wp_date( 'Y-m-01' );
	$out   = array(
		'rows'    => 0,
		'skipped' => 0,
		'error'   => '',
	);
	$put   = function ( bool $ok ) use ( &$out ) {
		$ok ? ++$out['rows'] : ++$out['skipped'];
	};
	if ( 'trends' === $kind || 'gov' === $kind ) {
		$lines = array_filter( array_map( 'trim', (array) preg_split( '/\r\n|\r|\n/', $raw ) ) );
		foreach ( $lines as $line ) {
			$cells = array_map( 'trim', str_getcsv( $line, substr_count( $line, "\t" ) ? "\t" : ',', '"', '\\' ) );
			if ( 'trends' === $kind ) {
				$v = isset( $cells[1] ) && is_numeric( $cells[1] ) ? (float) $cells[1] : null;
				if ( '' === ( $cells[0] ?? '' ) || null === $v ) {
					++$out['skipped'];
					continue;
				}
				$id = (int) current( insightweb_si_kw_ids( array( sanitize_text_field( $cells[0] ) ), 0 ) );
				if ( $id ) { // A new paste replaces the keyword's earlier pasted figure (the workers' rows stay).
					$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE src = 'trends' AND metric = 'index' AND period = '12m' AND kw_id = %d AND txt = 'import'", $o, $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				}
				$put(
					$id && insightweb_si_obs_put(
						$id,
						'',
						'trends',
						'index',
						'12m',
						wp_date( 'Y-m-d' ),
						array(
							'value' => $v,
							'txt'   => 'import', // Marks pasted rows apart from the workers job's.
						)
					)
				);
				continue;
			}
			$v = isset( $cells[2] ) ? insightweb_si_import_number( $cells[2] ) : null;
			if ( count( $cells ) < 3 || null === $v || '' === $cells[0] || '' === $cells[1] ) {
				++$out['skipped'];
				continue;
			}
			$key = sanitize_text_field( $cells[0] ) . '|' . sanitize_text_field( $cells[1] );
			$txt = implode( ' | ', array( sanitize_text_field( $cells[0] ), sanitize_text_field( $cells[1] ), esc_url_raw( $cells[4] ?? '' ), sanitize_text_field( $cells[3] ?? '' ) ) );
			$put(
				insightweb_si_obs_put(
					0,
					$key,
					'gov',
					'figure',
					'month',
					$month,
					array(
						'value' => $v,
						'txt'   => $txt,
					)
				)
			);
		}
		return $out;
	}
	list( $head, $rows ) = insightweb_si_parse_table( $raw, 'keyword' );
	if ( ! $head ) {
		$out['error'] = __( 'No header row was found. Check that the file is the right export.', 'insightweb' );
		return $out;
	}
	$kcol = insightweb_si_import_col( $head, array( 'keyword' ) );
	$vcol = insightweb_si_import_col( $head, array( 'avg. monthly searches', 'monthly searches', 'volume' ) );
	if ( '' === $kcol || '' === $vcol ) {
		$out['error'] = __( 'The file needs a keyword column and a volume column.', 'insightweb' );
		return $out;
	}
	$labels = array_filter( array_map( fn( $r ) => sanitize_text_field( (string) $r[ $kcol ] ), $rows ) );
	$ids    = insightweb_si_kw_ids( $labels, 0 );
	foreach ( $rows as $r ) {
		$id  = (int) ( $ids[ insightweb_si_norm( sanitize_text_field( (string) $r[ $kcol ] ) ) ] ?? 0 );
		$vol = insightweb_si_import_number( (string) $r[ $vcol ] );
		if ( ! $id || null === $vol ) {
			++$out['skipped'];
			continue;
		}
		$put(
			insightweb_si_obs_put(
				$id,
				'',
				$kind,
				'volume',
				'month',
				$month,
				array(
					'value' => $vol,
					'txt'   => mb_substr( (string) $r[ $vcol ], 0, 40 ),
				)
			)
		);
	}
	return $out;
}

/** Settings tab rows: imports and paste forms (added to the form-table through aw_si_settings_rows). */
function insightweb_si_import_rows(): void {
	echo '<tr><th scope="row"><label for="aw-si-import-kind">' . esc_html__( 'Imports', 'insightweb' ) . '</label></th><td>';
	echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="aw_si_import">';
	wp_nonce_field( 'aw_si_import' );
	echo '<p><select id="aw-si-import-kind" name="kind">';
	foreach ( insightweb_si_import_kinds() as $k => $label ) {
		echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</option>';
	}
	echo '</select></p>';
	echo '<p><label for="aw-si-import-file">' . esc_html__( 'CSV file', 'insightweb' ) . '</label> <input type="file" id="aw-si-import-file" name="file" accept=".csv,.tsv,.txt,text/csv,text/plain"></p>';
	echo '<p><label for="aw-si-import-paste">' . esc_html__( 'Or paste', 'insightweb' ) . '</label><br><textarea id="aw-si-import-paste" name="paste" rows="5" class="large-text"></textarea></p>';
	submit_button( __( 'Import', 'insightweb' ), 'secondary', 'submit', false );
	echo '<p class="description">' . esc_html__( 'Files are read once and deleted. Volumes and positions are stored for this month; a second import in the same month replaces the first.', 'insightweb' ) . '</p>';
	echo '</form>';
	global $wpdb;
	if ( insightweb_si_ready() ) {
		$o    = insightweb_si_table( 'obs' );
		$last = (array) $wpdb->get_results( $wpdb->prepare( "SELECT src, MAX(fetched) f, COUNT(*) n FROM %i WHERE src IN ('kp', 'gov', 'openseo_serp') OR (src = 'trends' AND txt = 'import') GROUP BY src", $o ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $last ) {
			echo '<ul>';
			foreach ( $last as $l ) {
				/* translators: 1: source, 2: rows, 3: date and time. */
				echo '<li>' . esc_html( sprintf( __( '%1$s: %2$s rows, last import %3$s', 'insightweb' ), $l->src, number_format_i18n( (int) $l->n ), mysql2date( 'j M Y, H:i', $l->f ) ) ) . '</li>';
			}
			echo '</ul>';
		}
	}
	echo '</td></tr>';
}
add_action( 'aw_si_settings_rows', 'insightweb_si_import_rows' );

/**
 * Who may send an import: the Search Insights managers, or a separate sender account that has only the capability
 * insightweb_si_import (the owner creates that user; it can import and nothing else in Search Insights).
 */
function insightweb_si_can_import(): bool {
	return current_user_can( insightweb_si_cap() ) || current_user_can( 'aw_si_import' );
}

add_action(
	'admin_post_aw_si_import',
	function () {
		if ( ! insightweb_si_can_import() || ! check_admin_referer( 'aw_si_import' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'insightweb' ), 403 );
		}
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : '';
		if ( ! isset( insightweb_si_import_kinds()[ $kind ] ) ) {
			wp_die( esc_html__( 'Unknown import.', 'insightweb' ), 400 );
		}
		$raw = isset( $_POST['paste'] ) ? (string) wp_unslash( $_POST['paste'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- parsed as CSV; each value is sanitised where it is stored.
		if ( ! empty( $_FILES['file']['name'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			// The extension is checked here; WordPress's content sniffing is skipped because Keyword Planner's UTF-16
			// exports are often detected as binary and refused. The file is only read as text and deleted at once.
			$name = sanitize_file_name( wp_unslash( $_FILES['file']['name'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised here.
			if ( ! in_array( strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ), array( 'csv', 'tsv', 'txt' ), true ) ) {
				wp_die( esc_html__( 'Upload a .csv, .tsv or .txt file.', 'insightweb' ), '', array( 'back_link' => true ) );
			}
			$up = wp_handle_upload(
				$_FILES['file'], // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- core upload handling checks it.
				array(
					'test_form' => false,
					'test_type' => false,
				)
			);
			if ( ! empty( $up['error'] ) ) {
				wp_die( esc_html( $up['error'] ), '', array( 'back_link' => true ) );
			}
			$raw = (string) file_get_contents( $up['file'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- the uploaded file.
			wp_delete_file( $up['file'] );
		}
		$res = '' === trim( $raw ) ? array(
			'rows'    => 0,
			'skipped' => 0,
			'error'   => __( 'Nothing to import: choose a file or paste the rows.', 'insightweb' ),
		) : insightweb_si_import( $kind, $raw );
		set_transient( 'aw_si_import_result_' . get_current_user_id(), $res + array( 'kind' => $kind ), 5 * MINUTE_IN_SECONDS );
		wp_safe_redirect( add_query_arg( 'imported', 1, insightweb_si_return_url( 'settings' ) ) );
		exit;
	}
);

add_action(
	'aw_si_settings_notices',
	function () {
		if ( ! isset( $_GET['imported'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- message only.
			return;
		}
		$r = get_transient( 'aw_si_import_result_' . get_current_user_id() );
		if ( ! is_array( $r ) ) {
			return;
		}
		if ( '' !== $r['error'] ) {
			wp_admin_notice( esc_html( $r['error'] ), array( 'type' => 'error', 'additional_classes' => array( 'inline' ) ) );
			return;
		}
		/* translators: 1: import kind, 2: rows stored, 3: rows skipped. */
		$msg = sprintf( __( '%1$s: %2$s rows stored, %3$s skipped.', 'insightweb' ), insightweb_si_import_kinds()[ $r['kind'] ] ?? $r['kind'], number_format_i18n( (int) $r['rows'] ), number_format_i18n( (int) $r['skipped'] ) );
		if ( ! empty( $r['other'] ) ) {
			/* translators: %s: rows. */
			$msg .= ' ' . sprintf( __( '%s rows from another source (such as the browser checks) were left out.', 'insightweb' ), number_format_i18n( (int) $r['other'] ) );
		}
		if ( ! empty( $r['rising'] ) ) {
			/* translators: %s: terms. */
			$msg .= ' ' . sprintf( __( '%s terms that are not keywords yet went to Rising.', 'insightweb' ), number_format_i18n( (int) $r['rising'] ) );
		}
		wp_admin_notice( esc_html( $msg ), array( 'type' => 'success', 'additional_classes' => array( 'inline' ) ) );
	}
);

add_filter(
	'aw_si_sources',
	function ( $s ) {
		$s['live'] = array(
			'label' => __( 'Live Google check (bookmarklet)', 'insightweb' ),
			'every' => MONTH_IN_SECONDS,
		);
		return $s;
	}
);

/**
 * The 21 Oct rankings seed stored live results (src live, 22 Oct 2026) without a run in the log, so the Live Google check
 * read "not run yet" beside its own figures. Once, the newest stored live result counts as the source's last run, marked
 * as the seed; the bookmarklet's own runs replace it (1 Nov 2026, flag aw_si_live_seed_run).
 */
add_action(
	'admin_init',
	function () {
		if ( get_option( 'aw_si_live_seed_run' ) || ! insightweb_si_ready() || ! empty( insightweb_si_runs()['live']['ok'] ) ) {
			return;
		}
		global $wpdb;
		$o   = insightweb_si_table( 'obs' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT MAX(d) d, COUNT(*) n FROM %i WHERE src = 'live' AND metric = 'position'", $o ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $row && $row->d && (int) $row->n > 0 ) {
			$r         = insightweb_si_runs();
			$r['live'] = array(
				'ok'      => (int) strtotime( $row->d . ' 12:00:00' ),
				'error'   => null,
				'info'    => array(
					'rows'   => (int) $row->n,
					'up_to'  => (string) $row->d,
					'seed'   => true,
					'status' => 'ok',
				),
				'started' => 0,
			);
			update_option( AW_SI_RUNS, $r, false );
		}
		update_option( 'aw_si_live_seed_run', time(), false );
	}
);
