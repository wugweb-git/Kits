<?php
/**
 * Crawler access (owner, 31 Oct 2026; Search Insights step 3). On 26 Oct an SEO tool's crawler got no answer on 17 of 20
 * pages, while the same pages answered 200 from the owner's Mac and from the server. Two weekly checks:
 * - inside: this server asks the home page and five sample pages (a Directory listing, a News item, a Library item, a
 *   Resources guide, an Opportunity) with each search and AI crawler's user agent (Monday 08:45 IST). A request from the
 *   server to itself does not show blocks that depend on the caller's address, so it only catches user-agent rules;
 * - outside: the workers job crawl-check.yml asks the same pages from a GitHub runner (an outside data-centre address),
 *   plus a 20-page burst, and posts here (aw/v1/search-insights/crawl, the ingest user's application password).
 * A page that is not a 200, or a 200 that is not one of our pages (a challenge page), is a problem: Site Health shows
 * it and the owner gets one email per new set of problems. Results are kept 12 weeks.
 * From outside, a search or AI crawler's name sent from a GitHub address is a fake, and Hostinger's CDN refuses fakes
 * (403, 429 or no answer) while letting the real crawlers in by their own addresses (hPanel → CDN → AI Audit: 0 blocked,
 * 31 Oct 2026). Those refusals are "expected", not problems (owner, 31 Oct 2026); the browser, the generic crawler and
 * the bursts still count from outside, and every agent counts from the server.
 *
 * obs rows: src crawl, period day, metric inside / outside, txt = agent, value = problems in that run.
 *
 * @package insightweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const AW_SI_CRAWL_CRON  = 'aw_si_crawl';
const AW_SI_CRAWL_IN    = 'aw_si_crawl_inside'; // Option: the last inside run.
const AW_SI_CRAWL_OUT   = 'aw_si_crawl_outside'; // Option: the last outside run.
const AW_SI_CRAWL_WEEKS = 12;
const AW_SI_CRAWL_TIME  = 240; // Seconds the inside run may take before it stops.
const AW_SI_CRAWL_STALE = 15 * DAY_IN_SECONDS; // An outside run older than this no longer counts (the job stopped?).

/** User agents: the same as the workers job (aw_workers/crawl_check.py AGENTS). */
function insightweb_si_crawl_agents(): array {
	return (array) apply_filters(
		'aw_si_crawl_agents',
		array(
			'Browser'         => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36',
			'Googlebot'       => 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
			'Bingbot'         => 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
			'GPTBot'          => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.2; +https://openai.com/gptbot)',
			'OAI-SearchBot'   => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; OAI-SearchBot/1.0; +https://openai.com/searchbot',
			'ChatGPT-User'    => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot',
			'PerplexityBot'   => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; PerplexityBot/1.0; +https://perplexity.ai/perplexitybot)',
			'ClaudeBot'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ClaudeBot/1.0; +claudebot@anthropic.com)',
			'Google-Extended' => 'Mozilla/5.0 (compatible; Google-Extended)',
			'Applebot'        => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.1 Safari/605.1.15 (Applebot/0.1; +http://www.apple.com/go/applebot)',
			'Generic crawler' => 'Mozilla/5.0 (compatible; SiteAuditBot/1.0; +' . home_url( '/' ) . ')', // An SEO tool's kind of crawler, not a named bot.
		)
	);
}

/**
 * The sample pages (newest published of each kind) and up to 20 pages for the outside burst.
 *
 * @return array{pages: array<int, array{kind: string, url: string}>, burst: string[]}
 */
function insightweb_si_crawl_pages(): array {
	$pages = array(
		array(
			'kind' => 'home',
			'url'  => home_url( '/' ),
		),
	);
	$extra = array();
	$kinds = array(
		'listing'     => 'aw_listing',
		'news'        => 'aw_news',
		'library'     => 'aw_legal',
		'resource'    => 'post',
		'opportunity' => 'aw_opportunity',
	);
	foreach ( $kinds as $kind => $type ) {
		if ( ! post_type_exists( $type ) ) {
			continue;
		}
		$urls = array();
		foreach ( get_posts(
			array(
				'post_type'        => $type,
				'post_status'      => 'publish',
				'numberposts'      => 'resource' === $kind ? 30 : 4,
				'orderby'          => 'date',
				'order'            => 'DESC',
				'fields'           => 'ids',
				'suppress_filters' => false,
			)
		) as $id ) {
			$url = (string) get_permalink( $id );
			if ( 'resource' === $kind && false === strpos( $url, '/resources/' ) ) {
				continue; // Resources guides are posts under /resources/.
			}
			$urls[] = $url;
		}
		if ( $urls ) {
			$pages[] = array(
				'kind' => $kind,
				'url'  => array_shift( $urls ),
			);
			$extra   = array_merge( $extra, array_slice( $urls, 0, 3 ) );
		}
	}
	foreach ( array( '/about/', '/contact/', '/directory/', '/library/', '/news/', '/campaigns/' ) as $path ) {
		$extra[] = home_url( $path );
	}
	$burst = array_values( array_unique( array_merge( wp_list_pluck( $pages, 'url' ), $extra ) ) );
	return array(
		'pages' => $pages,
		'burst' => array_slice( $burst, 0, 20 ),
	);
}

/**
 * The verdict on one answer: ok, refused (not a 200) or challenge (a 200 that is not one of our pages).
 *
 * @param int    $code HTTP status (0: no answer).
 * @param string $body Response body.
 */
function insightweb_si_crawl_verdict( int $code, string $body ): string {
	if ( 200 !== $code ) {
		return 'refused';
	}
	// One of our pages has a canonical link or, on a noindex page without one, our /wp-content/ assets; a CDN challenge has neither.
	$ours = false !== strpos( $body, 'rel="canonical"' ) || false !== strpos( $body, "rel='canonical'" ) || false !== strpos( $body, '/wp-content/' );
	return $ours ? 'ok' : 'challenge';
}

/**
 * The inside run: every agent on every sample page, from this server. Stored unless $dry.
 *
 * @param bool $dry Check only.
 * @return array{at: int, runner: string, checks: array, cut: bool}
 */
function insightweb_si_crawl_run( bool $dry = false ): array {
	if ( ! $dry ) {
		insightweb_si_run_start( 'crawl-in' );
	}
	if ( function_exists( 'set_time_limit' ) ) {
		set_time_limit( AW_SI_CRAWL_TIME + 60 ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions -- the run stops itself at AW_SI_CRAWL_TIME.
	}
	$plan   = insightweb_si_crawl_pages();
	$start  = time();
	$checks = array();
	$cut    = false;
	foreach ( insightweb_si_crawl_agents() as $agent => $ua ) {
		foreach ( $plan['pages'] as $p ) {
			if ( time() - $start > AW_SI_CRAWL_TIME ) {
				$cut = true;
				break 2;
			}
			$t    = microtime( true );
			$resp = wp_remote_get(
				$p['url'],
				array(
					'user-agent'  => $ua,
					'timeout'     => 20,
					'redirection' => 3,
					'headers'     => array( 'Cache-Control' => 'no-cache' ),
				)
			);
			$code     = is_wp_error( $resp ) ? 0 : (int) wp_remote_retrieve_response_code( $resp );
			$checks[] = array(
				'agent'  => $agent,
				'kind'   => $p['kind'],
				'url'    => $p['url'],
				'code'   => $code,
				'ms'     => (int) round( ( microtime( true ) - $t ) * 1000 ),
				'result' => is_wp_error( $resp ) ? 'refused' : insightweb_si_crawl_verdict( $code, (string) wp_remote_retrieve_body( $resp ) ),
				'error'  => is_wp_error( $resp ) ? $resp->get_error_message() : '',
			);
		}
	}
	$run = array(
		'at'     => time(),
		'runner' => 'server',
		'checks' => $checks,
		'burst'  => array(),
		'cut'    => $cut,
	);
	if ( ! $dry ) {
		insightweb_si_crawl_store( 'inside', $run );
		if ( $cut ) {
			/* translators: %d: seconds. */
			insightweb_si_run_fail( 'crawl-in', sprintf( __( 'The check stopped after %d seconds; some agents were not asked.', 'insightweb' ), AW_SI_CRAWL_TIME ) );
		}
	}
	return $run;
}

/**
 * A stored run, or [] when there is none, or (outside only) it is older than AW_SI_CRAWL_STALE.
 *
 * @param string $opt AW_SI_CRAWL_IN or AW_SI_CRAWL_OUT.
 */
function insightweb_si_crawl_last( string $opt ): array {
	$run = (array) get_option( $opt, array() );
	if ( empty( $run['at'] ) || ( AW_SI_CRAWL_OUT === $opt && time() - (int) $run['at'] > AW_SI_CRAWL_STALE ) ) {
		return array();
	}
	return $run;
}

/** Named search and AI crawlers that CDNs check by address: from outside, a refusal of their name is a refused fake. */
function insightweb_si_crawl_verified_bots(): array {
	return array( 'Googlebot', 'Bingbot', 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'PerplexityBot', 'ClaudeBot', 'Google-Extended', 'Applebot' );
}

/**
 * Whether a failed check is expected: an outside run, a named crawler, refused (403, 429 or no answer).
 *
 * @param array $run The run.
 * @param array $c   One check.
 */
function insightweb_si_crawl_expected( array $run, array $c ): bool {
	return 'server' !== ( $run['runner'] ?? 'server' ) && 'refused' === ( $c['result'] ?? '' )
		&& in_array( (string) ( $c['agent'] ?? '' ), insightweb_si_crawl_verified_bots(), true ) && in_array( (int) ( $c['code'] ?? 0 ), array( 0, 403, 429 ), true );
}

/**
 * Expected refusals in one run (fake named crawlers refused from outside), in plain words.
 *
 * @param array $run A stored run.
 * @return string[]
 */
function insightweb_si_crawl_refused_fakes( array $run ): array {
	$out = array();
	foreach ( (array) ( $run['checks'] ?? array() ) as $c ) {
		if ( 'ok' !== ( $c['result'] ?? '' ) && insightweb_si_crawl_expected( $run, $c ) ) {
			$out[] = sprintf( '%s, %s: %s', $c['agent'], $c['kind'], $c['code'] ? 'HTTP ' . $c['code'] : __( 'no answer', 'insightweb' ) );
		}
	}
	return $out;
}

/**
 * Problems in one run, in plain words.
 *
 * @param array $run A stored run.
 * @return string[]
 */
function insightweb_si_crawl_problems( array $run ): array {
	$out = array();
	foreach ( (array) ( $run['checks'] ?? array() ) as $c ) {
		if ( 'ok' !== ( $c['result'] ?? '' ) && ! insightweb_si_crawl_expected( $run, $c ) ) {
			$what  = 'challenge' === $c['result'] ? __( 'challenge page', 'insightweb' ) : ( $c['code'] ? 'HTTP ' . $c['code'] : __( 'no answer', 'insightweb' ) );
			$out[] = sprintf( '%s, %s: %s', $c['agent'], $c['kind'], $what );
		}
	}
	if ( ! empty( $run['cut'] ) ) {
		$out[] = __( 'The check stopped early: some agents and pages were not asked.', 'insightweb' );
	}
	foreach ( (array) ( $run['burst'] ?? array() ) as $b ) {
		if ( (int) ( $b['ok'] ?? 0 ) < (int) ( $b['n'] ?? 0 ) ) {
			/* translators: 1: agent, 2: pages that answered, 3: pages asked. */
			$out[] = sprintf( __( 'Burst as %1$s: %2$d of %3$d pages answered', 'insightweb' ), $b['agent'], (int) $b['ok'], (int) $b['n'] );
		}
	}
	return $out;
}

/**
 * Store a run: the latest in its option, problems per agent in obs (kept 12 weeks), the run log, and the alert.
 *
 * @param string $side inside or outside.
 * @param array  $run  The run.
 */
function insightweb_si_crawl_store( string $side, array $run ): void {
	global $wpdb;
	update_option( 'inside' === $side ? AW_SI_CRAWL_IN : AW_SI_CRAWL_OUT, $run, false );
	$day = wp_date( 'Y-m-d', (int) $run['at'] );
	$per = array();
	foreach ( (array) $run['checks'] as $c ) {
		$per[ $c['agent'] ] = ( $per[ $c['agent'] ] ?? 0 ) + ( 'ok' === $c['result'] || insightweb_si_crawl_expected( $run, $c ) ? 0 : 1 );
	}
	$o = insightweb_si_table( 'obs' );
	foreach ( $per as $agent => $n ) {
		$wpdb->replace( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$o,
			array(
				'kw_id'    => 0,
				'page'     => '',
				'page_key' => md5( 'agent:' . $agent ), // One row per agent and day (insightweb_si_obs_put keys rows by page).
				'src'      => 'crawl',
				'metric'   => $side,
				'period'   => 'day',
				'd'        => $day,
				'value'    => (float) $n,
				'txt'      => mb_substr( (string) $agent, 0, 255 ),
				'fetched'  => insightweb_si_now(),
			)
		);
	}
	$keep = ( new DateTimeImmutable( 'today', wp_timezone() ) )->modify( '-' . AW_SI_CRAWL_WEEKS . ' weeks' )->format( 'Y-m-d' );
	$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE src = 'crawl' AND d < %s", $o, $keep ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$problems = insightweb_si_crawl_problems( $run );
	insightweb_si_run_ok(
		'inside' === $side ? 'crawl-in' : 'crawl-out',
		array(
			'checks'   => count( (array) $run['checks'] ),
			'problems' => count( $problems ),
		)
	);
	insightweb_si_crawl_alert();
}

/** Email the owner once per new set of problems (inside and outside together). */
function insightweb_si_crawl_alert(): void {
	$all = array();
	foreach ( array(
		__( 'From the server', 'insightweb' )  => AW_SI_CRAWL_IN,
		__( 'From outside', 'insightweb' )     => AW_SI_CRAWL_OUT,
	) as $label => $opt ) {
		foreach ( insightweb_si_crawl_problems( insightweb_si_crawl_last( $opt ) ) as $p ) {
			$all[] = $label . ': ' . $p;
		}
	}
	if ( ! $all ) {
		delete_option( 'aw_si_crawl_mailed' );
		return;
	}
	$key = md5( implode( "\n", $all ) );
	if ( get_option( 'aw_si_crawl_mailed' ) === $key ) {
		return; // The same problems were already emailed.
	}
	$site_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	$site_name = (string) get_bloginfo( 'name' );
	$body      = "Some search or AI crawlers could not read {$site_host} pages:\n\n- " . implode( "\n- ", $all ) . "\n\nSite Health: " . admin_url( 'site-health.php' ) . "\nSearch Insights: " . insightweb_si_url() . "\n";
	if ( wp_mail( get_option( 'admin_email' ), $site_name . ': crawler access problem — ' . $all[0], $body ) ) {
		update_option( 'aw_si_crawl_mailed', $key, false );
	}
}

/**
 * Take the outside results from the workers job.
 *
 * @param array $body JSON body: runner, started, checks [{agent, kind, url, code, ms, bytes, result, error}], burst.
 * @return array|WP_Error What was stored.
 */
function insightweb_si_crawl_receive( array $body ) {
	$checks = array();
	foreach ( array_slice( (array) ( $body['checks'] ?? array() ), 0, 500 ) as $c ) {
		if ( ! is_array( $c ) || empty( $c['agent'] ) ) {
			continue;
		}
		$checks[] = array(
			'agent'  => sanitize_text_field( (string) $c['agent'] ),
			'kind'   => sanitize_key( (string) ( $c['kind'] ?? '' ) ),
			'url'    => esc_url_raw( (string) ( $c['url'] ?? '' ) ),
			'code'   => (int) ( $c['code'] ?? 0 ),
			'ms'     => (int) ( $c['ms'] ?? 0 ),
			'result' => in_array( $c['result'] ?? '', array( 'ok', 'refused', 'challenge' ), true ) ? $c['result'] : 'refused',
			'error'  => sanitize_text_field( (string) ( $c['error'] ?? '' ) ),
		);
	}
	if ( ! $checks ) {
		return new WP_Error( 'aw_si_crawl', __( 'No checks in the request.', 'insightweb' ), array( 'status' => 400 ) );
	}
	$burst = array();
	foreach ( array_slice( (array) ( $body['burst'] ?? array() ), 0, 20 ) as $b ) {
		if ( is_array( $b ) && ! empty( $b['agent'] ) ) {
			$burst[] = array(
				'agent'  => sanitize_text_field( (string) $b['agent'] ),
				'n'      => (int) ( $b['n'] ?? 0 ),
				'ok'     => (int) ( $b['ok'] ?? 0 ),
				'codes'  => array_map( 'intval', array_filter( (array) ( $b['codes'] ?? array() ), 'is_scalar' ) ),
				'max_ms' => (int) ( $b['max_ms'] ?? 0 ),
			);
		}
	}
	$run = array(
		'at'     => time(),
		'runner' => sanitize_key( (string) ( $body['runner'] ?? 'github' ) ),
		'checks' => $checks,
		'burst'  => $burst,
		'cut'    => ! empty( $body['cut'] ), // The workers job stopped at its deadline.
	);
	insightweb_si_crawl_store( 'outside', $run );
	return array(
		'checks'   => count( $checks ),
		'problems' => count( insightweb_si_crawl_problems( $run ) ),
	);
}

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'aw/v1',
			'/search-insights/crawl',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => 'insightweb_si_api_allowed',
					'callback'            => fn() => rest_ensure_response( insightweb_si_crawl_pages() + array( 'agents' => insightweb_si_crawl_agents() ) ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => 'insightweb_si_api_allowed',
					'callback'            => function ( WP_REST_Request $req ) {
						$body = $req->get_json_params();
						$out  = insightweb_si_crawl_receive( is_array( $body ) ? $body : array() );
						return is_wp_error( $out ) ? $out : rest_ensure_response( $out );
					},
				),
			)
		);
	}
);

add_action( AW_SI_CRAWL_CRON, fn() => get_option( 'aw_si_off' ) ? null : insightweb_si_crawl_run() );

add_action(
	'init',
	function () {
		if ( ! get_option( 'aw_si_off' ) && ! wp_next_scheduled( AW_SI_CRAWL_CRON ) ) {
			wp_schedule_event( ( new DateTimeImmutable( 'next monday 08:45', wp_timezone() ) )->getTimestamp(), 'weekly', AW_SI_CRAWL_CRON );
		}
	}
);

add_filter(
	'aw_si_cron_hooks',
	function ( $hooks ) {
		$hooks[] = AW_SI_CRAWL_CRON;
		return $hooks;
	}
);

add_filter(
	'aw_si_sources',
	function ( $s ) {
		$s['crawl-in'] = array(
			'label' => __( 'Crawler access, from the server', 'insightweb' ),
			'every' => WEEK_IN_SECONDS,
		);
		if ( get_option( AW_SI_CRAWL_OUT ) ) { // Listed once the workers job has reported, so it never shows as late before.
			$s['crawl-out'] = array(
				'label' => __( 'Crawler access, from outside (workers)', 'insightweb' ),
				'every' => WEEK_IN_SECONDS,
			);
		}
		return $s;
	}
);

/** Site Health test: the last inside and outside runs. */
function insightweb_si_crawl_health_test(): array {
	$items = '';
	$any   = false;
	$bad   = 0;
	$out   = (bool) insightweb_si_crawl_last( AW_SI_CRAWL_OUT );
	foreach ( array(
		__( 'From the server (user-agent rules only)', 'insightweb' ) => AW_SI_CRAWL_IN,
		__( 'From outside (GitHub runner, weekly)', 'insightweb' )    => AW_SI_CRAWL_OUT,
	) as $label => $opt ) {
		$run = insightweb_si_crawl_last( $opt );
		if ( empty( $run['at'] ) ) {
			$items .= '<li>' . esc_html( $label . ': ' . __( 'no result from the last 15 days.', 'insightweb' ) ) . '</li>';
			continue;
		}
		$any      = true;
		$problems = insightweb_si_crawl_problems( $run );
		$bad     += count( $problems );
		/* translators: 1: date, 2: checks, 3: problems. */
		$line   = sprintf( __( '%1$s: %2$d checks, %3$d problems', 'insightweb' ), wp_date( 'j M, H:i', (int) $run['at'] ), count( (array) $run['checks'] ), count( $problems ) );
		$items .= '<li>' . esc_html( $label . ' — ' . $line ) . ( $problems ? '<ul><li>' . implode( '</li><li>', array_map( 'esc_html', array_slice( $problems, 0, 20 ) ) ) . '</li></ul>' : '' ) . '</li>';
	}
	// Good only with an outside result: the server's own check cannot see blocks that depend on the caller's address.
	$status = $bad ? 'critical' : ( $out ? 'good' : 'recommended' );
	return array(
		'label'       => $bad ? __( 'Some search or AI crawlers cannot read the site', 'insightweb' ) : ( $out ? __( 'Search and AI crawlers can read the site', 'insightweb' ) : ( $any ? __( 'Crawler access checked from the server only (the outside check has not reported yet)', 'insightweb' ) : __( 'Crawler access has not been checked yet', 'insightweb' ) ) ),
		'status'      => $status,
		'badge'       => array(
			'label' => __( 'Search Insights', 'insightweb' ),
			'color' => $bad ? 'red' : 'blue',
		),
		'description' => '<p>' . esc_html__( 'Each week the home page and five sample pages are asked with the user agents of a browser, Googlebot, Bingbot, GPTBot, OAI-SearchBot, ChatGPT-User, PerplexityBot, ClaudeBot, Google-Extended, Applebot and a generic SEO crawler: from this server, and from outside by the workers. A page that is not a 200, or a challenge page, is a problem. From outside, a refused request with a named crawler\'s name is a refused fake (expected: the CDN lets the real crawlers in by their own addresses), so it is not counted.', 'insightweb' ) . '</p><ul>' . $items . '</ul>',
		'actions'     => '<p><a href="' . esc_url( insightweb_si_url() ) . '">' . esc_html__( 'Open Search Insights', 'insightweb' ) . '</a></p>',
		'test'        => 'aw_search_insights_crawl',
	);
}

add_filter(
	'site_status_tests',
	function ( $tests ) {
		$tests['direct']['aw_search_insights_crawl'] = array(
			'label' => __( 'Search and AI crawlers can read the site', 'insightweb' ),
			'test'  => 'insightweb_si_crawl_health_test',
		);
		return $tests;
	}
);

/** Overview box: the last inside and outside runs, problems first. */
function insightweb_si_box_crawl(): void {
	foreach ( array(
		__( 'From the server', 'insightweb' )         => AW_SI_CRAWL_IN,
		__( 'From outside (workers)', 'insightweb' ) => AW_SI_CRAWL_OUT,
	) as $label => $opt ) {
		$run = insightweb_si_crawl_last( $opt );
		if ( empty( $run['at'] ) ) {
			echo '<p><strong>' . esc_html( $label ) . ':</strong> ' . esc_html__( 'no result from the last 15 days (weekly, Monday morning).', 'insightweb' ) . '</p>';
			continue;
		}
		$problems = insightweb_si_crawl_problems( $run );
		$fakes    = insightweb_si_crawl_refused_fakes( $run );
		/* translators: 1: date, 2: checks. */
		$line = sprintf( __( '%1$s, %2$d checks', 'insightweb' ), wp_date( 'j M, H:i', (int) $run['at'] ), count( (array) $run['checks'] ) );
		echo '<p><strong>' . esc_html( $label ) . ':</strong> ' . esc_html( $line ) . ' — ' . ( $problems ? '<span class="dashicons dashicons-warning" aria-hidden="true"></span> ' . esc_html( implode( '; ', array_slice( $problems, 0, 8 ) ) ) : '<span class="dashicons dashicons-yes" aria-hidden="true"></span> ' . esc_html__( 'every agent got every page.', 'insightweb' ) ) . '</p>';
		if ( $fakes ) {
			/* translators: %d: refused requests. */
			echo '<p class="description">' . esc_html( sprintf( _n( '%d request with a search or AI crawler\'s name was refused as a fake (expected: the CDN lets the real crawlers in by their own addresses).', '%d requests with a search or AI crawler\'s name were refused as fakes (expected: the CDN lets the real crawlers in by their own addresses).', count( $fakes ), 'insightweb' ), count( $fakes ) ) ) . '</p>';
		}
	}
	echo '<p class="description">' . esc_html__( 'The server check only shows user-agent rules: blocks that depend on the caller\'s address show only in the outside check.', 'insightweb' ) . '</p>';
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	/**
	 * Crawler access from this server: every agent on every sample page (old name of `wp aw-si crawl`, kept as an alias).
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Check and print only; store nothing, send no email.
	 *
	 * ## EXAMPLES
	 *
	 *     wp aw-si-crawl --dry-run
	 */
	WP_CLI::add_command(
		'aw-si-crawl',
		function ( $args, $assoc ) {
			$run = insightweb_si_crawl_run( isset( $assoc['dry-run'] ) );
			WP_CLI\Utils\format_items( 'table', $run['checks'], array( 'agent', 'kind', 'code', 'ms', 'result' ) );
			$problems = insightweb_si_crawl_problems( $run );
			WP_CLI::log( $problems ? 'Problems: ' . implode( '; ', $problems ) : 'Every agent got every page.' );
		}
	);
}
