=== MailWeb ===
Contributors: wugweb
Tags: email, inbox, hostinger, smtp, signature
Requires at least: 7.1
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 3.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Hostinger Mail inside WordPress: read, reply and send from your mailboxes, plus SMTP sending with a daily limit and queue.

== Description ==

MailWeb puts a site's Hostinger mailboxes inside WordPress, so the team reads and answers mail where they already work. Everything is read from and written to the mailboxes through the Hostinger Mail API, so webmail and WordPress always show the same messages, folders and read state. Nothing from the mailboxes is copied into WordPress.

= Inbox =

* Every mailbox the API token can see, with its aliases, in one list or one at a time ("All mailboxes" mixes them, newest first).
* Folders: Inbox, Sent, Archive, Spam and Trash, with unread counts. A site can add a Website forms folder for its own form messages (filter `mailweb_forms_source`).
* WordPress list table: checkboxes, bulk actions (mark read or unread, archive, spam, move to Trash), row actions, search and pagination.
* Reading view in the edit-screen layout. Messages show in a sandboxed frame with scripts removed and pictures from the internet hidden until you choose to show them. Attachments download from the mailbox.
* Reply, Reply all, Forward and New message, sent from the mailbox itself: replies keep the thread, the original is marked answered, and a copy is kept in Sent.
* Delete only moves to Trash; nothing is removed for good.
* Unread badge on the Mail menu and a Mail dashboard widget.

= Profiles and signatures =

* Each mailbox and alias has a display name, a signature and a picture.
* The signature is added to replies and to the emails the site sends, laid out in a simple card.
* A site can add its own block under the signature (a banner, a notice) with the `mailweb_after_signature` filter.

= Sending =

* Sends the site's own email (notices, confirmations, newsletters) through its SMTP mailbox, with the sender name and a default Reply-To. Until a password is saved, WordPress sends the default way. A test email can be sent from the settings.
* A daily sending limit with a queue, for mailboxes that allow a fixed number of emails a day: priorities, retries, a pause when the mail server refuses mail, and pacing for FluentCRM campaigns.
* All mail settings in one place: Mail, then Settings.

= FluentCRM =

* Incoming email from people is noted on their FluentCRM contact (found, or made as "transactional" so they get no marketing), with a tag you choose, the full text and an "Open in Mail" link; replies sent from Mail are noted as "Reply sent". Choose the mailboxes in Mail → Settings.
* A site can keep a sender out of FluentCRM with the `mailweb_crm_skip_email` filter (return true for that address).

= Who can use it =

Administrators and editors. Every action checks a nonce and the user's capability, sending is limited to 30 messages an hour, and no message text is written to any log.

= Secrets =

The Mail API token, webhook secrets and SMTP password can be set in `wp-config.php` (`MAILWEB_API_TOKEN`, `MAILWEB_SECRET_<MAILBOX>`, `MAILWEB_SMTP_PASSWORD`). Values saved on the settings screen are stored encrypted with a key made from the site's salts; if the salts change, enter them again.

= Source code =

The JavaScript in `build/` is compiled with `@wordpress/scripts`. Its unminified source is in the `src/` folder of this plugin and is public at https://github.com/wugweb-git/Kits/tree/kits-suite/plugins/mailweb. To rebuild it, run `npm install` and then `npm run build` in that folder.

== Installation ==

1. Upload the `mailweb` folder to `/wp-content/plugins/` and activate MailWeb.
2. In hPanel, create a Mail API token for the domain's mailboxes. Save it in Mail → Settings, or add it to `wp-config.php`: `define( 'MAILWEB_API_TOKEN', '...' );`
3. In Mail → Settings, choose which mailboxes may send and the default From, add aliases, and fill in the profiles.
4. Optional: in hPanel, add a webhook for "message.received" on each mailbox pointing to `/wp-json/mailweb/v1/mail-in`, and save each webhook's secret in Mail → Settings, so unread counts refresh as soon as mail arrives.
5. Optional: set the SMTP mailbox and the daily limit in Mail → Settings → Site sending.

== Frequently Asked Questions ==

= Does it store my email in WordPress? =

No. Messages are read live from the mailboxes. Only send times are kept, for the hourly limit, and the site's own outgoing emails wait in a queue table when the daily limit is reached.

= Can it send as an alias? =

No. The Hostinger Mail API sends only as a real mailbox, so choose a mailbox in the From field.

= What happens on uninstall? =

Nothing is deleted. Settings and earlier data stay in place.

== External services ==

MailWeb connects to external services only when configured by the site administrator:

* **Hostinger Mail API (`https://api.mail.hostinger.com`):** When a Hostinger Mail API token is configured, reads mailbox folders/messages and sends replies/outbound mail through your Hostinger mailboxes. Terms & Privacy: [https://www.hostinger.com/privacy-policy](https://www.hostinger.com/privacy-policy).
* **Configured SMTP Server:** When SMTP credentials are configured under **Mail → Settings → Site sending**, delivers site emails via that SMTP host.
* **FluentCRM (local WordPress plugin, optional):** When FluentCRM is active and enabled in settings, logs transactional contact notes locally in WordPress.
* **Failure Alert Webhook (optional):** When an administrator configures a webhook URL (Slack, Discord, Telegram, or custom endpoint), sends throttled pause/failure notifications to that URL.

== Upgrade Notice ==

= 3.3.0 =
Adds Site Health email sending check, per-user pause notice dismissal, email logging & resend, fallback SMTP configuration, failure alert webhooks, and WP-CLI commands (`wp mailweb health|stats|test|prune-logs`).

== Bundled libraries ==

MailWeb ships these Composer libraries in `vendor/`, all under the MIT licence (GPL-compatible). Their licence texts are in each package folder.

* Hostinger Mail API PHP SDK (`hostinger/mail-api-php-sdk`) and, for it: Guzzle (`guzzlehttp/guzzle`, `guzzlehttp/promises`, `guzzlehttp/psr7`), PSR interfaces (`psr/container`, `psr/http-client`, `psr/http-factory`, `psr/http-message`), `ralouphie/getallheaders`.
* Symfony components used by the SDK: `serializer`, `property-access`, `property-info`, `type-info`, `string`, `deprecation-contracts`, and the `polyfill-ctype`, `polyfill-intl-grapheme`, `polyfill-intl-normalizer`, `polyfill-mbstring` and `polyfill-php80` packages.
* Type and docblock helpers: `phpdocumentor/reflection-common`, `reflection-docblock` and `type-resolver`, `phpstan/phpdoc-parser`, `doctrine/deprecations`, `webmozart/assert`.

Sources: https://packagist.org/packages/hostinger/mail-api-php-sdk and each package's page on Packagist.

== Changelog ==

= 3.3.0 =
* Lists: a Status column (New, Read, Replied, Forwarded) in every folder except Sent, and in Website forms. Replied also counts replies sent from webmail or another tool: the sender was written to, from any mailbox, after the message arrived.

= 3.2.1 =
* Shown as MailWeb (was Mailweb). The folder, text domain, settings, webhook address and everything saved stay the same.
* With Kits Core: a MailWeb tab on the Kits screens and a MailWeb row in Kits → Welcome → System Status.
* Update URI header, so WordPress.org never offers another plugin as an update.

= 3.2.0 =
* Message view: no remote content loads while pictures are hidden (a Content-Security-Policy in the frame; protocol-relative and escaped URLs included), and an email's own CSS cannot break out of its style tag.
* Replying or forwarding always flags the original Answered / Forwarded.
* All mailboxes: paging reads deeper into each mailbox, so later pages no longer skip messages or come up empty; dates are compared as dates.
* The mailbox lookup runs once per request and waits 5 minutes after a failure, so admin pages do not stall when the Mail API is down.
* Mailboxes with the same name on different domains get their own key.
* Queue: an email with no confirmation from the server is held after 4 tries instead of being resent; only errors about our own mailbox pause sending, not a refused recipient.
* FluentCRM: the sync no longer marks mail unread, runs one at a time and does not duplicate notes.
* Overview and dashboard: read and unread shown as in the inbox. No PHP warnings from crafted URLs.

= 3.1.1 =
* Opening a message marks it read, and replying to or forwarding a message marks the original read. The Mail API does not do this when the text is fetched.
* Translation template (languages/mailweb.pot) brought up to date.

= 3.1.0 =
* Mail menu: Inbox, Overview and Settings; Settings and Overview links on the Plugins screen.
* Mail lists are WordPress list tables: checkboxes, bulk actions, row actions, search and pagination.
* One address parser for every input; the 5-minute schedule is registered once.
* Unused functions removed.

= 3.0.0 =
* Now a standalone product: slug, folder and text domain `mailweb`; functions, options, hooks and the queue table renamed to `mailweb_`.
* Mailboxes come only from the API token; choose which may send and the default From in Mail → Settings. Webhook secrets per mailbox.
* Webhook address is now `/wp-json/mailweb/v1/mail-in`.
* Secrets saved on the settings screen are encrypted.
* Uploaded attachments are checked against the 10 MB total before they are read.
* FluentCRM feed settings: on/off, tag and mailboxes.
* Website forms folder and the block under signatures are now extension points (`mailweb_forms_source`, `mailweb_after_signature`).
* All text translatable (text domain `mailweb`, `languages/mailweb.pot`).
* Removed: copying mail into WordPress posts, and the old reply screen (both had been switched off).

= 2.9.3 =
* FluentCRM's dashboard no longer shows the "Set Up FluentSMTP" card; Mailweb sends the site's email.

= 2.9.2 =
* Removed the 2.9.1 change (no second signature on emails with their own); back to 2.9.0 behaviour.

= 2.9.0 =
* FluentCRM sync for mail is back: each incoming email from a person finds or creates their contact (tag "Emailed us") with a note holding the full text and an "Open in Mail" link; replies sent from Mail are noted too. Checked every 5 minutes and when the webhook fires; `wp mailweb crm-sync --all` catches up.

= 2.8.0 =
* Renamed from Wug Mail to Mailweb. The folder, settings, webhook address and everything saved stay the same.

= 2.7.0 =
* The SMTP connection (mailbox, password, server, port, sender name, default Reply-To) moved here from Kits Core: all of a site's mail is now in Mailweb. Same saved settings; nothing to re-enter.

= 2.6.0 =
* Plugin Check fixes: output escaped where it is printed, request values sanitised, nonce checks where uploads are read, translator comment for the unread count.
* Plugin information and this readme.

= 2.5.2 =
* Countdown campaign strip under signatures, with a line on what the campaign is about.

= 2.4.0 =
* Campaign strip under signatures.

= 2.3.0 =
* Signatures keep their line breaks. Replies go from a chosen mailbox.

= 2.2.0 =
* Inbox redesigned with the WordPress list table, an "All mailboxes" view and edit-screen layouts.

= 2.0.0 =
* A real inbox in WordPress through the Hostinger Mail API.

= 1.0.0 =
* Incoming mail, Mail menu with unread count, dashboard widget.
